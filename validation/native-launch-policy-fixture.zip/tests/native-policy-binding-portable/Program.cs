// Pure binary/boot parsing and non-Windows refusal fixtures. No OS ACL proof.
using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using GlassWidgets.ServerControlPrep;
internal static class Program {
 const string Owner="S-1-5-21-111-222-333-1001",Logon="S-1-5-5-700-800";
 sealed class Rule {internal readonly string Sid;internal readonly byte Kind,Flags;internal Rule(string sid,byte kind=0,byte flags=0){Sid=sid;Kind=kind;Flags=flags;}}
 static byte[] Sid(string value){string[] parts=value.Split('-');var bytes=new byte[8+(parts.Length-3)*4];bytes[0]=1;bytes[1]=(byte)(parts.Length-3);ulong authority=ulong.Parse(parts[2],CultureInfo.InvariantCulture);for(int i=7;i>=2;i--){bytes[i]=(byte)(authority&255);authority>>=8;}for(int i=3;i<parts.Length;i++)BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(8+(i-3)*4,4),uint.Parse(parts[i],CultureInfo.InvariantCulture));return bytes;}
 static byte[] Descriptor(string owner=Owner,params Rule[] rules){byte[] user=Sid(owner);var aces=new List<byte[]>();foreach(var rule in rules){byte[] sid=Sid(rule.Sid),ace=new byte[sid.Length+8];ace[0]=rule.Kind;ace[1]=rule.Flags;BinaryPrimitives.WriteUInt16LittleEndian(ace.AsSpan(2,2),(ushort)ace.Length);BinaryPrimitives.WriteUInt32LittleEndian(ace.AsSpan(4,4),0x001f01ff);sid.CopyTo(ace,8);aces.Add(ace);}int aclSize=8+aces.Sum(x=>x.Length);var result=new byte[20+user.Length+aclSize];result[0]=1;BinaryPrimitives.WriteUInt16LittleEndian(result.AsSpan(2,2),0x8004);BinaryPrimitives.WriteUInt32LittleEndian(result.AsSpan(4,4),20);BinaryPrimitives.WriteUInt32LittleEndian(result.AsSpan(16,4),(uint)(20+user.Length));user.CopyTo(result,20);int acl=20+user.Length;result[acl]=2;BinaryPrimitives.WriteUInt16LittleEndian(result.AsSpan(acl+2,2),(ushort)aclSize);BinaryPrimitives.WriteUInt16LittleEndian(result.AsSpan(acl+4,2),(ushort)aces.Count);int cursor=acl+8;foreach(byte[] ace in aces){ace.CopyTo(result,cursor);cursor+=ace.Length;}return result;}
 static bool Private(byte[] descriptor)=>NativePrivateDescriptor.IsPrivate(descriptor,Owner,Logon);
 static void Check(bool condition,string message){if(!condition)throw new Exception(message);}
 static int checks;
 static void Test(string name,Action body){body();checks++;Console.WriteLine(JsonSerializer.Serialize(new{test=name,passed=true,pureFixtureOnly=true,windowsAclExecution=false}));}
 static void Refused(Action action){bool refused=false;try{action();}catch(InvalidOperationException){refused=true;}catch(PlatformNotSupportedException){refused=true;}Check(refused,"expected refusal");}
 static int Main(){
  Console.WriteLine(JsonSerializer.Serialize(new{phaseProbePureChecks=FixedBootQueryPhaseProbe.SelfTest(),nativeWindowsExecution=false}));
  Test("trusted-user-system-admin-current-logon-allow-only",()=>Check(Private(Descriptor(Owner,new Rule(Owner),new Rule(Logon),new Rule("S-1-5-18"),new Rule("S-1-5-32-544"))),"trusted DACL"));
  Test("untrusted-deny-does-not-grant-access",()=>Check(Private(Descriptor(Owner,new Rule(Owner),new Rule("S-1-1-0",1))),"deny is not a grant"));
  Test("creator-owner-inherit-only-permitted",()=>Check(Private(Descriptor(Owner,new Rule(Owner),new Rule("S-1-3-0",0,11))),"creator owner inheritance"));
  Test("creator-owner-direct-grant-refused",()=>Check(!Private(Descriptor(Owner,new Rule("S-1-3-0"))),"unknown current owner mapping refused"));
  Test("everyone-grant-refused",()=>Check(!Private(Descriptor(Owner,new Rule("S-1-1-0"))),"everyone refused"));
  Test("inherited-everyone-grant-refused",()=>Check(!Private(Descriptor(Owner,new Rule("S-1-1-0",0,16))),"inherited grant refused"));
  Test("inherit-only-untrusted-grant-still-refused-for-future-files",()=>Check(!Private(Descriptor(Owner,new Rule("S-1-1-0",0,11))),"future files protected"));
  Test("other-logon-grant-refused",()=>Check(!Private(Descriptor(Owner,new Rule("S-1-5-5-900-901"))),"other logon refused"));
  Test("wrong-owner-refused-even-with-trusted-dacl",()=>Check(!Private(Descriptor("S-1-5-21-111-222-333-2002",new Rule(Owner))),"owner exact"));
  Test("null-dacl-refused",()=>{var bytes=Descriptor();BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(16,4),0);Check(!Private(bytes),"null DACL refused");});
  Test("missing-dacl-control-bit-refused",()=>{var bytes=Descriptor();BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(2,2),0x8000);Check(!Private(bytes),"DACL flag");});
  Test("absolute-descriptor-refused",()=>{var bytes=Descriptor();BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(2,2),4);Check(!Private(bytes),"self-relative required");});
  Test("unrecognized-descriptor-revision-refused",()=>{var bytes=Descriptor();bytes[0]=2;Check(!Private(bytes),"revision");});
  Test("truncated-descriptor-refused",()=>{Check(!Private(new byte[19]),"small");var bytes=Descriptor(Owner,new Rule(Owner));Array.Resize(ref bytes,bytes.Length-1);Check(!Private(bytes),"truncated");});
  Test("oversized-descriptor-refused",()=>Check(!Private(new byte[65537]),"size bound"));
  Test("unaligned-owner-offset-refused",()=>{var bytes=Descriptor();BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(4,4),21);Check(!Private(bytes),"owner alignment");});
  Test("oversized-sid-subauthority-count-refused",()=>{var bytes=Descriptor();bytes[21]=16;Check(!Private(bytes),"SID bounds");});
  Test("out-of-bounds-dacl-offset-refused",()=>{var bytes=Descriptor();BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(16,4),65532);Check(!Private(bytes),"DACL bounds");});
  Test("object-ace-refused-without-guessing-semantics",()=>Check(!Private(Descriptor(Owner,new Rule(Owner,5))),"object ACE"));
  Test("callback-ace-refused-without-running-condition",()=>Check(!Private(Descriptor(Owner,new Rule(Owner,9))),"callback ACE"));
  Test("audit-flags-on-access-ace-refused",()=>Check(!Private(Descriptor(Owner,new Rule(Owner,0,64))),"unexpected ACE flags"));
  Test("invalid-ace-size-refused",()=>{var bytes=Descriptor(Owner,new Rule(Owner));int acl=(int)BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(16,4));BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(acl+10,2),12);Check(!Private(bytes),"ACE size");});
  Test("extra-nonzero-ace-payload-refused",()=>{var bytes=Descriptor(Owner,new Rule(Owner));int acl=(int)BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(16,4));Array.Resize(ref bytes,bytes.Length+4);BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(acl+2,2),(ushort)(bytes.Length-acl));bytes[^1]=1;Check(!Private(bytes),"unclaimed ACL data");});
  Test("zero-filled-unused-acl-allocation-permitted",()=>{var bytes=Descriptor(Owner,new Rule(Owner));int acl=(int)BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(16,4));Array.Resize(ref bytes,bytes.Length+4);BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(acl+2,2),(ushort)(bytes.Length-acl));Check(Private(bytes),"zero unused allocation");});
  Test("fixed-boot-query-is-local-property-only-without-json-command-discovery",()=>{string command=WindowsNativeSessionBinding.FixedBootQueryCommand;Check(command.Contains("-ClassName Win32_OperatingSystem -Property LastBootUpTime -ErrorAction Stop")&&!command.Contains("ConvertTo-Json")&&!command.Contains("-ComputerName")&&!command.Contains("-CimSession")&&command.Contains("[Console]::Out.WriteLine"),"fixed-boot-query");});
  Test("fixed-roundtrip-boot-string-json-envelope-preserves-original-milliseconds",()=>{foreach(var value in new[]{new DateTimeOffset(2026,11,22,0,0,0,TimeSpan.Zero).AddTicks(1),new DateTimeOffset(2000,2,29,23,59,59,TimeSpan.Zero).AddTicks(9999999),new DateTimeOffset(2026,11,22,4,1,2,TimeSpan.FromHours(3)).AddTicks(4321000)}){string text=value.UtcDateTime.ToString("o",CultureInfo.InvariantCulture);Check(WindowsNativeSessionBinding.ParseBootMilliseconds("\""+text+"\"")==value.ToUnixTimeMilliseconds(),"roundtrip-envelope");}});
  Test("boot-parser-keeps-milliseconds-not-filetime-rounding",()=>{long value=WindowsNativeSessionBinding.ParseBootMilliseconds("\"2026-11-22T08:13:42.1234567Z\"\r\n");long expected=new DateTimeOffset(2026,11,22,8,13,42,123,TimeSpan.Zero).ToUnixTimeMilliseconds();Check(value==expected,"boot milliseconds");});
  Test("boot-parser-accepts-shorter-positive-fraction",()=>Check(WindowsNativeSessionBinding.ParseBootMilliseconds("\"2026-11-22T08:13:42.1Z\"")==new DateTimeOffset(2026,11,22,8,13,42,100,TimeSpan.Zero).ToUnixTimeMilliseconds(),"fraction"));
  Test("boot-parser-refuses-non-utc-or-ambiguous-input",()=>{foreach(string text in new[]{"null","123","{}","\"2026-11-22T08:13:42Z\"","\"2026-11-22T08:13:42.123+02:00\"","\"2026-13-22T08:13:42.123Z\"","\"2026-11-22T08:13:42.12345678Z\"","\"1960-11-22T08:13:42.123Z\""})Refused(()=>WindowsNativeSessionBinding.ParseBootMilliseconds(text));});
  if(!OperatingSystem.IsWindows())Test("non-windows-binding-and-token-capture-refuse-before-native-access",()=>{Refused(()=>new WindowsNativePolicyBinding("C:\\private",Owner,Logon));Refused(()=>WindowsNativeSessionBinding.Capture());});
  Test("fixed-native-flags-are-small-copied-and-canonical",()=>{var source=new[]{new KeyValuePair<string,string>("GW_TUNNEL","1"),new KeyValuePair<string,string>("GW_CHAT_LAN_PORT","65535")};var copy=NativeServerLaunchDefinition.ValidateFlags(source);source[0]=new KeyValuePair<string,string>("NODE_OPTIONS","bad");Check(copy.Length==2&&copy[0].Key=="GW_CHAT_LAN_PORT"&&copy[1].Key=="GW_TUNNEL","copied canonical flags");});
  Test("runtime-option-and-path-injection-flags-refused",()=>{foreach(string key in new[]{"NODE_OPTIONS","NODE_PATH","PATH","SystemRoot","GW_SERVER_CONFIG","gw_tunnel"})Refused(()=>NativeServerLaunchDefinition.ValidateFlags(new[]{new KeyValuePair<string,string>(key,"1")}));});
  Test("duplicate-or-invalid-fixed-flags-refused",()=>{Refused(()=>NativeServerLaunchDefinition.ValidateFlags(new[]{new KeyValuePair<string,string>("GW_TUNNEL","0"),new KeyValuePair<string,string>("GW_TUNNEL","1")}));foreach(string port in new[]{"0","65536","80\r\n","abc","080"})Refused(()=>NativeServerLaunchDefinition.ValidateFlags(new[]{new KeyValuePair<string,string>("GW_CHAT_LAN_PORT",port)}));Refused(()=>NativeServerLaunchDefinition.ValidateFlags(new[]{new KeyValuePair<string,string>("GW_MAILER","true")}));});
  Test("native-command-quoting-keeps-fixed-arguments",()=>{Check(NativeOwnedCreationFrame.Quote("")=="\"\"","empty");Check(NativeOwnedCreationFrame.Quote("--")=="\"--\"","option delimiter");Check(NativeOwnedCreationFrame.Quote("C:\\path with space\\server.cjs")=="\"C:\\path with space\\server.cjs\"","path");Check(NativeOwnedCreationFrame.Quote("a\"b")=="\"a\\\"b\"","quote escape");Check(NativeOwnedCreationFrame.Quote("C:\\path\\")=="\"C:\\path\\\\\"","trailing slash");});
  Test("native-command-refuses-control-and-unbounded-arguments",()=>{foreach(string value in new[]{null,"a\r\nb","a\0b",new string('a',4097)})Refused(()=>NativeOwnedCreationFrame.Quote(value));});
  Test("malformed-descriptor-mutations-remain-bounded",()=>{var random=new Random(413);byte[] seed=Descriptor(Owner,new Rule(Owner),new Rule(Logon));for(int i=0;i<2000;i++){var bytes=(byte[])seed.Clone();for(int j=0;j<4;j++)bytes[random.Next(bytes.Length)]=(byte)random.Next(256);_ = Private(bytes);}});
  if(!OperatingSystem.IsWindows())Test("native-creator-and-owner-refuse-on-non-windows-before-action",()=>{Refused(()=>new NativeServerLaunchDefinition(null,null,null,null,null,Array.Empty<KeyValuePair<string,string>>()));Refused(()=>NativeOwnedCreationFrame.CreateSuspended(null,null,null,null,default));Refused(()=>new FixedNativeSourceOwner(null,null,"fixture",null));});
  Console.WriteLine(JsonSerializer.Serialize(new{passed=checks,scope="pure descriptor/boot/argument parsing plus platform refusal, not Windows execution",windowsAclExecution=false,fixedCreatorCompiled=true,nativeCreationWindowsExecution=false,productionHostConnected=false}));return 0;
 }
}
