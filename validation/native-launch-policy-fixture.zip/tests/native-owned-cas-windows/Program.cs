// PRIVATE Windows integration acceptance candidate. Root accepts no existing
// path or PID arguments. It uses its own temporary files and pinned Node fixture.
// Not linked into the installed app and not yet executed on Windows.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Threading;
using Microsoft.Win32.SafeHandles;
using GlassWidgets.ServerControlPrep;
internal static class NativeOwnedCasAcceptance {
 const string NodeSha="528a9aa64888a2a3ba71c6aea89434dd5ab5cb3caa9f0f31345cf5facf685ab0",Installation="native-owned-cas-disposable-fixture";
 static readonly JsonSerializerOptions Json=new JsonSerializerOptions{IncludeFields=true,PropertyNamingPolicy=JsonNamingPolicy.CamelCase};
 sealed class FileDocument {public string Path;public long Bytes;public string Sha256;}
 sealed class Plan {public string Root,PolicyDir,SourceRoot,Config,Node,Entry,Module,Session,Nonce,Controller,Manifest,ExpectedError;public long Revision;public FileDocument[] Files;}
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetFinalPathNameByHandleW(SafeFileHandle file,StringBuilder value,uint size,uint flags);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetProcessId(NativeCreationHandle process);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(NativeCreationHandle process,out long created,out long exit,out long kernel,out long user);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageNameW(NativeCreationHandle process,uint flags,StringBuilder image,ref uint length);
 [DllImport("kernel32.dll",SetLastError=true)] static extern NativeCreationHandle OpenProcess(uint access,bool inherit,uint pid);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(NativeCreationHandle process,uint milliseconds);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateProcess(NativeCreationHandle process,uint code);
 static void Require(bool value){if(!value)throw new InvalidOperationException("native_owned_cas_fixture_assertion");}
 static int checks;
 static void Check(string name,Action body){body();checks++;Console.WriteLine("ok "+name);}
 static string Hash(byte[] value)=>Convert.ToHexString(SHA256.HashData(value)).ToLowerInvariant();
 static FileDocument Spec(string file){using(var stream=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)){var canonical=new StringBuilder(32768);uint size=GetFinalPathNameByHandleW(stream.SafeFileHandle,canonical,32768,0);Require(size>0&&size<32768&&canonical.ToString().StartsWith("\\\\?\\",StringComparison.Ordinal));return new FileDocument{Path=canonical.ToString().Substring(4),Bytes=stream.Length,Sha256=Hash(File.ReadAllBytes(file))};}}
 static void PrivateDirectory(string dir,string owner){var security=new DirectorySecurity();security.SetAccessRuleProtection(true,false);var user=new SecurityIdentifier(owner);security.SetOwner(user);foreach(string sid in new[]{owner,"S-1-5-18","S-1-5-32-544"})security.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(sid),FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));new DirectoryInfo(dir).SetAccessControl(security);}
 static string Encode(Plan plan)=>Convert.ToBase64String(JsonSerializer.SerializeToUtf8Bytes(plan,Json));
 static Plan Decode(string value){Require(value!=null&&value.Length<24000);var plan=JsonSerializer.Deserialize<Plan>(Convert.FromBase64String(value),Json);Require(plan!=null&&plan.Files!=null&&plan.Files.Length>=7&&plan.Files.Length<=12&&Guid.TryParseExact(plan.Nonce,"D",out _)&&Guid.TryParseExact(plan.Controller,"D",out _));string root=Path.GetFullPath(plan.Root),temp=Path.GetFullPath(Path.GetTempPath()).TrimEnd(Path.DirectorySeparatorChar);Require(Path.GetDirectoryName(root)==temp&&Path.GetFileName(root).StartsWith("gw native cas ",StringComparison.Ordinal)&&Directory.Exists(root)&&new DirectoryInfo(root).LinkTarget==null);foreach(string file in new[]{plan.PolicyDir,plan.SourceRoot,plan.Config,plan.Node,plan.Entry,plan.Module}.Concat(plan.Files.Select(x=>x.Path)))Require(Path.GetFullPath(file).StartsWith(root+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase));Require(plan.Manifest==HeldSourceFiles.HashManifest(plan.Files.Select(x=>new SourceFileSpec(x.Path,x.Bytes,x.Sha256))));Require(plan.Files.Single(x=>x.Path==plan.Node).Sha256==NodeSha);return plan;}
 static string Line(StreamReader reader){string line=reader.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(15)).GetAwaiter().GetResult();Require(line!=null&&line.Length<32768);return line;}
 sealed class ObservedChild:IDisposable {
  readonly NativeCreationHandle handle;readonly uint pid;readonly long birth;bool closed;
  internal ObservedChild(JsonElement identity,WindowsNativeSessionBinding session){pid=identity.GetProperty("pid").GetUInt32();birth=long.Parse(identity.GetProperty("nativeCreatedFileTimeUtc").GetString(),NumberStyles.None,CultureInfo.InvariantCulture);string image=identity.GetProperty("exe").GetString();handle=OpenProcess(0x00101001,false,pid);try{Require(handle!=null&&!handle.IsInvalid&&GetProcessId(handle)==pid&&session.VerifyOwnedProcessToken(handle));long actual,exit,kernel,user;Require(GetProcessTimes(handle,out actual,out exit,out kernel,out user)&&actual==birth);var path=new StringBuilder(32768);uint length=32768;Require(QueryFullProcessImageNameW(handle,0,path,ref length)&&String.Equals(path.ToString(),image,StringComparison.OrdinalIgnoreCase));}catch{handle?.Dispose();throw;}}
  internal bool Exited(uint timeout){uint result=WaitForSingleObject(handle,timeout);Require(result==0||result==258);if(result==258)return false;long actual,exit,kernel,user;Require(GetProcessId(handle)==pid&&GetProcessTimes(handle,out actual,out exit,out kernel,out user)&&actual==birth);return true;}
  public void Dispose(){if(closed)return;if(!Exited(0)){Require(TerminateProcess(handle,95)&&Exited(10000));}closed=true;handle.Dispose();}
 }
 static int Holder(string encoded){var plan=Decode(encoded);var specs=plan.Files.Select(x=>new SourceFileSpec(x.Path,x.Bytes,x.Sha256)).ToArray();using(var source=HeldSourceFiles.Acquire(specs,CancellationToken.None)){
  var context=new WindowsNativePolicyContext(plan.PolicyDir,source);Require(context.SessionId==plan.Session);
  var definition=new NativeServerLaunchDefinition(source,plan.Node,plan.Entry,plan.SourceRoot,plan.Config,new[]{new KeyValuePair<string,string>("GW_TUNNEL","0"),new KeyValuePair<string,string>("GW_MAILER","0")});
  var owner=new FixedNativeSourceOwner(definition,context,Installation,(authority,server,nonce,cancellation)=>{
   cancellation.ThrowIfCancellationRequested();Console.WriteLine(JsonSerializer.Serialize(new{phase="registration-required",nonce,sourceOwner=authority,server,manifest=source.ManifestHash},Json));Console.Out.Flush();string ack=Console.In.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(12),cancellation).GetAwaiter().GetResult();return ack=="ack:"+nonce;
  });
  try{var operation=new NativeStartCommitContext(plan.Session,plan.Revision,source.ManifestHash,new NativeStartOperation(plan.Nonce,plan.Controller,"manual-start",Installation,plan.Session));var result=owner.Start(operation,CancellationToken.None);Require(plan.ExpectedError==null);Console.WriteLine(JsonSerializer.Serialize(new{phase="resumed",nonce=result.OperationNonce,sourceOwner=result.SourceOwner,server=result.Server,manifest=result.SourceManifestHash,definitionHash=result.DefinitionHash},Json));Console.Out.Flush();string end=Console.In.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(15)).GetAwaiter().GetResult();Require(end=="finish:"+plan.Nonce);Require(owner.CloseOwned());return 0;}
  catch(InvalidOperationException error){if(plan.ExpectedError!=null&&error.Message==plan.ExpectedError){Require(owner.RequiresReconciliation||plan.ExpectedError=="native_running_intent_changed");Require(owner.CloseOwned());Console.WriteLine(JsonSerializer.Serialize(new{phase="expected-refusal",error=error.Message,nonce=plan.Nonce}));Console.Out.Flush();return 0;}throw;}
  finally{if(!owner.CloseOwned())throw new InvalidOperationException("fixture_original_cleanup_unverified");}
 }}
 static Process StartHolder(string image,Plan plan){var info=new ProcessStartInfo(image){UseShellExecute=false,CreateNoWindow=true,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true,WorkingDirectory=plan.SourceRoot};info.ArgumentList.Add("--fixture-holder");info.ArgumentList.Add(Encode(plan));info.Environment["NODE_OPTIONS"]="--invalid-native-owner-fixture-option";var process=new Process{StartInfo=info};Require(process.Start());Require(!process.SafeHandle.IsInvalid);return process;}
 static void CheckJavaScriptPolicyExclusion(Plan plan){var info=new ProcessStartInfo(plan.Node){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true,WorkingDirectory=plan.SourceRoot};info.Environment.Remove("NODE_OPTIONS");info.Environment.Remove("NODE_PATH");info.ArgumentList.Add(Path.Combine(plan.SourceRoot,"policy-race-fixture.cjs"));info.ArgumentList.Add(plan.PolicyDir);info.ArgumentList.Add(plan.Session);using(var process=new Process{StartInfo=info}){Require(process.Start()&&!process.SafeHandle.IsInvalid);try{var output=process.StandardOutput.ReadToEndAsync();var error=process.StandardError.ReadToEndAsync();Require(process.WaitForExit(10000)&&process.ExitCode==0&&output.GetAwaiter().GetResult().Trim()=="fixture-policy-busy"&&error.GetAwaiter().GetResult()=="");}finally{if(!process.HasExited){process.Kill(false);Require(process.WaitForExit(10000));}}}}
 static void WritePolicy(Plan plan,string intent,long revision){File.WriteAllText(Path.Combine(plan.PolicyDir,"server-intent-v1.json"),JsonSerializer.Serialize(new{version=1,policy="login-start-manual-stop-until-next-login-v1",sessionId=plan.Session,intent,revision}));File.WriteAllText(Path.Combine(plan.PolicyDir,"server-operation-v1.json"),JsonSerializer.Serialize(new{version=1,nonce=plan.Nonce,controllerId=plan.Controller,@event="manual-start",installationId=Installation,persistedSessionId=plan.Session}));}
 static JsonDocument WaitJson(string file,ObservedChild child){var clock=Stopwatch.StartNew();while(clock.ElapsedMilliseconds<10000){if(File.Exists(file))return JsonDocument.Parse(File.ReadAllText(file));Require(!child.Exited(0));Thread.Sleep(20);}throw new InvalidOperationException("fixture_ready_timeout");}
 static void WriteRefused(string file){bool refused=false;try{using(var stream=new FileStream(file,FileMode.Open,FileAccess.ReadWrite,FileShare.ReadWrite|FileShare.Delete))stream.WriteByte(1);}catch(IOException){refused=true;}catch(UnauthorizedAccessException){refused=true;}Require(refused);}
 static readonly string Reader=@"'use strict';
const fs=require('fs');
const p=JSON.parse(fs.readFileSync(process.env.GW_SERVER_CONFIG,'utf8'));
if(process.version!=='v20.18.3'||process.env.NODE_OPTIONS||process.env.NODE_PATH||process.env.GW_TUNNEL!=='0'||process.env.GW_MAILER!=='0')process.exit(41);
const value=require(p.module);if(value.nonce!==p.nonce)process.exit(42);
fs.writeFileSync(p.ready,JSON.stringify({pid:process.pid,version:process.version,uv:process.versions.uv,nonce:p.nonce}),{flag:'wx'});
setInterval(()=>{},1000);
";
 static int Root(){
  // Normal-token capture precedes temporary-file creation. An elevated CI worker
  // must start this fixture as a disposable non-admin user, not relax the check.
  var session=WindowsNativeSessionBinding.Capture();Check("normal-user token captured with the pinned native runtime",()=>Require(Environment.Version.ToString()=="10.0.15"));string temp=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Temp");Require(Path.IsPathFullyQualified(temp));Directory.CreateDirectory(temp);Environment.SetEnvironmentVariable("TEMP",temp);Environment.SetEnvironmentVariable("TMP",temp);
  string suppliedNode=Environment.GetEnvironmentVariable("GW_NODE_SOURCE_FIXTURE_PATH");Require(suppliedNode!=null&&Path.IsPathFullyQualified(suppliedNode)&&File.Exists(suppliedNode)&&Hash(File.ReadAllBytes(suppliedNode))==NodeSha);
  string root=Path.Combine(Path.GetTempPath(),"gw native cas "+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);PrivateDirectory(root,session.OwnerSid);Process holder=null;ObservedChild child=null;
  try{
   string sourceRoot=Path.Combine(root,"source"),data=Path.Combine(root,"data");Directory.CreateDirectory(sourceRoot);Directory.CreateDirectory(data);string name=System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
   var original=Directory.GetFiles(AppContext.BaseDirectory,"*",SearchOption.TopDirectoryOnly);Require(original.Length<=128&&original.Sum(x=>new FileInfo(x).Length)<268435456);foreach(string file in original)File.Copy(file,Path.Combine(sourceRoot,Path.GetFileName(file)),false);
   string node=Path.Combine(sourceRoot,"node.exe"),entry=Path.Combine(sourceRoot,"gw-native-owner-reader.cjs"),module=Path.Combine(sourceRoot,"delayed.cjs"),config=Path.Combine(data,"fixture-config.json"),ready=Path.Combine(data,"ready.json");File.Copy(suppliedNode,node,false);File.WriteAllText(entry,Reader,new UTF8Encoding(false));string nonce=Guid.NewGuid().ToString("D");File.WriteAllText(module,"module.exports={nonce:"+JsonSerializer.Serialize(nonce)+"};\n",new UTF8Encoding(false));File.WriteAllText(config,JsonSerializer.Serialize(new{module,ready,nonce}),new UTF8Encoding(false));
   var files=new[]{".exe",".dll",".deps.json",".runtimeconfig.json"}.Select(extension=>Path.Combine(sourceRoot,name+extension)).Concat(new[]{node,entry,module,Path.Combine(sourceRoot,"server-policy-store-prep.js"),Path.Combine(sourceRoot,"server-policy-prep.js"),Path.Combine(sourceRoot,"policy-race-fixture.cjs")}).Select(Spec).ToArray();var plan=new Plan{Root=root,SourceRoot=sourceRoot,PolicyDir=data,Config=config,Node=files.Single(x=>x.Path.EndsWith("\\node.exe",StringComparison.Ordinal)).Path,Entry=files.Single(x=>x.Path.EndsWith("gw-native-owner-reader.cjs",StringComparison.Ordinal)).Path,Module=files.Single(x=>x.Path.EndsWith("delayed.cjs",StringComparison.Ordinal)).Path,Session=session.SessionId,Nonce=nonce,Controller=Guid.NewGuid().ToString("D"),Revision=7,Files=files,Manifest=HeldSourceFiles.HashManifest(files.Select(x=>new SourceFileSpec(x.Path,x.Bytes,x.Sha256)))};WritePolicy(plan,"running",7);
   string image=files.Single(x=>x.Path.EndsWith(name+".exe",StringComparison.Ordinal)).Path;holder=StartHolder(image,plan);
   using(var registration=JsonDocument.Parse(Line(holder.StandardOutput))){var packet=registration.RootElement;Require(packet.GetProperty("phase").GetString()=="registration-required"&&packet.GetProperty("nonce").GetString()==plan.Nonce&&packet.GetProperty("manifest").GetString()==plan.Manifest);child=new ObservedChild(packet.GetProperty("server"),session);
    Check("independent exact child handle is retained while initial thread remains suspended",()=>{Require(!child.Exited(0)&&!File.Exists(ready));});
    Check("native creation callback holds the same CreateNew policy lock",()=>{bool blocked=false;try{using(var value=new FileStream(Path.Combine(data,"server-intent-v1.lock"),FileMode.CreateNew,FileAccess.Write)){} }catch(IOException){blocked=true;}Require(blocked);});
    Check("actual Node wx policy writer is excluded by the held native CAS lock",()=>CheckJavaScriptPolicyExclusion(plan));
    Check("attempt and suspended registration are flushed before independent acknowledgement",()=>{using(var record=JsonDocument.Parse(File.ReadAllText(Path.Combine(data,"server-owned-start-"+nonce+".json")))){Require(record.RootElement.GetProperty("phase").GetString()=="suspended-owned-not-ready"&&record.RootElement.GetProperty("server").GetProperty("nativeCreatedFileTimeUtc").GetString()==packet.GetProperty("server").GetProperty("nativeCreatedFileTimeUtc").GetString());}Require(File.Exists(Path.Combine(data,"server-launch-attempt-"+nonce+".json")));});
   }
   holder.StandardInput.WriteLine("ack:"+nonce);holder.StandardInput.Flush();using(var resumed=JsonDocument.Parse(Line(holder.StandardOutput)))Require(resumed.RootElement.GetProperty("phase").GetString()=="resumed");
   using(var status=WaitJson(ready,child))Check("real pinned Node executes under the filtered native environment",()=>Require(status.RootElement.GetProperty("version").GetString()=="v20.18.3"&&status.RootElement.GetProperty("nonce").GetString()==nonce));
   Check("native source lease excludes module writes while ordinary data stays writable",()=>{WriteRefused(module);File.WriteAllText(Path.Combine(data,"ordinary-data.txt"),"fixture writable");Require(File.ReadAllText(Path.Combine(data,"ordinary-data.txt"))=="fixture writable");});
   Check("policy lock is released only after owned child registration and resume",()=>Require(!File.Exists(Path.Combine(data,"server-intent-v1.lock"))));
   holder.Kill(false);Require(holder.WaitForExit(10000));holder.Dispose();holder=null;
   Check("creator death ends the original child in the private creation-time job",()=>Require(child.Exited(10000)));child.Dispose();child=null;
   Check("module writes restore after exact original child exit",()=>{string text=File.ReadAllText(module);File.WriteAllText(module,text+"\n");File.WriteAllText(module,text);});
   // The original bytes were restored, so a new holder can verify the same
   // manifest. Its durable attempt barrier must refuse the original operation.
   plan.ExpectedError="native_start_attempt_already_exists_or_unavailable";holder=StartHolder(image,plan);using(var replay=JsonDocument.Parse(Line(holder.StandardOutput)))Check("fresh native owner cannot replay a persisted attempted operation",()=>Require(replay.RootElement.GetProperty("phase").GetString()=="expected-refusal"&&replay.RootElement.GetProperty("error").GetString()==plan.ExpectedError));Require(holder.WaitForExit(10000)&&holder.ExitCode==0);holder.Dispose();holder=null;
   plan.Nonce=Guid.NewGuid().ToString("D");plan.Controller=Guid.NewGuid().ToString("D");plan.Revision=8;plan.ExpectedError="native_running_intent_changed";WritePolicy(plan,"stopped",8);holder=StartHolder(image,plan);using(var stopped=JsonDocument.Parse(Line(holder.StandardOutput)))Check("saved Stop refuses a later native request before creation and attempt marker",()=>Require(stopped.RootElement.GetProperty("phase").GetString()=="expected-refusal"&&!File.Exists(Path.Combine(data,"server-launch-attempt-"+plan.Nonce+".json"))));Require(holder.WaitForExit(10000)&&holder.ExitCode==0);holder.Dispose();holder=null;
   Console.WriteLine(JsonSerializer.Serialize(new{checks,scope="isolated normal-user Windows native policy/source/original-handle creation fixture",installedServer=false,productionHostConnected=false,observeOnlyHelperBreakawayTested=false,interruptedCreateProcessRollbackGuaranteed=false}));return 0;
  }finally{if(holder!=null){try{if(!holder.HasExited){holder.Kill(false);Require(holder.WaitForExit(10000));}}finally{holder.Dispose();}}if(child!=null)child.Dispose();Directory.Delete(root,true);}
 }
 static int Main(string[] args){try{if(!OperatingSystem.IsWindows()){Console.Error.WriteLine("windows_native_owned_cas_not_executed");return 2;}if(args.Length==1&&args[0]=="--fixed-boot-query-phases")return FixedBootQueryPhaseProbe.Run();if(args.Length==0)return Root();if(args.Length==2&&args[0]=="--fixture-holder")return Holder(args[1]);throw new InvalidOperationException("fixture_arguments_required");}catch(Exception error){Console.Error.WriteLine(error is InvalidOperationException?error.Message:"native_owned_fixture_failed");return 1;}}
}
