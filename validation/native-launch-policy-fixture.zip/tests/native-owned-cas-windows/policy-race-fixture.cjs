'use strict';
// Existing JS policy writer against a real native-held lock, on fixture files.
const fs=require('node:fs'),path=require('node:path');
const {createPolicyStore}=require('./server-policy-store-prep');
const dir=path.resolve(process.argv[2]||''),sessionId=process.argv[3];
if(dir!==path.resolve(__dirname,'..','data')||!path.basename(path.dirname(dir)).startsWith('gw native cas ')||!/^S-1-5-5-\d+-\d+:\d+$/.test(sessionId||''))process.exit(51);
const store=createPolicyStore({dir,verifyPrivateDirectory:target=>target===dir});
try{store.transition({event:'manual-stop',currentSessionId:sessionId,expectedRevision:7});process.exit(52)}catch(error){if(error.message!=='policy_busy')process.exit(53);if(store.read().intent!=='running'||store.read().revision!==7)process.exit(54);process.stdout.write('fixture-policy-busy\n')}
