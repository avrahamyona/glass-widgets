// Diagnostic-only, never selected by production Capture. A single cold fixed
// command at the same five-second wait and same original-handle cleanup.
using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32.SafeHandles;
using GlassWidgets.ServerControlPrep;
internal static class FixedBootQueryPhaseProbe {
 const string Entered="GW_BOOT_PHASE_ENTERED",Imported="GW_BOOT_PHASE_IMPORTED",Formatted="GW_BOOT_PHASE_FORMATTED";
 internal sealed class Trace {
  readonly Func<long> now;readonly StringBuilder line=new StringBuilder();int characters,index;
  internal readonly long?[] Marks=new long?[3];
  internal Trace(Func<long> clock){now=clock;}
  internal void Feed(char[] chunk,int count){for(int i=0;i<count;i++){
   if(++characters>8192)throw new InvalidOperationException("native_boot_output_limit");char c=chunk[i];
   if(c=='\n'){string value=line.ToString().TrimEnd('\r');line.Clear();if(value.Length==0)continue;string wanted=index==0?Entered:index==1?Imported:index==2?Formatted:null;
    if(value!=wanted)throw new InvalidOperationException("native_boot_phase_trace_unverified");Marks[index++]=now();
   }else line.Append(c);
  }}
  internal void Finish(){if(line.Length!=0)throw new InvalidOperationException("native_boot_phase_trace_unverified");}
  internal bool Complete=>index==3&&line.Length==0;
 }
 static string InsertBeforeOnce(string source,string needle,string inserted){int at=source.IndexOf(needle,StringComparison.Ordinal);if(at<0||source.IndexOf(needle,at+needle.Length,StringComparison.Ordinal)>=0)throw new InvalidOperationException("native_boot_phase_command_unverified");return source.Substring(0,at)+inserted+source.Substring(at);}
 internal static string Command(){string command=WindowsNativeSessionBinding.FixedBootQueryCommand;
  command=InsertBeforeOnce(command,"Import-Module CimCmdlets", "[Console]::Error.WriteLine('"+Entered+"'); ");
  command=InsertBeforeOnce(command,"$b=(CimCmdlets", "[Console]::Error.WriteLine('"+Imported+"'); ");
  return InsertBeforeOnce(command,"[Console]::Out.WriteLine", "[Console]::Error.WriteLine('"+Formatted+"'); ");
 }
 static async Task<string> Read(StreamReader reader,Trace trace,CancellationToken cancellation){var text=new StringBuilder();var chunk=new char[512];int count;
  while((count=await reader.ReadAsync(chunk.AsMemory(),cancellation))>0){if(text.Length+count>8192)throw new InvalidOperationException("native_boot_output_limit");text.Append(chunk,0,count);if(trace!=null)trace.Feed(chunk,count);}
  if(trace!=null)trace.Finish();return text.ToString();
 }
 [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetSystemDirectoryW(StringBuilder buffer,uint size);
 [DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr process,uint access,out SafeAccessTokenHandle token);
 [DllImport("advapi32.dll",SetLastError=true)] static extern bool GetTokenInformation(SafeAccessTokenHandle token,int info,out uint elevation,uint size,out uint returned);
 internal static void Platform(){if(!OperatingSystem.IsWindows()||!Environment.Is64BitProcess)throw new PlatformNotSupportedException("windows_x64_boot_phase_probe_required");}
 static void NormalToken(){SafeAccessTokenHandle token;if(!OpenProcessToken(GetCurrentProcess(),8,out token)||token==null||token.IsInvalid){if(token!=null)token.Dispose();throw new InvalidOperationException("native_process_token_unverified");}
  using(token){uint elevation,returned;if(!GetTokenInformation(token,20,out elevation,4,out returned)||returned!=4||elevation!=0)throw new InvalidOperationException("normal_user_native_owner_required");}
 }
 internal static int Run(){Platform();if(Environment.Version.ToString()!="10.0.15")throw new InvalidOperationException("phase_probe_pinned_runtime_required");NormalToken();lock(NativeCreationSerialization.Gate){
  var system=new StringBuilder(32768);uint size=GetSystemDirectoryW(system,32768);if(size==0||size>=32768)throw new InvalidOperationException("native_system_directory_unverified");string directory=system.ToString(),root=Path.GetDirectoryName(directory),home=Path.Combine(directory,"WindowsPowerShell","v1.0");
  var info=new ProcessStartInfo(Path.Combine(home,"powershell.exe")){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true,WorkingDirectory=directory};
  foreach(string argument in new[]{"-NoLogo","-NoProfile","-NonInteractive","-Command",Command()})info.ArgumentList.Add(argument);
  info.Environment.Clear();info.Environment["SystemRoot"]=root;info.Environment["WINDIR"]=root;info.Environment["PATH"]=directory;info.Environment["PSModulePath"]=Path.Combine(home,"Modules");
  var elapsed=Stopwatch.StartNew();var trace=new Trace(()=>elapsed.ElapsedMilliseconds);long? startReturnedMs=null;bool success=false;string code=null;
  using(var process=new Process{StartInfo=info}){
   SafeProcessHandle original=null;bool started=false;
   try{
    if(!process.Start())throw new InvalidOperationException("native_boot_query_start_failed");started=true;original=process.SafeHandle;if(original.IsInvalid)throw new InvalidOperationException("native_boot_process_unverified");startReturnedMs=elapsed.ElapsedMilliseconds;
    using(var deadline=new CancellationTokenSource(5000)){
     try{var stdout=Read(process.StandardOutput,null,deadline.Token);var stderr=Read(process.StandardError,trace,deadline.Token);Task.WhenAll(stdout,stderr,process.WaitForExitAsync(deadline.Token)).GetAwaiter().GetResult();
      if(process.ExitCode!=0)throw new InvalidOperationException("native_boot_query_exit_failed");if(!trace.Complete)throw new InvalidOperationException("native_boot_phase_trace_unverified");WindowsNativeSessionBinding.ParseBootMilliseconds(stdout.Result);success=true;
     }catch(Exception error){
      try{if(!process.HasExited){process.Kill(false);if(!process.WaitForExit(5000))throw new InvalidOperationException("native_boot_query_cleanup_unverified");}}
      catch{throw new InvalidOperationException("native_boot_query_cleanup_unverified");}
      code=error is InvalidOperationException&&error.Message=="native_boot_phase_trace_unverified"?"native_boot_phase_trace_unverified":WindowsNativeSessionBinding.BootFailureCode(error);
     }
    }
   }catch(Exception error){code=error is InvalidOperationException&&error.Message=="native_boot_query_cleanup_unverified"?"native_boot_query_cleanup_unverified":"native_boot_query_transport_failed";
    if(started){try{if(original==null||original.IsInvalid||original.IsClosed)throw new InvalidOperationException("native_boot_query_cleanup_unverified");if(!process.HasExited){process.Kill(false);if(!process.WaitForExit(5000))throw new InvalidOperationException("native_boot_query_cleanup_unverified");}}catch{code="native_boot_query_cleanup_unverified";}}
   }
  }
  Console.WriteLine(JsonSerializer.Serialize(new{kind="fixed-boot-query-phase-diagnostic",queryLimitMs=5000,startReturnedMs,enteredMs=trace.Marks[0],importedMs=trace.Marks[1],formattedMs=trace.Marks[2],elapsedIncludingStartAndCleanupMs=elapsed.ElapsedMilliseconds,success,code,traceComplete=trace.Complete,serverStarted=false,acceptanceChecksRun=0,productionCommandChanged=false,diagnosticMarkersAdded=true}));return success?0:1;
 }}
 static void Require(bool value){if(!value)throw new Exception("phase_probe_pure_assertion");}
 static void Refuse(Action action){try{action();}catch(InvalidOperationException){return;}throw new Exception("phase_probe_expected_refusal");}
 internal static int SelfTest(){int checks=0;string command=Command(),original=WindowsNativeSessionBinding.FixedBootQueryCommand;
  foreach(string marker in new[]{Entered,Imported,Formatted}){string inserted="[Console]::Error.WriteLine('"+marker+"'); ";Require(command.Contains(inserted));command=command.Replace(inserted,"");checks++;}Require(command==original);checks++;
  long clock=0;var trace=new Trace(()=>++clock);string packet=Entered+"\r\n"+Imported+"\n"+Formatted+"\n";foreach(char c in packet){var one=new[]{c};trace.Feed(one,1);}trace.Finish();Require(trace.Complete&&trace.Marks[0]==1&&trace.Marks[1]==2&&trace.Marks[2]==3);checks++;
  foreach(string bad in new[]{Imported+"\n",Entered+"\n"+Entered+"\n",Entered+"\n"+Imported+"\n"+Formatted+"\n"+Formatted+"\n","external text\n"}){Refuse(()=>{var item=new Trace(()=>0);char[] chars=bad.ToCharArray();item.Feed(chars,chars.Length);});checks++;}
  Refuse(()=>{var item=new Trace(()=>0);var chars=Entered.ToCharArray();item.Feed(chars,chars.Length);item.Finish();});checks++;
  Refuse(()=>{var item=new Trace(()=>0);var chars=new string('x',8193).ToCharArray();item.Feed(chars,chars.Length);});checks++;
  if(!OperatingSystem.IsWindows()){bool refused=false;try{Platform();}catch(PlatformNotSupportedException){refused=true;}Require(refused);checks++;}
  return checks;
 }
}
