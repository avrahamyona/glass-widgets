# Disposable GitHub-hosted VM only. No installed application or existing account is used.
$ErrorActionPreference = 'Stop'
$source = Join-Path $PSScriptRoot 'bin'
$node = Join-Path $PSScriptRoot 'node.exe'
if (!(Test-Path -LiteralPath (Join-Path $source 'NativeOwnedCasWindows.exe')) -or !(Test-Path -LiteralPath $node)) { throw 'fixture_stage_missing' }
$account = 'gwcas' + [Guid]::NewGuid().ToString('N').Substring(0,12)
$stage = Join-Path $env:SystemDrive ('gw-cas-' + [Guid]::NewGuid().ToString('N'))
$process = $null
$created = $false
try {
  # This password belongs only to a disposable test account on the disposable VM.
  # It is never printed, persisted or used for any user's account.
  $bytes = [System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32)
  $secure = ConvertTo-SecureString ('Aa1!' + [Convert]::ToBase64String($bytes)) -AsPlainText -Force
  [Array]::Clear($bytes,0,$bytes.Length)
  $user = New-LocalUser -Name $account -Password $secure -AccountNeverExpires -UserMayNotChangePassword
  $created = $true
  $users = Get-LocalGroup -SID 'S-1-5-32-545'
  if (!(Get-LocalGroupMember -Group $users.Name | Where-Object SID -eq $user.SID)) { Add-LocalGroupMember -Group $users.Name -Member $user }
  $admins = Get-LocalGroup -SID 'S-1-5-32-544'
  if (Get-LocalGroupMember -Group $admins.Name | Where-Object SID -eq $user.SID) { throw 'disposable_account_must_not_be_admin' }
  New-Item -ItemType Directory -Path $stage | Out-Null
  Copy-Item -LiteralPath $source -Destination (Join-Path $stage 'bin') -Recurse
  Copy-Item -LiteralPath $node -Destination (Join-Path $stage 'node.exe')
  $acl = Get-Acl -LiteralPath $stage
  $acl.AddAccessRule([System.Security.AccessControl.FileSystemAccessRule]::new($user.SID,'ReadAndExecute','ContainerInherit,ObjectInherit','None','Allow'))
  Set-Acl -LiteralPath $stage -AclObject $acl
  $runtime = Split-Path (Get-Command dotnet).Source -Parent
  $wrapper = Join-Path $stage 'run-fixture.ps1'
  @'
$ErrorActionPreference='Stop'
Get-ChildItem Env: | Where-Object Name -match '^(GITHUB_|ACTIONS_|RUNNER_)|TOKEN|SECRET|PASSWORD|NODE_OPTIONS|NODE_PATH' | ForEach-Object { [Environment]::SetEnvironmentVariable($_.Name,$null,'Process') }
$env:DOTNET_ROOT='__RUNTIME__'
$env:DOTNET_MULTILEVEL_LOOKUP='0'
$env:GW_NODE_SOURCE_FIXTURE_PATH=Join-Path $PSScriptRoot 'node.exe'
& (Join-Path $PSScriptRoot 'bin\NativeOwnedCasWindows.exe') '--fixed-boot-query-phases'
exit $LASTEXITCODE
'@.Replace('__RUNTIME__',$runtime.Replace("'","''")) | Set-Content -LiteralPath $wrapper -Encoding utf8
  Start-Service seclogon
  $credential = [PSCredential]::new(($env:COMPUTERNAME+'\'+$account),$secure)
  $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $process = Start-Process -FilePath $powershell -Credential $credential -LoadUserProfile -WorkingDirectory $stage -ArgumentList @('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',('"'+$wrapper+'"')) -RedirectStandardOutput (Join-Path $stage 'stdout.log') -RedirectStandardError (Join-Path $stage 'stderr.log') -PassThru
  if (!$process.WaitForExit(120000)) { $process.Kill(); $process.WaitForExit(); throw 'disposable_fixture_timeout' }
  $process.Refresh()
  foreach ($name in @('stdout.log','stderr.log')) { $file=Join-Path $stage $name; if ((Get-Item -LiteralPath $file).Length -gt 65536) { throw 'fixture_output_limit' }; Get-Content -LiteralPath $file }
  if ($process.ExitCode -ne 0) { throw 'normal_user_fixture_failed' }
  Write-Output 'disposable_non_admin_native_cas_fixture_passed'
} finally {
  if ($null -ne $process) { if (!$process.HasExited) { $process.Kill(); $process.WaitForExit() }; $process.Dispose() }
  if ($created) { Remove-LocalUser -Name $account }
  if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
}
