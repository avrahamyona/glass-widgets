# Targeted read-only boot-query candidate and original normal-user server fixture

This candidate changes only the fixed boot query in the native session library: it requests only LastBootUpTime, then emits that same roundtrip UTC timestamp as a JSON string using Console.Out. It no longer invokes the PowerShell ConvertTo-Json cmdlet for this one fixed timestamp. There is no arbitrary string serialization or output escape rule change.

The native owner/logon/boot session meaning, strict parser, original native process handles, normal-user checks, five-second query limit, output bounds and cleanup rules are unchanged. The optimization is not yet known to fix the observed30-second latency. Pure property/format checks are included, but do not prove Windows behavior.

The temporary timing-only wrapper is removed. This archive returns to the original12-check disposable normal-user acceptance fixture, so its first query is the candidate at the unchanged five-second limit. It does not prewarm the provider using a longer timeout. On failure it stops; on success it may proceed through the original private-job/source/CAS checks. No checkpoint28 or later local integration is included. The public-run outcome must be reported with its exact scope, never as installed or integrated application acceptance.

No installed source/settings, personal data, user PC, main, Release, installer or production composition is changed. This source is test-only and not an application deployment. The source bundle contains the unchanged previous native fixture except the targeted query and two pure parser/command tests.
