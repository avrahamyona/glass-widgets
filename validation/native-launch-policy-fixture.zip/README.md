# Pinned system-module import candidate with one cold phase diagnostic

Prepared22 November2026. Local candidate, not yet published or executed on Windows.

The prior phase diagnostic observed Process.Start return63ms and script entry223ms, then no imported/formatted marker by the unchanged five-second wait. It did not establish the exact cause of the timeout.

Windows PowerShell can reconstruct PSModulePath at startup, adding user/AllUsers locations even when the parent sets the system modules directory. This candidate resets PSModulePath inside the fixed script before any module import, then imports from the fixed CimCmdlets directory under PSHOME. It does not guess a DLL/manifest layout or add a path-discovery cmdlet. Get-CimInstance remains explicitly qualified, local and LastBootUpTime-only. UTC formatting, the strict parser, token/logon identity, output bounds, five-second wait and original-process cleanup are unchanged.

This is a necessary path-selection hardening candidate, not a proven timeout repair. System directory/tool/dependency enrollment is still required. No foreign module or attack was observed. The old claim that the parent environment alone guaranteed system-only lookup was insufficient.

One cold diagnostic selects exactly the same three fixed marker receipt times around the candidate. No warmup, original12 acceptance cases or server start runs. Missing markers alone do not prove a root cause. Total elapsed, Process.Start return and the wait are separate values. Diagnostic JSON labels that native session source changed from the prior fixture; no installed production code changed.

The actual fixed source differs from the prior public fixture only in the native command string, two pure loader-shape checks and the diagnostic marker's fixed match/record label. The metadata-reader hardening, private connectivity/checkpoint29 code and all later integration remain excluded.

Two exact projects must build clean and12 diagnostic plus39 existing/pinning pure checks must pass before publication review. These are not Windows evidence. No personal data, installed configuration/source, main, Release, installer or user PC is included or touched. Publication and one free same-branch Windows test require scoped routing.

Sources:
https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_psmodulepath?view=powershell-7.6
https://github.com/MicrosoftDocs/PowerShell-Docs/blob/main/reference/5.1/Microsoft.PowerShell.Core/About/about_Modules.md
