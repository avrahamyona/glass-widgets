# Native launch policy and disposable Windows acceptance fixture

This is test-only source for a candidate native launch owner. It is not an installer or an installed-server export.

The native owner holds the shared policy CAS lock, records an attempt before creating a suspended child, flushes ownership registration, requires an independently held exact process observation, then resumes the original child. The fixture uses the pinned official Node 20.18.3 executable and its own temporary source and data.

The Windows harness must run under a disposable non-administrator account. It accepts no existing root path or target PID. The provisioner is solely for a fresh GitHub-hosted Windows VM. Build infrastructure creates and removes that test account; the actual native acceptance program rejects elevated tokens.

Proposed checks cover normal-user token capture, held native process identity before resume, shared native/CreateNew and actual Node/wx lock exclusion, flushed attempt and ownership records, filtered Node environment, protected source versus writable data, lock release, creator death and the original child's private job, restored writes, replay refusal and saved Stop refusal.

Limitations: the production stdio/handle-host adapter and production health/listener probe are not connected. The fixture does not establish installed server runtime compatibility, observe-only helper breakaway behavior, or transactional rollback if the creator dies inside CreateProcess. No main branch, Release, installed app, personal configuration or user PC is changed by this fixture.

Portable parser and platform-refusal tests have passed locally. A successful build is not proof of Windows execution. The workflow result, not this source archive, determines Windows acceptance.
