# Fixed boot-query phase diagnostic, one cold read only

This is a diagnostic-only source candidate, not a repair or application deployment. The original five-second wait remains unchanged. No warmup runs and no server acceptance cases run in the selected diagnostic entry point. The production native session source is byte-for-byte unchanged from the targeted-query candidate.

The disposable normal-user wrapper selects a new fixed diagnostic entry point. It launches the same fixed system PowerShell path, arguments and minimal environment. Three fixed stderr markers surround script entry, module import and the existing boot-field query plus UTC formatting. The markers are received and timed by the parent. Actual timestamps, identities, paths, commands and external error text are never emitted into diagnostic output. Only fixed stage names, elapsed counters, success/failure codes and scope flags are emitted. A valid boot value must still pass the original strict JSON parser.

The wait starts after Process.Start returns, just as in the existing native implementation. The record separately reports Start return and total elapsed time including cleanup. These are not a claim that the whole operation has a five-second wall-clock limit. Cleanup is limited to the retained originally created PowerShell process, without tree-kill or PID lookup. Cleanup doubt stays a failure.

A missing marker means only that it was not observed by the deadline. It does not prove precisely where execution was delayed. The imported-to-formatted interval includes the existing CIM query and UTC formatting. Instrumentation has a small unmeasured overhead and is not performance acceptance of the production command.

The original12-case fixture source remains available for review but is not selected by the wrapper. The diagnostic refuses elevation and a runtime other than10.0.15. Twelve pure phase/command checks and the prior37 parser checks can run portably; no Windows execution is established by them.

No latest private integration, checkpoint28, cleanup-receipt or listener changes are included. No installed server/settings, personal data, user PC, main, Release, installer or production composition changes are included. Publication and one Windows run are pending scoped review.
