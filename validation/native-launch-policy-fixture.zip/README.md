# Disposable normal-user boot-query timing experiment

This is a separate timing experiment, not a server acceptance run. The provisioner creates and removes a fresh non-administrator account on the disposable Windows VM. Its wrapper invokes only --boot-timing-only.

The native library and its five-second boot-query bound are unchanged. The test program mechanically copies the exact fixed read-only query setup, minimal environment, strict boot parser, output limits and original-handle cleanup. The first diagnostic invocation has a45-second limit; the second keeps the original five-second limit. Cleanup is separately bounded at five seconds. No other program or server is started by the probe, no acceptance check is run, and no privileges are raised.

Output contains only the fixed probe label, limits, elapsed milliseconds, success/fixed error code, and whether two successful parses yielded the same boot identity. The boot value, paths, raw stderr/stdout, account identifiers and settings are not output. No input root or PID is accepted.

The probe checks its own non-elevated token before and after each successful query. It cannot prove whether slow cold execution is PowerShell startup, CIM loading or the actual query. It can show whether the unchanged five-second call behaves differently after one completed identical query. A passing experiment is not a passing server test.

No checkpoint28/new integration, installed-server source, personal data, main, Release or user-PC change is included. Standard public Windows runner only. Scope remains test-only source on the separate validation branch, pending routing approval before publication.
