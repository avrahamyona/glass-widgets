# Pinned system import with original native CAS acceptance fixture

Prepared22 November2026. Local candidate only, not yet published or run.

The preceding single cold diagnostic completed within five seconds: Process.Start57ms, script entry212ms, import826ms, formatting932ms, total with cleanup1118ms. It ran no server or acceptance cases. A single successful diagnostic on a new runner does not establish the cause of earlier timeouts.

This candidate restores the original12-case disposable normal-user native CAS fixture and its wrapper/project from the prior targeted-query snapshot. All seven native source files are byte-identical to the already-published pinned-import diagnostic. There is no new native behavior. The fixed command resets PSModulePath inside the script and imports the CimCmdlets folder under PSHOME. Same five-second wait, strict UTC parser, boot/logon/token meaning, output bounds and original-process cleanup. No warmup or phase markers remain.

The original fixture tests suspended owned creation, independent acknowledgement, source protection and saved policy/CAS/refusal behavior against a pinned dummy Node runtime. It is not the installed server, new private connectivity/owner wire, checkpoint29/30, complete source registry, production root or installation. Even all12 passing would accept only this focused component fixture, not the complete backend or a real chat answer.

Pure pinning tests remain. The phase-only helper and its separate12 pure phase checks are removed. Two exact projects and39 binding/parser/pinning checks must pass locally before routing for any public run. The workflow remains a free standard Windows runner in a public repository, exact reviewed commit/manual dispatch only, same dedicated validation branch. No main, Release, personal data or user PC is involved. No additional publication or run is inferred from the previous diagnostic.
