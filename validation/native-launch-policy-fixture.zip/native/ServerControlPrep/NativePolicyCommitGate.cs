// Private integration core. Shared on-disk CAS and durable per-operation attempt
// barrier only. Not a fixed launch host or a Windows directory/session verifier.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
namespace GlassWidgets.ServerControlPrep {
 internal sealed class NativeStartOperation {
  internal readonly string Nonce,ControllerId,Event,InstallationId,PersistedSessionId;
  internal NativeStartOperation(string nonce,string controllerId,string action,string installationId,string persistedSessionId){
   if(!NativePolicyCommitGate.Uuid(nonce)||!NativePolicyCommitGate.Uuid(controllerId)||!new[]{"manual-start","app-open","recover","windows-logon"}.Contains(action)||!NativePolicyCommitGate.Identifier(installationId)||!NativePolicyCommitGate.Session(persistedSessionId))throw new InvalidOperationException("native_start_operation_required");
   Nonce=nonce;ControllerId=controllerId;Event=action;InstallationId=installationId;PersistedSessionId=persistedSessionId;
  }
 }
 internal sealed class NativeStartCommitContext {
  internal readonly string SessionId,SourceManifestHash;internal readonly long Revision;internal readonly NativeStartOperation Operation;
  internal NativeStartCommitContext(string sessionId,long revision,string sourceManifestHash,NativeStartOperation operation){
   if(!NativePolicyCommitGate.Session(sessionId)||revision<0||revision>=9007199254740991L||sourceManifestHash==null||!Regex.IsMatch(sourceManifestHash,"^[a-f0-9]{64}$",RegexOptions.CultureInvariant)||operation==null)throw new InvalidOperationException("native_start_context_required");
   SessionId=sessionId;Revision=revision;SourceManifestHash=sourceManifestHash;Operation=new NativeStartOperation(operation.Nonce,operation.ControllerId,operation.Event,operation.InstallationId,operation.PersistedSessionId);
  }
 }
 internal sealed class NativePolicyCommitGate {
  internal const string Scope="shared-policy-cas-and-attempt-barrier-not-fixed-native-launch-host";
  const string Policy="login-start-manual-stop-until-next-login-v1";
  readonly string directory,policyFile,lockFile,operationFile;
  readonly Func<string,IDisposable> holdVerifiedPrivateDirectory;
  readonly Func<FileStream,string,bool> verifyBoundOpenedFile;
  readonly Func<string,bool> verifyCurrentSession;
  readonly Func<string,CancellationToken,bool> verifyHeldSource;
  bool busy,uncertain;readonly object gate=new object();
  internal static bool Uuid(string value)=>value!=null&&Guid.TryParseExact(value,"D",out _)&&value==value.ToLowerInvariant();
  internal static bool Session(string value)=>value!=null&&Regex.IsMatch(value,"^[A-Za-z0-9_.:-]{1,160}$",RegexOptions.CultureInvariant);
  internal static bool Identifier(string value)=>value!=null&&value.Length>0&&value.Length<=160&&!value.Any(Char.IsControl);
  internal NativePolicyCommitGate(string directory,Func<string,IDisposable> holdVerifiedPrivateDirectory,Func<FileStream,string,bool> verifyBoundOpenedFile,Func<string,bool> verifyCurrentSession,Func<string,CancellationToken,bool> verifyHeldSource){
   if(String.IsNullOrEmpty(directory)||!Path.IsPathFullyQualified(directory)||holdVerifiedPrivateDirectory==null||verifyBoundOpenedFile==null||verifyCurrentSession==null||verifyHeldSource==null)throw new InvalidOperationException("native_policy_capabilities_required");
   this.directory=Path.GetFullPath(directory);this.holdVerifiedPrivateDirectory=holdVerifiedPrivateDirectory;this.verifyBoundOpenedFile=verifyBoundOpenedFile;this.verifyCurrentSession=verifyCurrentSession;this.verifyHeldSource=verifyHeldSource;
   policyFile=Path.Combine(this.directory,"server-intent-v1.json");lockFile=Path.Combine(this.directory,"server-intent-v1.lock");operationFile=Path.Combine(this.directory,"server-operation-v1.json");
  }
  static void ExactKeys(JsonElement value,params string[] keys){
   if(value.ValueKind!=JsonValueKind.Object)throw new InvalidOperationException("native_policy_document_unverified");var seen=new HashSet<string>(StringComparer.Ordinal);
   foreach(var entry in value.EnumerateObject())if(!seen.Add(entry.Name)||!keys.Contains(entry.Name,StringComparer.Ordinal))throw new InvalidOperationException("native_policy_document_unverified");
   if(seen.Count!=keys.Length)throw new InvalidOperationException("native_policy_document_unverified");
  }
  static string Text(JsonElement value,string key){var field=value.GetProperty(key);if(field.ValueKind!=JsonValueKind.String)throw new InvalidOperationException("native_policy_document_unverified");return field.GetString();}
  static long Number(JsonElement value,string key){var field=value.GetProperty(key);long result;if(field.ValueKind!=JsonValueKind.Number||!field.TryGetInt64(out result))throw new InvalidOperationException("native_policy_document_unverified");return result;}
  JsonDocument ReadBound(string file,int limit){
   FileStream stream=null;try{
    stream=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.Read,4096,FileOptions.SequentialScan);
    if(!verifyBoundOpenedFile(stream,file)||stream.Length<2||stream.Length>limit)throw new InvalidOperationException("native_policy_file_unverified");
    var bytes=new byte[checked((int)stream.Length)];stream.ReadExactly(bytes);if(stream.ReadByte()!=-1||!verifyBoundOpenedFile(stream,file))throw new InvalidOperationException("native_policy_file_unverified");
    return JsonDocument.Parse(bytes,new JsonDocumentOptions{AllowTrailingCommas=false,CommentHandling=JsonCommentHandling.Disallow,MaxDepth=8});
   }catch(JsonException){throw new InvalidOperationException("native_policy_document_unverified");}finally{if(stream!=null)stream.Dispose();}
  }
  void Revalidate(NativeStartCommitContext context){
   using(var document=ReadBound(policyFile,4096)){var value=document.RootElement;ExactKeys(value,"version","policy","sessionId","intent","revision");if(Number(value,"version")!=1||Text(value,"policy")!=Policy||Text(value,"sessionId")!=context.SessionId||Text(value,"intent")!="running"||Number(value,"revision")!=context.Revision)throw new InvalidOperationException("native_running_intent_changed");}
   using(var document=ReadBound(operationFile,2048)){var value=document.RootElement;ExactKeys(value,"version","nonce","controllerId","event","installationId","persistedSessionId");var operation=context.Operation;if(Number(value,"version")!=1||Text(value,"nonce")!=operation.Nonce||Text(value,"controllerId")!=operation.ControllerId||Text(value,"event")!=operation.Event||Text(value,"installationId")!=operation.InstallationId||Text(value,"persistedSessionId")!=operation.PersistedSessionId)throw new InvalidOperationException("native_operation_token_changed");}
   if(!verifyCurrentSession(context.SessionId))throw new InvalidOperationException("native_logon_session_changed");
  }
  static bool AsyncResult(Type type)=>typeof(Task).IsAssignableFrom(type)||type==typeof(ValueTask)||(type.IsGenericType&&type.GetGenericTypeDefinition()==typeof(ValueTask<>));
  internal T Commit<T>(NativeStartCommitContext context,Func<NativeStartCommitContext,T> createOwnedSynchronously,CancellationToken cancellation){
   if(context==null||createOwnedSynchronously==null||AsyncResult(typeof(T))||createOwnedSynchronously.Method.GetCustomAttribute<AsyncStateMachineAttribute>()!=null)throw new InvalidOperationException("synchronous_native_creation_required");
   lock(gate){if(busy||uncertain)throw new InvalidOperationException("native_commit_requires_reconciliation");busy=true;}
   FileStream policyLock=null;IDisposable binding=null;bool lockCreated=false,attemptCreated=false;
   try{
    cancellation.ThrowIfCancellationRequested();binding=holdVerifiedPrivateDirectory(directory);if(binding==null)throw new InvalidOperationException("native_private_directory_unverified");
    // Same path and CreateNew operation as the existing JavaScript wx lock.
    // No stale-lock deletion, waiting loop or fallback lock namespace is allowed.
    try{policyLock=new FileStream(lockFile,FileMode.CreateNew,FileAccess.ReadWrite,FileShare.Read,4096,FileOptions.WriteThrough);lockCreated=true;}catch(IOException){throw new InvalidOperationException("native_policy_lock_unavailable");}
    if(!verifyBoundOpenedFile(policyLock,lockFile))throw new InvalidOperationException("native_policy_lock_unverified");
    cancellation.ThrowIfCancellationRequested();Revalidate(context);
    if(!verifyHeldSource(context.SourceManifestHash,cancellation))throw new InvalidOperationException("native_source_owner_unverified");
    // Detect even an out-of-contract mutation by a verification capability before
    // creation; legitimate Stop writers are already excluded by the shared lock.
    cancellation.ThrowIfCancellationRequested();Revalidate(context);
    string attemptFile=Path.Combine(directory,"server-launch-attempt-"+context.Operation.Nonce+".json");
    FileStream attemptStream;try{attemptStream=new FileStream(attemptFile,FileMode.CreateNew,FileAccess.Write,FileShare.Read,4096,FileOptions.WriteThrough);attemptCreated=true;}catch(IOException){lock(gate)uncertain=true;throw new InvalidOperationException("native_start_attempt_already_exists_or_unavailable");}
    using(var attempt=attemptStream){
     if(!verifyBoundOpenedFile(attempt,attemptFile))throw new InvalidOperationException("native_attempt_file_unverified");
     byte[] bytes=JsonSerializer.SerializeToUtf8Bytes(new {version=1,phase="attempted-not-completed",operationNonce=context.Operation.Nonce,controllerId=context.Operation.ControllerId,installationId=context.Operation.InstallationId,sessionId=context.SessionId,revision=context.Revision,sourceManifestHash=context.SourceManifestHash});attempt.Write(bytes);attempt.Flush(true);
    }
    cancellation.ThrowIfCancellationRequested();
    // The fixed native owner must create/record/resume synchronously here. It must
    // preserve original handles and uncertain cleanup ownership. This core does
    // not supply a process launcher and never treats a marker as a successful start.
    T result=createOwnedSynchronously(context);if(result!=null&&AsyncResult(result.GetType()))throw new InvalidOperationException("synchronous_native_creation_required");return result;
   }catch{if(attemptCreated)lock(gate)uncertain=true;throw;}
   finally{
    try{
     if(policyLock!=null){bool original=false;try{original=verifyBoundOpenedFile(policyLock,lockFile);}finally{policyLock.Dispose();policyLock=null;}if(lockCreated&&original)File.Delete(lockFile);else if(lockCreated){lock(gate)uncertain=true;throw new InvalidOperationException("native_policy_lock_cleanup_unverified");}}
    }catch{lock(gate)uncertain=true;throw;}
    finally{try{if(binding!=null)binding.Dispose();}catch{lock(gate)uncertain=true;throw;}finally{lock(gate)busy=false;}}
   }
  }
  internal bool RequiresReconciliation {get{lock(gate)return uncertain;}}
 }
}
