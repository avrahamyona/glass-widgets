// Private integration preparation. Pure fail-closed parsing of a self-relative
// owner/DACL descriptor. Not an OS ACL or private-directory execution proof.
using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Globalization;
namespace GlassWidgets.ServerControlPrep {
 internal static class NativePrivateDescriptor {
  static ushort U16(byte[] bytes,int offset){Bounds(bytes,offset,2);return BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(offset,2));}
  static uint U32(byte[] bytes,int offset){Bounds(bytes,offset,4);return BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(offset,4));}
  static void Bounds(byte[] bytes,int offset,int count){if(bytes==null||offset<0||count<0||offset>bytes.Length-count)throw new InvalidOperationException("native_security_descriptor_unverified");}
  static string Sid(byte[] bytes,int offset,int end,out int size){
   Bounds(bytes,offset,8);int count=bytes[offset+1];size=checked(8+4*count);if(bytes[offset]!=1||count>15||offset+size>end)throw new InvalidOperationException("native_security_sid_unverified");Bounds(bytes,offset,size);
   ulong authority=0;for(int i=2;i<8;i++)authority=(authority<<8)|bytes[offset+i];var text="S-1-"+authority.ToString(CultureInfo.InvariantCulture);
   for(int i=0;i<count;i++)text+="-"+U32(bytes,offset+8+i*4).ToString(CultureInfo.InvariantCulture);return text;
  }
  internal static bool IsPrivate(byte[] descriptor,string ownerSid,string logonSid){
   try{
    if(descriptor==null||descriptor.Length<20||descriptor.Length>65536||String.IsNullOrEmpty(ownerSid)||String.IsNullOrEmpty(logonSid)||descriptor[0]!=1)return false;
    ushort control=U16(descriptor,2);if((control&0x8004)!=0x8004)return false;
    uint rawOwner=U32(descriptor,4),rawDacl=U32(descriptor,16);if(rawOwner<20||rawDacl<20||rawOwner%4!=0||rawDacl%4!=0||rawOwner>65535||rawDacl>65535)return false;
    int ownerBytes;if(Sid(descriptor,(int)rawOwner,descriptor.Length,out ownerBytes)!=ownerSid)return false;
    int dacl=(int)rawDacl;Bounds(descriptor,dacl,8);if(descriptor[dacl]!=2||descriptor[dacl+1]!=0||U16(descriptor,dacl+6)!=0)return false;
    int aclSize=U16(descriptor,dacl+2),count=U16(descriptor,dacl+4);if(aclSize<8||count>1024)return false;Bounds(descriptor,dacl,aclSize);
    var trusted=new HashSet<string>(StringComparer.Ordinal){ownerSid,logonSid,"S-1-5-18","S-1-5-32-544"};int cursor=dacl+8,end=dacl+aclSize;
    for(int i=0;i<count;i++){
     if(cursor>end-8)return false;int kind=descriptor[cursor],flags=descriptor[cursor+1],size=U16(descriptor,cursor+2);if((kind!=0&&kind!=1)||(flags&~0x1f)!=0||size<16||size%4!=0||cursor>end-size)return false;
     int sidBytes;string sid=Sid(descriptor,cursor+8,cursor+size,out sidBytes);if(sidBytes+8!=size)return false;
     // Inherit-only ACEs can affect future JS-created policy files. Do not
     // ignore an untrusted grant merely because it is inherit-only here.
     bool creatorOwnerInheritOnly=sid=="S-1-3-0"&&(flags&8)!=0;
     if(kind==0&&!trusted.Contains(sid)&&!creatorOwnerInheritOnly)return false;
     cursor+=size;
    }
    // An unused ACL allocation tail is permitted only when zero-filled.
    for(int i=cursor;i<end;i++)if(descriptor[i]!=0)return false;return true;
   }catch(InvalidOperationException){return false;}catch(OverflowException){return false;}catch(ArgumentOutOfRangeException){return false;}
  }
 }
}
