// Private native creation candidate. Not exposed by ServerControlHost.
// The fixed owner must retain this frame, register ownership before Resume, and
// reconcile every uncertain frame. No arbitrary command, PID lookup or tree kill.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Microsoft.Win32.SafeHandles;
namespace GlassWidgets.ServerControlPrep {
 internal sealed class NativeCreationHandle:SafeHandleZeroOrMinusOneIsInvalid {
  internal NativeCreationHandle():base(true){}
  internal NativeCreationHandle(IntPtr value):base(true){SetHandle(value);}
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
  protected override bool ReleaseHandle()=>CloseHandle(handle);
 }
 internal sealed class NativeServerLaunchDefinition {
  internal readonly HeldSourceFiles Sources;internal readonly string Runtime,Entry,SourceRoot,ConfigFile,DefinitionHash;readonly KeyValuePair<string,string>[] flags;
  internal NativeServerLaunchDefinition(HeldSourceFiles sources,string runtime,string entry,string sourceRoot,string config,IEnumerable<KeyValuePair<string,string>> flags){
   if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException("windows_native_launch_required");
   if(sources==null||flags==null)throw new InvalidOperationException("fixed_native_launch_definition_required");
   foreach(string value in new[]{runtime,entry,sourceRoot,config})HeldSourceFiles.ValidateAndCopy(new[]{new SourceFileSpec(value,1,new string('a',64))});
   Runtime=Path.GetFullPath(runtime);Entry=Path.GetFullPath(entry);SourceRoot=Path.GetFullPath(sourceRoot).TrimEnd('\\');ConfigFile=Path.GetFullPath(config);Sources=sources;
   if(!Entry.StartsWith(SourceRoot+"\\",StringComparison.OrdinalIgnoreCase)||!sources.IncludesReviewedFile(Runtime)||!sources.IncludesReviewedFile(Entry)||sources.IncludesReviewedFile(ConfigFile))throw new InvalidOperationException("fixed_held_entry_and_runtime_required");
   this.flags=ValidateFlags(flags);DefinitionHash=Convert.ToHexString(SHA256.HashData(System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(new{version=1,runtime=Runtime,entry=Entry,sourceRoot=SourceRoot,configFile=ConfigFile,sourceManifestHash=Sources.ManifestHash,environment=this.flags}))).ToLowerInvariant();
  }
  internal static KeyValuePair<string,string>[] ValidateFlags(IEnumerable<KeyValuePair<string,string>> input){
   if(input==null)throw new InvalidOperationException("fixed_native_environment_required");var result=new List<KeyValuePair<string,string>>();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
   foreach(var item in input){if(result.Count>=5||!seen.Add(item.Key??""))throw new InvalidOperationException("fixed_native_environment_required");bool port=item.Key=="GW_CHAT_LAN_PORT";int number;if(!(port?item.Value!=null&&System.Text.RegularExpressions.Regex.IsMatch(item.Value,"^[1-9][0-9]{0,4}$",System.Text.RegularExpressions.RegexOptions.CultureInvariant)&&Int32.TryParse(item.Value,out number)&&number<=65535:new[]{"GW_TUNNEL","GW_MAILER","GW_SERVER_STRICT_ENVELOPES","GW_CHAT_LAN"}.Contains(item.Key)&&(item.Value=="0"||item.Value=="1")))throw new InvalidOperationException("nonsecret_fixed_native_flags_required");result.Add(item);}
   return result.OrderBy(x=>x.Key,StringComparer.Ordinal).ToArray();
  }
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetSystemDirectoryW(StringBuilder value,uint size);
  internal byte[] EnvironmentBlock(){
   var value=new StringBuilder(32768);uint length=GetSystemDirectoryW(value,32768);if(length==0||length>=32768)throw new InvalidOperationException("native_system_directory_unverified");string system=value.ToString(),root=Path.GetDirectoryName(system),local=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
   var map=new SortedDictionary<string,string>(StringComparer.OrdinalIgnoreCase){{"SystemRoot",root},{"WINDIR",root},{"PATH",system},{"USERPROFILE",Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)},{"APPDATA",Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)},{"LOCALAPPDATA",local},{"TEMP",Path.Combine(local,"Temp")},{"TMP",Path.Combine(local,"Temp")},{"GW_SERVER_CONFIG",ConfigFile}};
   foreach(var flag in flags)map.Add(flag.Key,flag.Value);var text=new StringBuilder();foreach(var item in map){if(String.IsNullOrEmpty(item.Value)||item.Key.IndexOfAny(new[]{'=','\0'})>=0||item.Value.IndexOf('\0')>=0)throw new InvalidOperationException("native_environment_unverified");text.Append(item.Key).Append('=').Append(item.Value).Append('\0');}text.Append('\0');if(text.Length>32767)throw new InvalidOperationException("native_environment_limit");return Encoding.Unicode.GetBytes(text.ToString());
  }
 }
 internal sealed class NativeOwnedProcessIdentity {
  public uint Pid {get;}
  public string NativeCreatedFileTimeUtc {get;}
  public string Exe {get;}
  public string OwnerSid {get;}
  public string LogonSid {get;}
  public string SessionId {get;}
  public string CommandHash {get;}
  public string CreatedAt {get;}
  internal NativeOwnedProcessIdentity(uint pid,long birth,string image,WindowsNativeSessionBinding session,string commandHash){Pid=pid;NativeCreatedFileTimeUtc=birth.ToString(CultureInfo.InvariantCulture);Exe=image;OwnerSid=session.OwnerSid;LogonSid=session.LogonSid;SessionId=session.SessionId;CommandHash=commandHash;CreatedAt=DateTime.FromFileTimeUtc(birth).ToString("o",CultureInfo.InvariantCulture);}
 }
 internal sealed class NativeOwnedCreationFrame {
  internal const string Scope="original-handle-suspended-creation-job-and-source-candidate-not-windows-accepted";
  readonly object sync=new object();NativeCreationHandle process,thread,job;bool creationCalled,creationReturned,handlesKnown,identityCaptured,resumed,registrationBound,terminationRequested,closed,uncertain;
  uint pid;long birth;string image,commandHash;int sealedSources;
  internal readonly string OperationNonce,SourceManifestHash;
  [StructLayout(LayoutKind.Sequential)] struct JobBasicLimits {internal long ProcessTime,JobTime;internal uint Flags;internal UIntPtr MinimumWorkingSet,MaximumWorkingSet;internal uint ActiveProcessLimit;internal UIntPtr Affinity;internal uint PriorityClass,SchedulingClass;}
  [StructLayout(LayoutKind.Sequential)] struct IoCounters {internal ulong ReadOperations,WriteOperations,OtherOperations,ReadBytes,WriteBytes,OtherBytes;}
  [StructLayout(LayoutKind.Sequential)] struct JobExtendedLimits {internal JobBasicLimits Basic;internal IoCounters Io;internal UIntPtr ProcessMemory,JobMemory,PeakProcessMemory,PeakJobMemory;}
  [StructLayout(LayoutKind.Sequential)] struct JobAccounting {internal long UserTime,KernelTime,PeriodUserTime,PeriodKernelTime;internal uint PageFaults,TotalProcesses,ActiveProcesses,TerminatedProcesses;}
  [StructLayout(LayoutKind.Sequential)] struct StartupInfo {internal uint Cb;internal IntPtr Reserved,Desktop,Title;internal uint X,Y,XSize,YSize,XCount,YCount,Fill,Flags;internal ushort Show,ReservedBytes;internal IntPtr ReservedData,Input,Output,Error;}
  [StructLayout(LayoutKind.Sequential)] struct StartupInfoEx {internal StartupInfo Startup;internal IntPtr Attributes;}
  [StructLayout(LayoutKind.Sequential)] struct ProcessInformation {internal IntPtr Process,Thread;internal uint Pid,Tid;}
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern NativeCreationHandle CreateJobObjectW(IntPtr attributes,string name);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetInformationJobObject(NativeCreationHandle job,int type,ref JobExtendedLimits info,uint length);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool QueryInformationJobObject(NativeCreationHandle job,int type,out JobAccounting info,uint length,out uint returned);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool IsProcessInJob(NativeCreationHandle process,NativeCreationHandle job,out bool result);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateJobObject(NativeCreationHandle job,uint exitCode);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool InitializeProcThreadAttributeList(IntPtr list,int count,uint flags,ref UIntPtr size);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool UpdateProcThreadAttribute(IntPtr list,uint flags,UIntPtr attribute,IntPtr value,UIntPtr bytes,IntPtr previous,IntPtr returned);
  [DllImport("kernel32.dll")] static extern void DeleteProcThreadAttributeList(IntPtr list);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CreateProcessW(string image,StringBuilder command,IntPtr processAttributes,IntPtr threadAttributes,bool inherit,uint flags,IntPtr environment,string directory,ref StartupInfoEx startup,out ProcessInformation information);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern SafeFileHandle CreateFileW(string path,uint access,uint share,IntPtr security,uint disposition,uint flags,IntPtr template);
  [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool DuplicateHandle(IntPtr sourceProcess,SafeHandle source,IntPtr targetProcess,out NativeCreationHandle target,uint access,bool inherit,uint options);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool DuplicateHandle(NativeCreationHandle sourceProcess,IntPtr source,NativeCreationHandle targetProcess,out IntPtr target,uint access,bool inherit,uint options);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool DuplicateHandle(IntPtr sourceProcess,IntPtr source,IntPtr targetProcess,out NativeCreationHandle target,uint access,bool inherit,uint options);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr GetCommandLineW();
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetHandleInformation(SafeHandle handle,out uint flags);
  [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetProcessId(NativeCreationHandle process);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(NativeCreationHandle process,out long created,out long exit,out long kernel,out long user);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageNameW(NativeCreationHandle process,uint flags,StringBuilder image,ref uint length);
  [DllImport("kernel32.dll",SetLastError=true)] static extern uint ResumeThread(NativeCreationHandle thread);
  [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(NativeCreationHandle process,uint milliseconds);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateProcess(NativeCreationHandle process,uint exitCode);
  NativeOwnedCreationFrame(string nonce,string manifest){OperationNonce=nonce;SourceManifestHash=manifest;}
  internal static string Quote(string value){if(value==null||value.Length>4096||value.IndexOfAny(new[]{'\0','\r','\n'})>=0)throw new InvalidOperationException("fixed_native_argument_required");var text=new StringBuilder("\"");int slashes=0;foreach(char c in value){if(c=='\\'){slashes++;continue;}if(c=='\"'){text.Append('\\',slashes*2+1).Append(c);slashes=0;continue;}text.Append('\\',slashes).Append(c);slashes=0;}return text.Append('\\',slashes*2).Append('"').ToString();}
  // Ownership is taken before even the job is created, so every later failure
  // leaves a retained reconciliation frame. The callback is fixed owner code.
  internal static NativeOwnedCreationFrame CreateSuspended(NativeServerLaunchDefinition definition,NativeStartCommitContext context,WindowsNativeSessionBinding session,Action<NativeOwnedCreationFrame> retainBeforeCreation,CancellationToken cancellation){
   if(!OperatingSystem.IsWindows()||!Environment.Is64BitProcess)throw new PlatformNotSupportedException("windows_x64_owned_creation_required");
   if(definition==null||context==null||session==null||!session.VerifyCurrentSession(context.SessionId)||retainBeforeCreation==null||definition.Sources.ManifestHash!=context.SourceManifestHash)throw new InvalidOperationException("bound_native_creation_required");
   var frame=new NativeOwnedCreationFrame(context.Operation.Nonce,context.SourceManifestHash);retainBeforeCreation(frame);
   try{frame.Create(definition,session,cancellation);return frame;}catch{lock(frame.sync)frame.uncertain=true;throw;}
  }
  void Create(NativeServerLaunchDefinition definition,WindowsNativeSessionBinding session,CancellationToken cancellation){lock(sync)lock(NativeCreationSerialization.Gate){
   cancellation.ThrowIfCancellationRequested();job=CreateJobObjectW(IntPtr.Zero,null);uint jobFlags;if(job==null||job.IsInvalid||!GetHandleInformation(job,out jobFlags)||(jobFlags&1)!=0)throw new InvalidOperationException("private_native_job_unverified");
   // One explicitly assigned child only. Descendants break away instead of
   // becoming blanket job-tree kill targets. Nested-job behavior needs Windows
   // acceptance. The job is unnamed, non-inheritable and not copied to the child.
   var limits=new JobExtendedLimits();limits.Basic.Flags=0x00002000|0x00001000|0x00000008;limits.Basic.ActiveProcessLimit=1;
   if(!SetInformationJobObject(job,9,ref limits,(uint)Marshal.SizeOf<JobExtendedLimits>()))throw new InvalidOperationException("native_creation_job_limit_unverified");
   definition.Sources.WithInheritableDuplicates(definition.Runtime,sourceHandles=>{
    IntPtr list=IntPtr.Zero,handleValues=IntPtr.Zero,jobValue=IntPtr.Zero,environment=IntPtr.Zero;bool initialized=false;
    using(var nullHandle=CreateFileW("NUL",0xc0000000,3,IntPtr.Zero,3,0x80,IntPtr.Zero)){
     if(nullHandle.IsInvalid)throw new InvalidOperationException("native_null_stdio_unverified");NativeCreationHandle nullCopy;if(!DuplicateHandle(GetCurrentProcess(),nullHandle,GetCurrentProcess(),out nullCopy,0,true,2)){if(nullCopy!=null)nullCopy.Dispose();throw new InvalidOperationException("native_stdio_copy_unverified");}
     using(nullCopy)try{
      var handles=sourceHandles.Cast<SafeHandle>().Concat(new SafeHandle[]{nullCopy}).ToArray();foreach(var handle in handles){uint flags;if(!GetHandleInformation(handle,out flags)||(flags&1)==0)throw new InvalidOperationException("native_inheritability_unverified");}
      UIntPtr bytes=UIntPtr.Zero;bool unexpected=InitializeProcThreadAttributeList(IntPtr.Zero,2,0,ref bytes);if(unexpected||Marshal.GetLastWin32Error()!=122||bytes.ToUInt64()==0||bytes.ToUInt64()>1048576)throw new InvalidOperationException("native_attribute_size_unverified");list=Marshal.AllocHGlobal(checked((int)bytes.ToUInt64()));if(!InitializeProcThreadAttributeList(list,2,0,ref bytes))throw new InvalidOperationException("native_attribute_list_unverified");initialized=true;
      handleValues=Marshal.AllocHGlobal(handles.Length*IntPtr.Size);for(int i=0;i<handles.Length;i++)Marshal.WriteIntPtr(handleValues,i*IntPtr.Size,handles[i].DangerousGetHandle());
      if(!UpdateProcThreadAttribute(list,0,(UIntPtr)0x00020002,handleValues,(UIntPtr)(uint)(handles.Length*IntPtr.Size),IntPtr.Zero,IntPtr.Zero))throw new InvalidOperationException("native_handle_list_unverified");
      jobValue=Marshal.AllocHGlobal(IntPtr.Size);Marshal.WriteIntPtr(jobValue,job.DangerousGetHandle());if(!UpdateProcThreadAttribute(list,0,(UIntPtr)0x0002000d,jobValue,(UIntPtr)(uint)IntPtr.Size,IntPtr.Zero,IntPtr.Zero))throw new InvalidOperationException("native_creation_job_list_unverified");
      byte[] block=definition.EnvironmentBlock();environment=Marshal.AllocHGlobal(block.Length);Marshal.Copy(block,0,environment,block.Length);
      var startup=new StartupInfoEx();startup.Startup.Cb=(uint)Marshal.SizeOf<StartupInfoEx>();startup.Startup.Flags=0x100;startup.Startup.Input=nullCopy.DangerousGetHandle();startup.Startup.Output=startup.Startup.Input;startup.Startup.Error=startup.Startup.Input;startup.Attributes=list;
      string command=String.Join(" ",new[]{definition.Runtime,"--",definition.Entry}.Select(Quote));if(command.Length>30000)throw new InvalidOperationException("fixed_native_command_limit");commandHash=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(command))).ToLowerInvariant();cancellation.ThrowIfCancellationRequested();creationCalled=true;ProcessInformation result;
      bool created=CreateProcessW(definition.Runtime,new StringBuilder(command),IntPtr.Zero,IntPtr.Zero,true,0x00080000|0x00000004|0x08000000|0x00000400,environment,definition.SourceRoot,ref startup,out result);creationReturned=true;
      if(!created)throw new InvalidOperationException("native_owned_creation_failed");
      // Store original handles before the first metadata call. No PID reopen.
      process=new NativeCreationHandle(result.Process);thread=new NativeCreationHandle(result.Thread);pid=result.Pid;handlesKnown=true;image=definition.Runtime;
      long capturedBirth,exit,kernel,user;if(pid==0||GetProcessId(process)!=pid||!GetProcessTimes(process,out capturedBirth,out exit,out kernel,out user)||capturedBirth<=0)throw new InvalidOperationException("native_created_identity_unverified");birth=capturedBirth;identityCaptured=true;
      InspectIdentity();if(!session.VerifyOwnedProcessToken(process))throw new InvalidOperationException("native_created_owner_or_logon_changed");bool member;if(!IsProcessInJob(process,job,out member)||!member||ActiveJobProcesses()!=1)throw new InvalidOperationException("native_created_job_unverified");
      foreach(var source in sourceHandles){IntPtr replacement;if(!DuplicateHandle(process,source.DangerousGetHandle(),process,out replacement,0,false,3)||replacement==IntPtr.Zero||replacement==new IntPtr(-1))throw new InvalidOperationException("native_source_seal_unverified");sealedSources++;}
      cancellation.ThrowIfCancellationRequested();return true;
     }finally{if(initialized)DeleteProcThreadAttributeList(list);if(list!=IntPtr.Zero)Marshal.FreeHGlobal(list);if(handleValues!=IntPtr.Zero)Marshal.FreeHGlobal(handleValues);if(jobValue!=IntPtr.Zero)Marshal.FreeHGlobal(jobValue);if(environment!=IntPtr.Zero)Marshal.FreeHGlobal(environment);}
    }
   },cancellation);
  }}
  void InspectIdentity(){long actual,exit,kernel,user;if(!handlesKnown||!identityCaptured||GetProcessId(process)!=pid||!GetProcessTimes(process,out actual,out exit,out kernel,out user)||actual!=birth)throw new InvalidOperationException("native_original_process_changed");var path=new StringBuilder(32768);uint length=32768;if(!QueryFullProcessImageNameW(process,0,path,ref length)||!String.Equals(path.ToString(),image,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("native_created_image_changed");}
  uint ActiveJobProcesses(){JobAccounting info;uint returned;if(job==null||job.IsInvalid||!QueryInformationJobObject(job,1,out info,(uint)Marshal.SizeOf<JobAccounting>(),out returned)||returned!=Marshal.SizeOf<JobAccounting>()||info.ActiveProcesses>1)throw new InvalidOperationException("native_creation_job_state_unverified");return info.ActiveProcesses;}
  internal NativeOwnedProcessIdentity Identity(WindowsNativeSessionBinding session){lock(sync){if(closed||uncertain)throw new InvalidOperationException("native_created_identity_unverified");InspectIdentity();if(!session.VerifyOwnedProcessToken(process))throw new InvalidOperationException("native_created_token_changed");return new NativeOwnedProcessIdentity(pid,birth,image,session,commandHash);}}
  internal static NativeOwnedProcessIdentity CaptureCreationAuthority(WindowsNativeSessionBinding session){
   if(!OperatingSystem.IsWindows()||session==null||!session.VerifyCurrentSession(session.SessionId))throw new InvalidOperationException("native_creation_authority_unverified");NativeCreationHandle handle;if(!DuplicateHandle(GetCurrentProcess(),GetCurrentProcess(),GetCurrentProcess(),out handle,0x00101000,false,0)){if(handle!=null)handle.Dispose();throw new InvalidOperationException("native_creation_authority_handle_unverified");}
   using(handle){uint id=GetProcessId(handle);long created,exit,kernel,user;var image=new StringBuilder(32768);uint length=32768;string command=Marshal.PtrToStringUni(GetCommandLineW());if(id==0||!GetProcessTimes(handle,out created,out exit,out kernel,out user)||created<=0||!QueryFullProcessImageNameW(handle,0,image,ref length)||command==null||command.Length>32767||!session.VerifyOwnedProcessToken(handle))throw new InvalidOperationException("native_creation_authority_identity_unverified");return new NativeOwnedProcessIdentity(id,created,image.ToString(),session,Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(command))).ToLowerInvariant());}
  }
  internal uint Pid {get{lock(sync){if(closed||!handlesKnown)throw new InvalidOperationException("native_original_process_required");return pid;}}}
  internal string NativeCreatedFileTimeUtc {get{lock(sync){if(closed||!handlesKnown||!identityCaptured||birth<=0)throw new InvalidOperationException("native_original_birth_required");return birth.ToString(CultureInfo.InvariantCulture);}}}
  internal int SealedSourceCount {get{lock(sync)return sealedSources;}}
  internal bool RequiresReconciliation {get{lock(sync)return uncertain;}}
  internal void BindPersistedRegistration(string operationNonce,string manifest,uint processId,string exactBirth){lock(sync){if(closed||uncertain||resumed||registrationBound||operationNonce!=OperationNonce||manifest!=SourceManifestHash||processId!=pid||exactBirth!=NativeCreatedFileTimeUtc||sealedSources<1)throw new InvalidOperationException("native_registration_unbound");InspectIdentity();registrationBound=true;}}
  internal void Resume(CancellationToken cancellation){lock(sync){if(closed||uncertain||resumed||!registrationBound)throw new InvalidOperationException("native_registered_creation_required");cancellation.ThrowIfCancellationRequested();InspectIdentity();if(ResumeThread(thread)!=1){uncertain=true;throw new InvalidOperationException("native_resume_unverified");}resumed=true;}}
  internal bool VerifiedExited(){lock(sync){if(closed||!handlesKnown||!identityCaptured)throw new InvalidOperationException("native_original_process_required");uint state=WaitForSingleObject(process,0);if(state==258)return false;if(state!=0)throw new InvalidOperationException("native_original_exit_unverified");long actual,exit,kernel,user;if(GetProcessId(process)!=pid||!GetProcessTimes(process,out actual,out exit,out kernel,out user)||actual!=birth)throw new InvalidOperationException("native_original_exit_identity_changed");return true;}}
  bool OriginalCreationHandleExited(){if(!handlesKnown||GetProcessId(process)!=pid)throw new InvalidOperationException("native_original_handle_unverified");uint state=WaitForSingleObject(process,0);if(state==258)return false;if(state!=0)throw new InvalidOperationException("native_original_exit_unverified");if(identityCaptured){long actual,exit,kernel,user;if(!GetProcessTimes(process,out actual,out exit,out kernel,out user)||actual!=birth)throw new InvalidOperationException("native_original_birth_changed");}return true;}
  // This is bounded cleanup of the one original child/private job, never an
  // unknown descendant tree. An unverified exit keeps every ownership handle.
  internal bool CleanupOwned(int deadlineMilliseconds){lock(sync){
   if(closed)return true;if(deadlineMilliseconds<1||deadlineMilliseconds>10000)throw new InvalidOperationException("native_cleanup_deadline_required");uncertain=true;
   if(handlesKnown){if(!OriginalCreationHandleExited()){if(GetProcessId(process)!=pid)throw new InvalidOperationException("native_original_handle_unverified");if(terminationRequested)throw new InvalidOperationException("native_termination_already_requested");terminationRequested=true;if(!TerminateProcess(process,93))throw new InvalidOperationException("native_original_termination_unverified");if(WaitForSingleObject(process,(uint)deadlineMilliseconds)!=0||!OriginalCreationHandleExited())return false;}}
   else if(creationCalled){if(!creationReturned)throw new InvalidOperationException("native_creation_still_unresolved");if(ActiveJobProcesses()!=0){if(terminationRequested)throw new InvalidOperationException("native_termination_already_requested");terminationRequested=true;if(!TerminateJobObject(job,93))throw new InvalidOperationException("native_private_job_termination_unverified");var timer=System.Diagnostics.Stopwatch.StartNew();while(ActiveJobProcesses()!=0){if(timer.ElapsedMilliseconds>=deadlineMilliseconds)return false;Thread.Sleep(20);}}}
   if(job!=null&&!job.IsInvalid&&ActiveJobProcesses()!=0)return false;
   if(thread!=null)thread.Dispose();if(process!=null)process.Dispose();if(job!=null)job.Dispose();closed=true;return true;
  }}
 }
}
