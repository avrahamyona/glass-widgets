// Private fixed-definition owner. Actual native creation is inside the shared
// policy CAS. No launch method is exposed by the existing production stdio host.
using System;
using System.Threading;
namespace GlassWidgets.ServerControlPrep {
 internal sealed class NativeOwnedStartResult {
  internal readonly NativeOwnedProcessIdentity SourceOwner,Server;
  internal readonly string OperationNonce,SourceManifestHash,DefinitionHash;
  internal readonly long Revision;
  internal NativeOwnedStartResult(NativeOwnedProcessIdentity owner,NativeOwnedProcessIdentity server,NativeStartCommitContext context,string definitionHash){SourceOwner=owner;Server=server;OperationNonce=context.Operation.Nonce;SourceManifestHash=context.SourceManifestHash;Revision=context.Revision;DefinitionHash=definitionHash;}
 }
 internal sealed class FixedNativeSourceOwner {
  readonly object sync=new object();readonly NativeServerLaunchDefinition definition;readonly WindowsNativePolicyContext context;readonly string installationId;readonly NativeOwnedProcessIdentity authority;readonly Func<NativeOwnedProcessIdentity,NativeOwnedProcessIdentity,string,CancellationToken,bool> acknowledgeIndependentOwnership;
  NativeOwnedCreationFrame frame;bool uncertain,closed,cleanupVerified=true;
  internal FixedNativeSourceOwner(NativeServerLaunchDefinition definition,WindowsNativePolicyContext context,string installationId,Func<NativeOwnedProcessIdentity,NativeOwnedProcessIdentity,string,CancellationToken,bool> acknowledgeIndependentOwnership){
   if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException("windows_fixed_native_owner_required");
   if(definition==null||context==null||acknowledgeIndependentOwnership==null||!NativePolicyCommitGate.Identifier(installationId))throw new InvalidOperationException("fixed_native_owner_context_required");this.definition=definition;this.context=context;this.installationId=installationId;this.acknowledgeIndependentOwnership=acknowledgeIndependentOwnership;authority=NativeOwnedCreationFrame.CaptureCreationAuthority(context.SessionBinding);
  }
  internal NativeOwnedStartResult Start(NativeStartCommitContext operation,CancellationToken cancellation){lock(sync){
   if(closed||uncertain||context.CommitGate.RequiresReconciliation)throw new InvalidOperationException("fixed_native_owner_requires_reconciliation");
   if(operation==null||operation.SessionId!=context.SessionId||operation.Operation.InstallationId!=installationId||operation.SourceManifestHash!=definition.Sources.ManifestHash)throw new InvalidOperationException("fixed_native_operation_unbound");
   cancellation.ThrowIfCancellationRequested();
   if(frame!=null){if(!frame.VerifiedExited())throw new InvalidOperationException("previous_native_child_still_owned");if(!frame.CleanupOwned(5000)){uncertain=true;cleanupVerified=false;throw new InvalidOperationException("previous_native_child_cleanup_unverified");}frame=null;}
   try{
    return context.CommitGate.Commit(operation,commit=>{
     NativeOwnedProcessIdentity server;
     // Check private configuration metadata without reading or exporting secrets.
     // Release its read lease before resume so mutable server data is not locked.
     using(var configuration=context.HoldVerifiedConfiguration(definition.ConfigFile)){
      var created=NativeOwnedCreationFrame.CreateSuspended(definition,commit,context.SessionBinding,value=>{if(frame!=null)throw new InvalidOperationException("native_creation_frame_already_owned");frame=value;cleanupVerified=false;},cancellation);
      server=created.Identity(context.SessionBinding);context.PersistSuspendedRegistration(commit,authority,server,definition.DefinitionHash);
      // No permissive default. The fixed stdio/handle-host adapter must acquire
      // and retain its independent exact kernel observation before acknowledging.
      // This callback must be bounded and synchronous; its real adapter is pending.
      cancellation.ThrowIfCancellationRequested();if(!acknowledgeIndependentOwnership(authority,server,commit.Operation.Nonce,cancellation))throw new InvalidOperationException("independent_native_ownership_unverified");
      created.BindPersistedRegistration(commit.Operation.Nonce,commit.SourceManifestHash,server.Pid,server.NativeCreatedFileTimeUtc);
     }
     cancellation.ThrowIfCancellationRequested();frame.Resume(cancellation);
     // This is owned/resumed, not an authenticated health or listener proof.
     return new NativeOwnedStartResult(authority,server,commit,definition.DefinitionHash);
    },cancellation);
   }catch{
    uncertain=true;
    // Keep the frame and every unverified original handle. The journal/attempt
    // barrier remains even if bounded cleanup proves that the new child exited.
    if(frame!=null){try{cleanupVerified=frame.CleanupOwned(5000);}catch{cleanupVerified=false;}}
    throw;
   }
  }}
  internal bool VerifyOriginalChildExited(){lock(sync){if(frame==null)return cleanupVerified;return frame.VerifiedExited();}}
  internal bool RequiresReconciliation {get{lock(sync)return uncertain||context.CommitGate.RequiresReconciliation||(frame!=null&&frame.RequiresReconciliation);}}
  internal bool CleanupVerified {get{lock(sync)return cleanupVerified;}}
  internal bool CloseOwned(){lock(sync){if(closed)return true;if(frame!=null){try{cleanupVerified=frame.CleanupOwned(5000);}catch{cleanupVerified=false;}if(!cleanupVerified){uncertain=true;return false;}}closed=true;return true;}}
 }
}
