// Private Windows binding for the shared policy CAS. Read-only validation only:
// no directory creation, ACL edits, elevation, process launch or stale-lock removal.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32.SafeHandles;
namespace GlassWidgets.ServerControlPrep {
 internal sealed class WindowsNativePolicyBinding {
  const uint ReadAttributesAndControl=0x00020080,ShareReadWrite=3,OpenExisting=3,Backup=0x02000000,OpenReparse=0x00200000,DirectoryAttribute=0x10,ReparseAttribute=0x400;
  readonly object sync=new object();readonly string directory,ownerSid,logonSid,enrolledDataFileName;Lease active;
  [StructLayout(LayoutKind.Sequential)] struct FileInformation {internal uint Attributes,CreatedLow,CreatedHigh,AccessLow,AccessHigh,WriteLow,WriteHigh,Volume,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;}
  sealed class DirectoryEntry {internal string Path;internal SafeFileHandle Handle;internal FileInformation Identity;}
  sealed class Lease:IDisposable {
   internal readonly WindowsNativePolicyBinding Parent;internal readonly List<DirectoryEntry> Directories=new List<DirectoryEntry>();internal readonly Dictionary<string,FileInformation> Opened=new Dictionary<string,FileInformation>(StringComparer.OrdinalIgnoreCase);internal bool Disposed;
   internal Lease(WindowsNativePolicyBinding parent){Parent=parent;}
   public void Dispose(){Parent.Release(this);}
  }
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern SafeFileHandle CreateFileW(string path,uint access,uint share,IntPtr security,uint disposition,uint flags,IntPtr template);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetFinalPathNameByHandleW(SafeFileHandle file,StringBuilder value,uint count,uint flags);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetFileInformationByHandle(SafeFileHandle file,out FileInformation info);
  [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetFileType(SafeFileHandle file);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern uint GetDriveTypeW(string root);
  [DllImport("advapi32.dll",SetLastError=true)] static extern uint GetSecurityInfo(SafeFileHandle handle,uint type,uint security,out IntPtr owner,out IntPtr group,out IntPtr dacl,out IntPtr sacl,out IntPtr descriptor);
  [DllImport("advapi32.dll",SetLastError=true)] static extern uint GetSecurityDescriptorLength(IntPtr descriptor);
  [DllImport("advapi32.dll",SetLastError=true)] static extern bool IsValidSecurityDescriptor(IntPtr descriptor);
  [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr memory);
  internal WindowsNativePolicyBinding(string directory,string ownerSid,string logonSid,string enrolledDataFileName=null){
   if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException("windows_policy_binding_required");
   if(directory==null||directory.Length<4||!Regex.IsMatch(directory,"^[A-Za-z]:\\\\",RegexOptions.CultureInvariant)||directory.StartsWith("\\\\",StringComparison.Ordinal)||directory.IndexOf(':',2)>=0||directory.IndexOfAny(new[]{'\0','\r','\n','/'})>=0||String.IsNullOrEmpty(ownerSid)||logonSid==null||!Regex.IsMatch(logonSid,"^S-1-5-5-[0-9]+-[0-9]+$",RegexOptions.CultureInvariant))throw new InvalidOperationException("native_policy_binding_context_required");
   this.directory=Path.GetFullPath(directory).TrimEnd('\\');this.ownerSid=ownerSid;this.logonSid=logonSid;this.enrolledDataFileName=enrolledDataFileName;
   if(enrolledDataFileName!=null){if(enrolledDataFileName!=Path.GetFileName(enrolledDataFileName))throw new InvalidOperationException("fixed_native_data_file_required");HeldSourceFiles.ValidateAndCopy(new[]{new SourceFileSpec(this.directory+"\\"+enrolledDataFileName,1,new string('a',64))});}
   // Reject aliases, reserved components and trailing dots/spaces using the same
   // strict path grammar as the held-source implementation. No file is opened.
   HeldSourceFiles.ValidateAndCopy(new[]{new SourceFileSpec(this.directory+"\\gw-policy-path-validation",1,new string('a',64))});
   if(GetDriveTypeW(this.directory.Substring(0,3))!=3)throw new InvalidOperationException("fixed_local_policy_drive_required");
  }
  static string FinalPath(SafeFileHandle handle){var text=new StringBuilder(32768);uint length=GetFinalPathNameByHandleW(handle,text,32768,0);if(length==0||length>=32768)throw new InvalidOperationException("native_policy_final_path_unverified");string path=text.ToString();if(!path.StartsWith("\\\\?\\",StringComparison.Ordinal)||path.StartsWith("\\\\?\\UNC\\",StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("native_policy_final_path_unverified");return path.Substring(4);}
  static FileInformation Info(SafeFileHandle handle){FileInformation info;if(handle==null||handle.IsClosed||handle.IsInvalid||GetFileType(handle)!=1||!GetFileInformationByHandle(handle,out info)||(info.Attributes&ReparseAttribute)!=0)throw new InvalidOperationException("native_policy_handle_unverified");return info;}
  static bool SameObject(FileInformation first,FileInformation second)=>first.Volume==second.Volume&&first.IndexHigh==second.IndexHigh&&first.IndexLow==second.IndexLow;
  bool Private(SafeFileHandle handle){
   IntPtr owner,group,dacl,sacl,descriptor=IntPtr.Zero;
   try{
    if(GetSecurityInfo(handle,1,5,out owner,out group,out dacl,out sacl,out descriptor)!=0||descriptor==IntPtr.Zero||owner==IntPtr.Zero||dacl==IntPtr.Zero||!IsValidSecurityDescriptor(descriptor))return false;
    uint size=GetSecurityDescriptorLength(descriptor);if(size<20||size>65536)return false;var bytes=new byte[size];Marshal.Copy(descriptor,bytes,0,checked((int)size));return NativePrivateDescriptor.IsPrivate(bytes,ownerSid,logonSid);
   }finally{if(descriptor!=IntPtr.Zero&&LocalFree(descriptor)!=IntPtr.Zero)throw new InvalidOperationException("native_security_buffer_release_unverified");}
  }
  void VerifyDirectories(Lease lease){
   foreach(var entry in lease.Directories){var info=Info(entry.Handle);if((info.Attributes&DirectoryAttribute)==0||!SameObject(info,entry.Identity)||!String.Equals(FinalPath(entry.Handle),entry.Path,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("native_policy_ancestor_changed");}
   if(lease.Directories.Count==0||!Private(lease.Directories[lease.Directories.Count-1].Handle))throw new InvalidOperationException("native_private_policy_directory_unverified");
  }
  internal IDisposable HoldVerifiedPrivateDirectory(string requestedDirectory){lock(sync){
   if(active!=null)throw new InvalidOperationException("native_policy_directory_binding_busy");if(!String.Equals(requestedDirectory,directory,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("native_policy_directory_unbound");
   var lease=new Lease(this);active=lease;
   try{
    var paths=new List<string>();for(string path=directory;path!=null;path=Path.GetDirectoryName(path)){paths.Add(path);if(paths.Count>65)throw new InvalidOperationException("native_policy_ancestor_limit");}paths.Reverse();
    foreach(string path in paths){var handle=CreateFileW(path,ReadAttributesAndControl,ShareReadWrite,IntPtr.Zero,OpenExisting,Backup|OpenReparse,IntPtr.Zero);try{var info=Info(handle);if((info.Attributes&DirectoryAttribute)==0||!String.Equals(FinalPath(handle),path,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("native_policy_directory_unverified");lease.Directories.Add(new DirectoryEntry{Path=path,Handle=handle,Identity=info});handle=null;}finally{if(handle!=null)handle.Dispose();}}
    VerifyDirectories(lease);return lease;
   }catch{foreach(var entry in lease.Directories)entry.Handle.Dispose();lease.Disposed=true;active=null;throw;}
  }}
  internal bool VerifyBoundOpenedFile(FileStream stream,string requestedFile){lock(sync){
   var lease=active;if(lease==null||lease.Disposed||stream==null)return false;
   string file=Path.GetFullPath(requestedFile);if(!String.Equals(Path.GetDirectoryName(file),directory,StringComparison.OrdinalIgnoreCase))return false;
   string name=Path.GetFileName(file);if(name!=enrolledDataFileName&&name!="server-intent-v1.json"&&name!="server-intent-v1.lock"&&name!="server-operation-v1.json"&&!Regex.IsMatch(name,"^server-(launch-attempt|owned-start)-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\\.json$",RegexOptions.CultureInvariant))return false;
   VerifyDirectories(lease);var handle=stream.SafeFileHandle;var before=Info(handle);if((before.Attributes&DirectoryAttribute)!=0||before.Links!=1||!String.Equals(FinalPath(handle),file,StringComparison.OrdinalIgnoreCase)||!Private(handle))return false;
   var after=Info(handle);if(!SameObject(before,after)||after.Links!=1)return false;
   FileInformation previous;if(lease.Opened.TryGetValue(file,out previous)){if(!SameObject(previous,after))return false;}else lease.Opened.Add(file,after);
   return true;
  }}
  void Release(Lease lease){lock(sync){if(lease.Disposed)return;if(!Object.ReferenceEquals(active,lease))throw new InvalidOperationException("native_policy_directory_lease_unbound");try{VerifyDirectories(lease);}finally{foreach(var entry in lease.Directories.AsEnumerable().Reverse())entry.Handle.Dispose();lease.Directories.Clear();lease.Opened.Clear();lease.Disposed=true;active=null;}}}
 }
}
