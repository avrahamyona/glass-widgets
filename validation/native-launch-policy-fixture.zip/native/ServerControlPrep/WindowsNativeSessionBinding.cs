// Private Windows context for policy CAS. Captures owner/logon from the process
// token and boot milliseconds through a fixed, read-only built-in CIM command.
// Capture happens before any inheritable source duplicates can exist.
using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32.SafeHandles;
namespace GlassWidgets.ServerControlPrep {
 internal static class NativeCreationSerialization {internal static readonly object Gate=new object();}
 internal sealed class WindowsNativeSessionBinding {
  internal readonly string OwnerSid,LogonSid,SessionId;
  [StructLayout(LayoutKind.Sequential)] struct SidAndAttributes {internal IntPtr Sid;internal uint Attributes;}
  [StructLayout(LayoutKind.Sequential)] struct GroupsHeader {internal uint Count;internal SidAndAttributes First;}
  [DllImport("advapi32.dll",SetLastError=true)] static extern bool GetTokenInformation(SafeAccessTokenHandle token,int info,IntPtr buffer,uint size,out uint returned);
  [DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr process,uint access,out SafeAccessTokenHandle token);
  [DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(SafeHandle process,uint access,out SafeAccessTokenHandle token);
  [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
  static SafeAccessTokenHandle ProcessToken(){SafeAccessTokenHandle token;if(!OpenProcessToken(GetCurrentProcess(),8,out token)||token==null||token.IsInvalid){if(token!=null)token.Dispose();throw new InvalidOperationException("native_process_token_unverified");}return token;}
  static bool NormalUser(SafeAccessTokenHandle token){IntPtr buffer=Marshal.AllocHGlobal(4);try{uint returned;return GetTokenInformation(token,20,buffer,4,out returned)&&returned==4&&Marshal.ReadInt32(buffer)==0;}finally{Marshal.FreeHGlobal(buffer);}}
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetSystemDirectoryW(StringBuilder buffer,uint size);
  static string TokenLogon(SafeAccessTokenHandle token){
   uint needed;GetTokenInformation(token,2,IntPtr.Zero,0,out needed);if(needed<8||needed>1048576)throw new InvalidOperationException("native_session_token_unverified");IntPtr buffer=Marshal.AllocHGlobal((int)needed);
   try{uint returned;if(!GetTokenInformation(token,2,buffer,needed,out returned))throw new InvalidOperationException("native_session_token_unverified");int count=Marshal.ReadInt32(buffer),offset=(int)Marshal.OffsetOf<GroupsHeader>("First"),stride=Marshal.SizeOf<SidAndAttributes>();if(count<1||count>4096||offset+(long)count*stride>returned)throw new InvalidOperationException("native_session_groups_unverified");string found=null;
    for(int i=0;i<count;i++){var row=Marshal.PtrToStructure<SidAndAttributes>(IntPtr.Add(buffer,offset+i*stride));if((row.Attributes&0xC0000000)==0xC0000000){if(found!=null)throw new InvalidOperationException("native_session_groups_unverified");found=new SecurityIdentifier(row.Sid).Value;}}
    if(found==null||!Regex.IsMatch(found,"^S-1-5-5-[0-9]+-[0-9]+$",RegexOptions.CultureInvariant))throw new InvalidOperationException("native_logon_sid_unverified");return found;
   }finally{Marshal.FreeHGlobal(buffer);}
  }
  internal static long ParseBootMilliseconds(string output){
   try{using(var document=JsonDocument.Parse(output)){var root=document.RootElement;DateTimeOffset boot;string text=root.ValueKind==JsonValueKind.String?root.GetString():null;if(text==null||!Regex.IsMatch(text,"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\\.[0-9]{1,7}Z$",RegexOptions.CultureInvariant)||!DateTimeOffset.TryParseExact(text,"yyyy-MM-dd'T'HH:mm:ss.FFFFFFF'Z'",CultureInfo.InvariantCulture,DateTimeStyles.AssumeUniversal|DateTimeStyles.AdjustToUniversal,out boot)||boot.ToUnixTimeMilliseconds()<=0)throw new InvalidOperationException("native_boot_id_unverified");return boot.ToUnixTimeMilliseconds();}}
   catch(JsonException){throw new InvalidOperationException("native_boot_id_unverified");}
  }
  static async Task<string> ReadBounded(StreamReader reader,CancellationToken token){var output=new StringBuilder();var buffer=new char[512];int read;while((read=await reader.ReadAsync(buffer.AsMemory(),token))>0){if(output.Length+read>8192)throw new InvalidOperationException("native_boot_output_limit");output.Append(buffer,0,read);}return output.ToString();}
  static long ReadBootMilliseconds(){lock(NativeCreationSerialization.Gate){
   var system=new StringBuilder(32768);uint size=GetSystemDirectoryW(system,32768);if(size==0||size>=32768)throw new InvalidOperationException("native_system_directory_unverified");string systemDirectory=system.ToString(),root=Path.GetDirectoryName(systemDirectory),home=Path.Combine(systemDirectory,"WindowsPowerShell","v1.0");
   var info=new ProcessStartInfo(Path.Combine(home,"powershell.exe")){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true,WorkingDirectory=systemDirectory};
   foreach(string value in new[]{"-NoLogo","-NoProfile","-NonInteractive","-Command","$ErrorActionPreference='Stop'; Import-Module CimCmdlets -ErrorAction Stop; (CimCmdlets\\Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().ToString('o') | ConvertTo-Json -Compress"})info.ArgumentList.Add(value);
   info.Environment.Clear();info.Environment["SystemRoot"]=root;info.Environment["WINDIR"]=root;info.Environment["PATH"]=systemDirectory;info.Environment["PSModulePath"]=Path.Combine(home,"Modules");
   using(var process=new Process{StartInfo=info}){
    if(!process.Start())throw new InvalidOperationException("native_boot_query_failed");var original=process.SafeHandle;if(original.IsInvalid)throw new InvalidOperationException("native_boot_process_unverified");
    using(var deadline=new CancellationTokenSource(5000)){
     try{var stdout=ReadBounded(process.StandardOutput,deadline.Token);var stderr=ReadBounded(process.StandardError,deadline.Token);Task.WhenAll(stdout,stderr,process.WaitForExitAsync(deadline.Token)).GetAwaiter().GetResult();if(process.ExitCode!=0||!String.IsNullOrWhiteSpace(stderr.Result))throw new InvalidOperationException("native_boot_query_failed");return ParseBootMilliseconds(stdout.Result);}
     catch{
      // The Process retains its original creation handle. Never search a PID or
      // kill a process tree. This fixed read-only query should have no children.
      if(!process.HasExited){process.Kill(false);if(!process.WaitForExit(5000))throw new InvalidOperationException("native_boot_query_cleanup_unverified");}
      throw new InvalidOperationException("native_boot_query_unverified");
     }
    }
   }
  }}
  WindowsNativeSessionBinding(string owner,string logon,long boot){OwnerSid=owner;LogonSid=logon;SessionId=logon+":"+boot.ToString(CultureInfo.InvariantCulture);}
  internal static WindowsNativeSessionBinding Capture(){
   if(!OperatingSystem.IsWindows()||!Environment.Is64BitProcess)throw new PlatformNotSupportedException("windows_x64_native_session_required");
   using(var token=ProcessToken())using(var identity=new WindowsIdentity(token.DangerousGetHandle())){if(identity.User==null||!NormalUser(token))throw new InvalidOperationException("normal_user_native_owner_required");string owner=identity.User.Value,logon=TokenLogon(token);long boot=ReadBootMilliseconds();var result=new WindowsNativeSessionBinding(owner,logon,boot);if(!result.VerifyCurrentSession(result.SessionId))throw new InvalidOperationException("native_session_changed_during_capture");return result;}
  }
  internal bool VerifyOwnedProcessToken(SafeHandle process){
   if(!OperatingSystem.IsWindows()||process==null||process.IsClosed||process.IsInvalid)return false;SafeAccessTokenHandle token;
   if(!OpenProcessToken(process,8,out token)){if(token!=null)token.Dispose();return false;}
   using(token)using(var identity=new WindowsIdentity(token.DangerousGetHandle()))return NormalUser(token)&&identity.User!=null&&identity.User.Value==OwnerSid&&TokenLogon(token)==LogonSid;
  }
  internal bool VerifyCurrentSession(string expected){
   if(!OperatingSystem.IsWindows()||expected!=SessionId)return false;
   using(var token=ProcessToken())using(var identity=new WindowsIdentity(token.DangerousGetHandle())){return NormalUser(token)&&identity.User!=null&&identity.User.Value==OwnerSid&&TokenLogon(token)==LogonSid;}
   // Boot identity need not spawn another query: this live binding cannot survive
   // an OS reboot. It never refreshes itself into a different user's/logon's token.
  }
 }
 internal sealed class WindowsNativePolicyContext {
  readonly WindowsNativeSessionBinding session;readonly WindowsNativePolicyBinding files;readonly HeldSourceFiles sources;readonly string policyDirectory;
  internal readonly NativePolicyCommitGate CommitGate;
  internal string SessionId=>session.SessionId;
  internal string OwnerSid=>session.OwnerSid;
  internal string LogonSid=>session.LogonSid;
  internal WindowsNativeSessionBinding SessionBinding=>session;
  internal WindowsNativePolicyContext(string policyDirectory,HeldSourceFiles sources){
   if(sources==null)throw new InvalidOperationException("held_native_sources_required");
   this.policyDirectory=Path.GetFullPath(policyDirectory).TrimEnd('\\');session=WindowsNativeSessionBinding.Capture();this.sources=sources;files=new WindowsNativePolicyBinding(this.policyDirectory,session.OwnerSid,session.LogonSid);
   CommitGate=new NativePolicyCommitGate(Path.GetFullPath(policyDirectory).TrimEnd('\\'),files.HoldVerifiedPrivateDirectory,files.VerifyBoundOpenedFile,session.VerifyCurrentSession,VerifySources);
  }
  sealed class ConfigurationLease:IDisposable {readonly IDisposable directory;readonly FileStream file;internal ConfigurationLease(IDisposable directory,FileStream file){this.directory=directory;this.file=file;}public void Dispose(){try{file.Dispose();}finally{directory.Dispose();}}}
  internal IDisposable HoldVerifiedConfiguration(string file){
   string path=Path.GetFullPath(file),parent=Path.GetDirectoryName(path),name=Path.GetFileName(path);if(new[]{"server-intent-","server-operation-","server-launch-attempt-","server-owned-start-"}.Any(prefix=>name.StartsWith(prefix,StringComparison.OrdinalIgnoreCase)))throw new InvalidOperationException("native_configuration_policy_collision");
   var binding=new WindowsNativePolicyBinding(parent,session.OwnerSid,session.LogonSid,name);IDisposable directory=null;FileStream stream=null;
   try{directory=binding.HoldVerifiedPrivateDirectory(parent);stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read);if(!binding.VerifyBoundOpenedFile(stream,path)||stream.Length<2||stream.Length>1048576)throw new InvalidOperationException("native_private_configuration_unverified");return new ConfigurationLease(directory,stream);}catch{try{if(stream!=null)stream.Dispose();}finally{if(directory!=null)directory.Dispose();}throw;}
  }
  internal void PersistSuspendedRegistration(NativeStartCommitContext context,NativeOwnedProcessIdentity owner,NativeOwnedProcessIdentity server,string definitionHash){
   if(context==null||owner==null||server==null||!session.VerifyCurrentSession(context.SessionId)||owner.SessionId!=context.SessionId||server.SessionId!=context.SessionId||owner.OwnerSid!=session.OwnerSid||server.OwnerSid!=session.OwnerSid||owner.Pid==server.Pid||definitionHash==null||!Regex.IsMatch(definitionHash,"^[a-f0-9]{64}$",RegexOptions.CultureInvariant))throw new InvalidOperationException("native_registration_context_unbound");
   string file=Path.Combine(policyDirectory,"server-owned-start-"+context.Operation.Nonce+".json");var options=new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase};
   using(var stream=new FileStream(file,FileMode.CreateNew,FileAccess.Write,FileShare.Read,4096,FileOptions.WriteThrough)){
    if(!files.VerifyBoundOpenedFile(stream,file))throw new InvalidOperationException("native_registration_file_unverified");
    var operation=context.Operation;byte[] bytes=JsonSerializer.SerializeToUtf8Bytes(new{version=1,phase="suspended-owned-not-ready",installationId=operation.InstallationId,sessionId=context.SessionId,revision=context.Revision,sourceManifestHash=context.SourceManifestHash,definitionHash,operation=new{version=1,nonce=operation.Nonce,controllerId=operation.ControllerId,@event=operation.Event,installationId=operation.InstallationId,persistedSessionId=operation.PersistedSessionId},sourceOwner=owner,server},options);if(bytes.Length>16384)throw new InvalidOperationException("native_registration_size_limit");stream.Write(bytes);stream.Flush(true);if(!files.VerifyBoundOpenedFile(stream,file))throw new InvalidOperationException("native_registration_file_changed");
   }
  }
  bool VerifySources(string manifest,CancellationToken cancellation){if(manifest!=sources.ManifestHash)return false;sources.Verify(cancellation);return true;}
 }
}
