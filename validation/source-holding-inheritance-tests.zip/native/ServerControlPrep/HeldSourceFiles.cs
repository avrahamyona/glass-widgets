// Private backend preparation. Read-only source handles, not a launcher, a
// complete module-closure proof, an ACL proof or a process-execution proof.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.Win32.SafeHandles;

namespace GlassWidgets.ServerControlPrep {
 public sealed class SourceFileSpec {
  public readonly string Path, Sha256;
  public readonly long Bytes;
  public SourceFileSpec(string path,long bytes,string sha256){Path=path;Bytes=bytes;Sha256=sha256;}
 }
 public sealed class HeldSourceFiles : IDisposable {
  public const string Scope="read-only-held-files-not-closure-or-spawn-proof";
  const uint Read=0x80000000,ReadAttributes=0x80,ShareRead=1,OpenExisting=3,Backup=0x02000000,OpenReparse=0x00200000,Reparse=0x400,Directory=0x10;
  readonly object gate=new object();
  readonly SourceFileSpec[] specs;
  readonly List<SafeFileHandle> directories=new List<SafeFileHandle>();
  readonly List<FileStream> files=new List<FileStream>();
  readonly List<string> directoryPaths=new List<string>();
  bool disposed;
  public readonly string ManifestHash;
  [StructLayout(LayoutKind.Sequential)] struct FileInfo {
   public uint Attributes,CreatedLow,CreatedHigh,AccessLow,AccessHigh,WriteLow,WriteHigh,Volume,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;
  }
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern SafeFileHandle CreateFileW(string path,uint access,uint share,IntPtr security,uint disposition,uint flags,IntPtr template);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetFinalPathNameByHandleW(SafeFileHandle file,StringBuilder value,uint count,uint flags);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetFileInformationByHandle(SafeFileHandle file,out FileInfo info);
  [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetFileType(SafeFileHandle file);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern uint GetDriveTypeW(string root);

  public static SourceFileSpec[] ValidateAndCopy(IEnumerable<SourceFileSpec> input){
   if(input==null)throw new InvalidOperationException("reviewed_source_files_required");
   var copy=new List<SourceFileSpec>();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);long total=0;
   foreach(var value in input){
    if(value==null||copy.Count>=128||!ValidPath(value.Path)||value.Bytes<1||value.Bytes>268435456||value.Sha256==null||!Regex.IsMatch(value.Sha256,"^[a-f0-9]{64}$",RegexOptions.CultureInvariant)||!seen.Add(value.Path))throw new InvalidOperationException("reviewed_source_files_required");
    total=checked(total+value.Bytes);if(total>1073741824)throw new InvalidOperationException("source_size_limit");
    copy.Add(new SourceFileSpec(value.Path,value.Bytes,value.Sha256));
   }
   if(copy.Count==0)throw new InvalidOperationException("reviewed_source_files_required");
   return copy.OrderBy(x=>x.Path,StringComparer.Ordinal).ToArray();
  }
  static bool ValidPath(string path){
   if(String.IsNullOrEmpty(path)||path.Length>4096||!Regex.IsMatch(path,"^[A-Za-z]:\\\\",RegexOptions.CultureInvariant)||path.IndexOfAny(new[]{'\0','\r','\n','/','<','>','\"','|','?','*'})>=0||path.IndexOf(':',2)>=0)return false;
   var parts=path.Substring(3).Split('\\');if(parts.Length==0||parts.Length>64)return false;
   foreach(string part in parts)if(part.Length==0||part=="."||part==".."||part.EndsWith(" ",StringComparison.Ordinal)||part.EndsWith(".",StringComparison.Ordinal)||Regex.IsMatch(part,"^(CON|PRN|AUX|NUL|COM[0-9¹²³]|LPT[0-9¹²³])(?:\\.|$)",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant))return false;
   return true;
  }
  public static string HashManifest(IEnumerable<SourceFileSpec> input){
   var copied=ValidateAndCopy(input);var text=new StringBuilder("GW-SOURCE-HANDLES-1\n");text.Append(copied.Length.ToString(CultureInfo.InvariantCulture)).Append('\n');
   foreach(var item in copied)text.Append(item.Path).Append('\n').Append(item.Bytes.ToString(CultureInfo.InvariantCulture)).Append('\n').Append(item.Sha256).Append('\n');
   using(var hash=SHA256.Create())return Convert.ToHexString(hash.ComputeHash(Encoding.UTF8.GetBytes(text.ToString()))).ToLowerInvariant();
  }
  static string FinalPath(SafeFileHandle file){
   var text=new StringBuilder(32768);uint length=GetFinalPathNameByHandleW(file,text,32768,0);
   if(length==0||length>=32768)throw new InvalidOperationException("source_final_path_unverified");
   string path=text.ToString();if(!path.StartsWith("\\\\?\\",StringComparison.Ordinal)||path.StartsWith("\\\\?\\UNC\\",StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("local_source_path_required");return path.Substring(4);
  }
  static FileInfo Info(SafeFileHandle file){
   FileInfo info;if(file==null||file.IsClosed||file.IsInvalid||GetFileType(file)!=1||!GetFileInformationByHandle(file,out info)||(info.Attributes&Reparse)!=0)throw new InvalidOperationException("source_handle_unverified");return info;
  }
  static SafeFileHandle Open(string path,bool directory){
   var handle=CreateFileW(path,directory?ReadAttributes:Read,ShareRead,IntPtr.Zero,OpenExisting,OpenReparse|(directory?Backup:0u),IntPtr.Zero);
   try{
    if(handle.IsInvalid)throw new InvalidOperationException("source_read_lease_refused");var info=Info(handle);
    if(((info.Attributes&Directory)!=0)!=directory||(!directory&&info.Links!=1)||!String.Equals(FinalPath(handle),path,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("source_path_identity_unverified");
    return handle;
   }catch{handle.Dispose();throw;}
  }
  HeldSourceFiles(SourceFileSpec[] records,CancellationToken cancellation){
   specs=records;ManifestHash=HashManifest(records);
   try{
    var ancestors=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    foreach(var item in specs){
     if(GetDriveTypeW(item.Path.Substring(0,3))!=3)throw new InvalidOperationException("fixed_local_source_drive_required");
     string parent=System.IO.Path.GetDirectoryName(item.Path);
     while(parent!=null&&parent.Length>3){ancestors.Add(parent);if(ancestors.Count>2048)throw new InvalidOperationException("source_directory_limit");parent=System.IO.Path.GetDirectoryName(parent);}
    }
    foreach(string directory in ancestors.OrderBy(x=>x.Length).ThenBy(x=>x,StringComparer.Ordinal)){cancellation.ThrowIfCancellationRequested();directories.Add(Open(directory,true));directoryPaths.Add(directory);}
    foreach(var item in specs){cancellation.ThrowIfCancellationRequested();var handle=Open(item.Path,false);FileStream stream=null;try{stream=new FileStream(handle,FileAccess.Read,65536,false);files.Add(stream);}catch{if(stream!=null)stream.Dispose();else handle.Dispose();throw;}}
    Verify(cancellation);
   }catch{Dispose();throw;}
  }
  public static HeldSourceFiles Acquire(IEnumerable<SourceFileSpec> records,CancellationToken cancellation){
   var copied=ValidateAndCopy(records);cancellation.ThrowIfCancellationRequested();if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException("windows_source_handles_required");return new HeldSourceFiles(copied,cancellation);
  }
  public int FileCount {get {lock(gate){if(disposed)throw new ObjectDisposedException("HeldSourceFiles");return specs.Length;}}}
  public void Verify(CancellationToken cancellation){lock(gate){
   if(disposed)throw new ObjectDisposedException("HeldSourceFiles");
   for(int i=0;i<directories.Count;i++){cancellation.ThrowIfCancellationRequested();var info=Info(directories[i]);if((info.Attributes&Directory)==0||!String.Equals(FinalPath(directories[i]),directoryPaths[i],StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("source_ancestor_changed");}
   byte[] buffer=new byte[65536];
   for(int i=0;i<files.Count;i++){
    cancellation.ThrowIfCancellationRequested();var stream=files[i];var expected=specs[i];var before=Info(stream.SafeFileHandle);long size=((long)before.SizeHigh<<32)|before.SizeLow;
    if(size!=expected.Bytes||before.Links!=1||!String.Equals(FinalPath(stream.SafeFileHandle),expected.Path,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("source_file_changed");
    stream.Position=0;long bytes=0;using(var hash=IncrementalHash.CreateHash(HashAlgorithmName.SHA256)){
     int n;while((n=stream.Read(buffer,0,buffer.Length))>0){cancellation.ThrowIfCancellationRequested();bytes=checked(bytes+n);if(bytes>expected.Bytes)throw new InvalidOperationException("source_file_changed");hash.AppendData(buffer,0,n);}
     if(bytes!=expected.Bytes||!String.Equals(Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant(),expected.Sha256,StringComparison.Ordinal))throw new InvalidOperationException("source_hash_changed");
    }
    var after=Info(stream.SafeFileHandle);if(before.Volume!=after.Volume||before.IndexHigh!=after.IndexHigh||before.IndexLow!=after.IndexLow||before.WriteHigh!=after.WriteHigh||before.WriteLow!=after.WriteLow||before.SizeHigh!=after.SizeHigh||before.SizeLow!=after.SizeLow||after.Links!=1)throw new InvalidOperationException("source_file_changed");
   }
  }}
  // Internal preparation boundary only. The production stdio host does not expose
  // process creation through this method. A caller must supply its own policy CAS
  // boundary before it can become a production launch capability.
  [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr GetCurrentProcess();
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool DuplicateHandle(IntPtr sourceProcess,SafeFileHandle source,IntPtr targetProcess,out SafeFileHandle target,uint access,bool inherit,uint options);
  internal T WithInheritableDuplicates<T>(string reviewedImage,Func<IReadOnlyList<SafeFileHandle>,T> create,CancellationToken cancellation){lock(gate){
   if(disposed)throw new ObjectDisposedException("HeldSourceFiles");
   if(create==null||!specs.Any(x=>String.Equals(x.Path,reviewedImage,StringComparison.OrdinalIgnoreCase)))throw new InvalidOperationException("held_reviewed_image_required");
   Verify(cancellation);var duplicates=new List<SafeFileHandle>();
   try{
    foreach(var original in directories.Concat(files.Select(x=>x.SafeFileHandle))){cancellation.ThrowIfCancellationRequested();SafeFileHandle duplicate;
     if(!DuplicateHandle(GetCurrentProcess(),original,GetCurrentProcess(),out duplicate,0,true,2)){if(duplicate!=null)duplicate.Dispose();throw new InvalidOperationException("source_handle_duplication_unverified");}duplicates.Add(duplicate);
    }
    cancellation.ThrowIfCancellationRequested();return create(duplicates.AsReadOnly());
   }finally{foreach(var duplicate in duplicates)duplicate.Dispose();}
  }}
  public void Dispose(){lock(gate){if(disposed)return;disposed=true;Exception failed=null;foreach(var file in files)try{file.Dispose();}catch(Exception error){failed=error;}foreach(var directory in directories)try{directory.Dispose();}catch(Exception error){failed=error;}files.Clear();directories.Clear();directoryPaths.Clear();if(failed!=null)throw new InvalidOperationException("source_handle_close_unverified");}GC.SuppressFinalize(this);}
 }
}
