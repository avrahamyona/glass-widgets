// Windows-only inheritance acceptance primitive. Not linked into ServerControlHost.
// No production launch API, policy commit, environment filtering or module closure
// is claimed. Only the dedicated fixture program should call this preparation code.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32.SafeHandles;
namespace GlassWidgets.ServerControlPrep {
 internal sealed class FixtureKernelHandle:SafeHandleZeroOrMinusOneIsInvalid {
  internal FixtureKernelHandle():base(true){}
  internal FixtureKernelHandle(IntPtr handle):base(true){SetHandle(handle);}
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
  protected override bool ReleaseHandle(){return CloseHandle(handle);}
 }
 internal sealed class InheritedSourceFixtureProcess:IDisposable {
  readonly FixtureKernelHandle process,thread;bool disposed,resumed;
  internal readonly uint Pid;
  internal readonly string NativeCreatedFileTimeUtc;
  internal readonly string ManifestHash;
  [DllImport("kernel32.dll",SetLastError=true)] static extern uint ResumeThread(FixtureKernelHandle thread);
  [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(FixtureKernelHandle handle,uint ms);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeProcess(FixtureKernelHandle process,out uint code);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateProcess(FixtureKernelHandle process,uint code);
  [StructLayout(LayoutKind.Sequential)] struct FileTime {internal uint Low,High;internal long Ticks=>((long)High<<32)|Low;}
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(FixtureKernelHandle process,out FileTime creation,out FileTime exit,out FileTime kernel,out FileTime user);
  internal InheritedSourceFixtureProcess(IntPtr processHandle,IntPtr threadHandle,uint pid,string manifestHash){process=new FixtureKernelHandle(processHandle);thread=new FixtureKernelHandle(threadHandle);Pid=pid;ManifestHash=manifestHash;FileTime birth,exit,kernel,user;if(!GetProcessTimes(process,out birth,out exit,out kernel,out user)){try{Dispose();}finally{throw new InvalidOperationException("fixture_creation_time_unverified");}}NativeCreatedFileTimeUtc=birth.Ticks.ToString(CultureInfo.InvariantCulture);}
  internal void Resume(){if(disposed||resumed)throw new InvalidOperationException("fixture_resume_refused");if(ResumeThread(thread)!=1)throw new InvalidOperationException("fixture_resume_unverified");resumed=true;}
  internal bool WaitForExit(int milliseconds){if(disposed||milliseconds<0||milliseconds>15000)throw new InvalidOperationException("fixture_wait_refused");uint value=WaitForSingleObject(process,(uint)milliseconds);if(value==0)return true;if(value==258)return false;throw new InvalidOperationException("fixture_exit_unverified");}
  internal uint ExitCode(){uint code;if(disposed||!WaitForExit(0)||!GetExitCodeProcess(process,out code))throw new InvalidOperationException("fixture_exit_unverified");return code;}
  internal void TerminateOwnedFixture(){if(disposed||WaitForExit(0))throw new InvalidOperationException("fixture_forced_exit_refused");if(!TerminateProcess(process,91)||!WaitForExit(5000)||ExitCode()!=91)throw new InvalidOperationException("fixture_forced_exit_unverified");}
  public void Dispose(){if(disposed)return;try{if(!WaitForExit(0)){if(!TerminateProcess(process,91)||!WaitForExit(5000))throw new InvalidOperationException("fixture_cleanup_unverified");}}finally{disposed=true;thread.Dispose();process.Dispose();}}
 }
 internal static class InheritedSourceFixtureSpawn {
  internal const string Scope="source-inheritance-fixture-only-no-policy-commit";
  static readonly object CreationGate=new object();
  [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct StartupInfo {
   internal uint Cb;internal IntPtr Reserved,Desktop,Title;internal uint X,Y,XSize,YSize,XCount,YCount,Fill,Flags;internal ushort Show,ReservedBytes;internal IntPtr ReservedData,Input,Output,Error;
  }
  [StructLayout(LayoutKind.Sequential)] struct StartupInfoEx {internal StartupInfo Startup;internal IntPtr Attributes;}
  [StructLayout(LayoutKind.Sequential)] struct ProcessInfo {internal IntPtr Process,Thread;internal uint Pid,Tid;}
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool InitializeProcThreadAttributeList(IntPtr list,int count,uint flags,ref UIntPtr size);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool UpdateProcThreadAttribute(IntPtr list,uint flags,UIntPtr attribute,IntPtr value,UIntPtr bytes,IntPtr previous,IntPtr returned);
  [DllImport("kernel32.dll")] static extern void DeleteProcThreadAttributeList(IntPtr list);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CreateProcessW(string image,StringBuilder command,IntPtr processAttributes,IntPtr threadAttributes,bool inherit,uint flags,IntPtr environment,string directory,ref StartupInfoEx startup,out ProcessInfo information);
  [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool DuplicateHandle(IntPtr sourceProcess,SafeHandle source,IntPtr targetProcess,out FixtureKernelHandle target,uint access,bool inherit,uint options);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetHandleInformation(SafeHandle handle,out uint flags);
  internal static string Quote(string value){
   if(value==null||value.Length>4096||value.IndexOfAny(new[]{'\0','\r','\n'})>=0)throw new InvalidOperationException("fixture_argument_refused");
   var text=new StringBuilder("\"");int slashes=0;foreach(char c in value){if(c=='\\'){slashes++;continue;}if(c=='\"'){text.Append('\\',slashes*2+1).Append(c);slashes=0;continue;}text.Append('\\',slashes).Append(c);slashes=0;}return text.Append('\\',slashes*2).Append('"').ToString();
  }
  internal static InheritedSourceFixtureProcess CreateSuspended(HeldSourceFiles source,string image,string directory,IReadOnlyList<SafeHandle> channels,Func<IReadOnlyList<long>,IReadOnlyList<long>,string[]> fixtureArguments,CancellationToken cancellation){
   if(source==null||channels==null||channels.Count>4||fixtureArguments==null||String.IsNullOrEmpty(directory))throw new InvalidOperationException("fixture_spawn_context_required");
   if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException("windows_source_inheritance_required");
   // No other component in this dedicated fixture may start a process while
   // inheritable duplicates exist. This lock is not a general host-wide guarantee.
   lock(CreationGate)return source.WithInheritableDuplicates(image,sourceHandles=>{
    var channelCopies=new List<FixtureKernelHandle>();IntPtr list=IntPtr.Zero,values=IntPtr.Zero;bool initialized=false;
    try{
     foreach(var channel in channels){if(channel==null||channel.IsClosed||channel.IsInvalid)throw new InvalidOperationException("fixture_channel_unverified");FixtureKernelHandle copy;if(!DuplicateHandle(GetCurrentProcess(),channel,GetCurrentProcess(),out copy,0,true,2)){if(copy!=null)copy.Dispose();throw new InvalidOperationException("fixture_channel_duplication_unverified");}channelCopies.Add(copy);}
     var handles=sourceHandles.Cast<SafeHandle>().Concat(channelCopies).ToArray();if(handles.Length<1||handles.Length>2180)throw new InvalidOperationException("fixture_handle_limit");foreach(var handle in handles){uint flags;if(!GetHandleInformation(handle,out flags)||(flags&1)==0)throw new InvalidOperationException("fixture_inheritability_unverified");}
     var raw=sourceHandles.Select(x=>x.DangerousGetHandle().ToInt64()).ToArray();var rawChannels=channelCopies.Select(x=>x.DangerousGetHandle().ToInt64()).ToArray();var arguments=fixtureArguments(Array.AsReadOnly(raw),Array.AsReadOnly(rawChannels));if(arguments==null||arguments.Length<1||arguments.Length>32||arguments[0]!="--gw-source-inheritance-child")throw new InvalidOperationException("fixture_child_marker_required");
     string command=String.Join(" ",new[]{image}.Concat(arguments).Select(Quote));if(command.Length>30000)throw new InvalidOperationException("fixture_command_limit");
     UIntPtr size=UIntPtr.Zero;bool unexpected=InitializeProcThreadAttributeList(IntPtr.Zero,1,0,ref size);if(unexpected||Marshal.GetLastWin32Error()!=122||size.ToUInt64()==0||size.ToUInt64()>1048576)throw new InvalidOperationException("fixture_attribute_size_unverified");
     list=Marshal.AllocHGlobal(checked((int)size.ToUInt64()));if(!InitializeProcThreadAttributeList(list,1,0,ref size))throw new InvalidOperationException("fixture_attribute_initialization_unverified");initialized=true;
     values=Marshal.AllocHGlobal(checked(handles.Length*IntPtr.Size));for(int i=0;i<handles.Length;i++)Marshal.WriteIntPtr(values,i*IntPtr.Size,handles[i].DangerousGetHandle());
     if(!UpdateProcThreadAttribute(list,0,(UIntPtr)0x00020002,values,(UIntPtr)(uint)(handles.Length*IntPtr.Size),IntPtr.Zero,IntPtr.Zero))throw new InvalidOperationException("fixture_handle_list_unverified");
     cancellation.ThrowIfCancellationRequested();var startup=new StartupInfoEx();startup.Startup.Cb=(uint)Marshal.SizeOf<StartupInfoEx>();startup.Attributes=list;ProcessInfo result;
     if(!CreateProcessW(image,new StringBuilder(command),IntPtr.Zero,IntPtr.Zero,true,0x00080000|0x00000004|0x08000000|0x00000400,IntPtr.Zero,directory,ref startup,out result))throw new InvalidOperationException("fixture_process_creation_unverified");
     // The returned original process/thread handles, never a PID lookup, own all
     // subsequent waits, resume and fixture-only cleanup.
     var child=new InheritedSourceFixtureProcess(result.Process,result.Thread,result.Pid,source.ManifestHash);try{cancellation.ThrowIfCancellationRequested();return child;}catch{child.Dispose();throw;}
    }finally{if(initialized)DeleteProcThreadAttributeList(list);if(list!=IntPtr.Zero)Marshal.FreeHGlobal(list);if(values!=IntPtr.Zero)Marshal.FreeHGlobal(values);foreach(var channel in channelCopies)channel.Dispose();}
   },cancellation);
  }
 }
}
