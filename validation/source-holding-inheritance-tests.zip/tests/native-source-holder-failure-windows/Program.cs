// Dedicated Windows dummy test. The root test entry accepts no existing paths or PIDs.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using Microsoft.Win32.SafeHandles;
using GlassWidgets.ServerControlPrep;
internal static class SourceHolderFailureAcceptance {
 const string Marker="--gw-source-inheritance-child";
 static readonly JsonSerializerOptions Json=new JsonSerializerOptions{IncludeFields=true};
 static int checks;
 public sealed class Plan {public SourceFileSpec[] Files{get;set;}public string Nonce{get;set;}public string Delayed{get;set;}public string Sha256{get;set;}public string Manifest{get;set;}}
 [StructLayout(LayoutKind.Sequential)] struct FileTime {public uint Low,High;public long Ticks=>((long)High<<32)|Low;}
 [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool DuplicateHandle(IntPtr sourceProcess,IntPtr source,IntPtr targetProcess,out IntPtr target,uint access,bool inherit,uint options);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetHandleInformation(IntPtr handle,uint mask,uint flags);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetHandleInformation(IntPtr handle,out uint flags);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetProcessId(FixtureKernelHandle process);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(FixtureKernelHandle process,out FileTime birth,out FileTime exit,out FileTime kernel,out FileTime user);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeProcess(FixtureKernelHandle process,out uint code);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateProcess(FixtureKernelHandle process,uint code);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(FixtureKernelHandle handle,uint milliseconds);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(IntPtr handle,uint milliseconds);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageNameW(FixtureKernelHandle process,uint flags,StringBuilder path,ref uint length);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetFinalPathNameByHandleW(SafeFileHandle file,StringBuilder path,uint length,uint flags);
 static void Require(bool value){if(!value)throw new InvalidOperationException("holder_failure_acceptance_assertion");}
 static void Check(string name,Action test){test();checks++;Console.WriteLine("ok "+name);}
 static string Hash(byte[] bytes)=>Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
 static string Canonical(SafeFileHandle file){var value=new StringBuilder(32768);uint size=GetFinalPathNameByHandleW(file,value,32768,0);Require(size>0&&size<32768&&value.ToString().StartsWith("\\\\?\\",StringComparison.Ordinal));return value.ToString().Substring(4);}
 static SourceFileSpec Spec(string path){using(var file=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)){byte[] bytes=File.ReadAllBytes(path);return new SourceFileSpec(Canonical(file.SafeFileHandle),bytes.Length,Hash(bytes));}}
 static string Encode(Plan plan)=>JsonSerializer.Serialize(plan,Json);
 static Plan Decode(string value){Require(value!=null&&value.Length<4096);var plan=JsonSerializer.Deserialize<Plan>(value,Json);Require(plan!=null&&plan.Files!=null&&plan.Files.Length==5&&plan.Nonce!=null&&plan.Nonce.Length==48&&plan.Manifest==HeldSourceFiles.HashManifest(plan.Files));Require(plan.Files.Any(x=>x.Path==plan.Delayed&&x.Sha256==plan.Sha256));return plan;}
 static long[] Numbers(string value){var parts=value.Split(',');Require(parts.Length>0&&parts.Length<2180);return parts.Select(x=>{long n=long.Parse(x,NumberStyles.None,CultureInfo.InvariantCulture);Require(n>0);return n;}).ToArray();}
 static string Join(IEnumerable<long> values)=>String.Join(",",values.Select(x=>x.ToString(CultureInfo.InvariantCulture)));
 static void ClearInherit(long value){Require(SetHandleInformation(new IntPtr(value),1,0));uint flags;Require(GetHandleInformation(new IntPtr(value),out flags)&&(flags&1)==0);}
 static List<SafeFileHandle> OwnSourceHandles(string value){var held=new List<SafeFileHandle>();try{foreach(long number in Numbers(value)){ClearInherit(number);held.Add(new SafeFileHandle(new IntPtr(number),true));}return held;}catch{foreach(var handle in held)handle.Dispose();throw;}}
 static JsonDocument Packet(StreamReader reader){string line=reader.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(8)).GetAwaiter().GetResult();Require(line!=null&&line.Length<16384);return JsonDocument.Parse(line);}
 static void Refused(Action action){try{action();}catch(IOException){return;}catch(UnauthorizedAccessException){return;}throw new InvalidOperationException("fixture_source_write_not_refused");}
 sealed class ExactChild:IDisposable {
  readonly FixtureKernelHandle handle;bool disposed;
  internal ExactChild(long raw,uint pid,string birth,string image){handle=new FixtureKernelHandle(new IntPtr(raw));try{Require(!handle.IsInvalid&&GetProcessId(handle)==pid);FileTime b,e,k,u;Require(GetProcessTimes(handle,out b,out e,out k,out u)&&b.Ticks.ToString(CultureInfo.InvariantCulture)==birth);var path=new StringBuilder(32768);uint length=32768;Require(QueryFullProcessImageNameW(handle,0,path,ref length)&&String.Equals(path.ToString(),image,StringComparison.OrdinalIgnoreCase));}catch{handle.Dispose();throw;}}
  internal bool Exited(uint milliseconds){uint result=WaitForSingleObject(handle,milliseconds);Require(result==0||result==258);return result==0;}
  internal uint ExitCode(){uint value=0;Require(Exited(0)&&GetExitCodeProcess(handle,out value));return value;}
  public void Dispose(){if(disposed)return;try{if(!Exited(0))Require(TerminateProcess(handle,92)&&Exited(5000));}finally{disposed=true;handle.Dispose();}}
 }
 static int Holder(string[] args){
  Require(args.Length==6);Plan plan=Decode(args[4]);Require(args[5]==plan.Nonce);long[] channels=Numbers(args[3]);Require(channels.Length==3);foreach(long handle in channels)ClearInherit(handle);
  var inherited=OwnSourceHandles(args[2]);HeldSourceFiles source=null;InheritedSourceFixtureProcess child=null;
  try{
   source=HeldSourceFiles.Acquire(plan.Files,CancellationToken.None);foreach(var handle in inherited)handle.Dispose();inherited.Clear();
   string image=plan.Files.Single(x=>x.Path.EndsWith(".exe",StringComparison.OrdinalIgnoreCase)).Path;
   using(var eventHandle=new SafeWaitHandle(new IntPtr(channels[0]),true))using(var pipeHandle=new SafePipeHandle(new IntPtr(channels[1]),true))using(var peer=new FixtureKernelHandle(new IntPtr(channels[2])))using(var pipe=new AnonymousPipeClientStream(PipeDirection.Out,pipeHandle))using(var writer=new StreamWriter(pipe,new UTF8Encoding(false),1024,true){AutoFlush=true}){
    child=InheritedSourceFixtureSpawn.CreateSuspended(source,image,Path.GetDirectoryName(image),new SafeHandle[]{eventHandle,pipeHandle,peer},(held,copied)=>new[]{Marker,"reader",Join(held),Join(copied),Encode(plan),plan.Nonce},CancellationToken.None);
    // The original creation handles attest to the child before it can write.
    writer.WriteLine(JsonSerializer.Serialize(new {phase="created",pid=child.Pid,birth=child.NativeCreatedFileTimeUtc,nonce=plan.Nonce,manifest=source.ManifestHash}));child.Resume();
    // Root deliberately terminates this process while it waits here. TerminateProcess
    // bypasses these finally blocks, so child source protection cannot depend on them.
    if(!child.WaitForExit(15000))return 72;return 73;
   }
  }finally{if(child!=null)child.Dispose();if(source!=null)source.Dispose();foreach(var handle in inherited)handle.Dispose();}
 }
 static int Reader(string[] args){
  Require(args.Length==6);Plan plan=Decode(args[4]);Require(args[5]==plan.Nonce);var held=OwnSourceHandles(args[2]);long[] channels=Numbers(args[3]);Require(channels.Length==3);foreach(long handle in channels)ClearInherit(handle);
  try{using(var signal=new SafeWaitHandle(new IntPtr(channels[0]),true))using(var pipe=new AnonymousPipeClientStream(PipeDirection.Out,new SafePipeHandle(new IntPtr(channels[1]),true)))using(var peer=new FixtureKernelHandle(new IntPtr(channels[2])))using(var writer=new StreamWriter(pipe,new UTF8Encoding(false),1024,true){AutoFlush=true}){
   IntPtr originalCopy;Require(DuplicateHandle(GetCurrentProcess(),GetCurrentProcess(),peer.DangerousGetHandle(),out originalCopy,0x00101001,false,0));
   // Query self through an owned real handle, never a PID reopen.
   IntPtr localCopy;Require(DuplicateHandle(GetCurrentProcess(),GetCurrentProcess(),GetCurrentProcess(),out localCopy,0x00101000,false,0));
   using(var original=new FixtureKernelHandle(localCopy)){FileTime b,e,k,u;Require(GetProcessTimes(original,out b,out e,out k,out u));writer.WriteLine(JsonSerializer.Serialize(new {phase="ready",pid=Environment.ProcessId,birth=b.Ticks.ToString(CultureInfo.InvariantCulture),ownedHandle=originalCopy.ToInt64(),nonce=plan.Nonce,manifest=plan.Manifest}));}
   if(WaitForSingleObject(signal.DangerousGetHandle(),10000)!=0)return 74;
   string hash=Hash(File.ReadAllBytes(plan.Delayed));Require(hash==plan.Sha256);writer.WriteLine(JsonSerializer.Serialize(new {phase="delayed-read",pid=Environment.ProcessId,sha256=hash,nonce=plan.Nonce}));
   if(WaitForSingleObject(signal.DangerousGetHandle(),10000)!=0)return 75;
  }return 0;}finally{foreach(var handle in held)handle.Dispose();}
 }
 static int Main(string[] args){
  if(args.Length==1&&args[0]=="--portable-plan-check"){
   var files=new[]{"fixture.exe","fixture.dll","fixture.deps.json","fixture.runtimeconfig.json","late source.js"}.Select(x=>new SourceFileSpec("C:\\gw-fixture\\"+x,1,new string('a',64))).ToArray();
   var plan=new Plan{Files=files,Nonce=new string('b',48),Delayed=files[4].Path,Sha256=files[4].Sha256,Manifest=HeldSourceFiles.HashManifest(files)};var copy=Decode(Encode(plan));Require(copy.Manifest==plan.Manifest&&copy.Nonce==plan.Nonce&&copy.Files.Length==5&&copy.Files[4].Path==plan.Delayed);
   Console.WriteLine(JsonSerializer.Serialize(new {checks=1,scope="portable fixture plan serialization only",nativeWindowsHolderFailureExecution=false,abruptOriginalHelperDeathExecuted=false,completeSourceLifetimeProof=false}));return 0;
  }
  if(!OperatingSystem.IsWindows()){Console.Error.WriteLine("windows_holder_failure_acceptance_not_executed");return 2;}
  if(args.Length>0){Require(args[0]==Marker);return args[1]=="holder"?Holder(args):args[1]=="reader"?Reader(args):76;}
  string root=Path.Combine(Path.GetTempPath(),"gw holder failure "+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);HeldSourceFiles source=null;InheritedSourceFixtureProcess holder=null;ExactChild child=null;
  try{
   var output=Directory.GetFiles(AppContext.BaseDirectory,"*",SearchOption.TopDirectoryOnly);Require(output.Length<=512&&output.Sum(x=>new FileInfo(x).Length)<=268435456);foreach(string original in output)File.Copy(original,Path.Combine(root,Path.GetFileName(original)),false);
   string name=Assembly.GetExecutingAssembly().GetName().Name;var files=new List<string>();foreach(string suffix in new[]{".exe",".dll",".deps.json",".runtimeconfig.json"})files.Add(Path.Combine(root,name+suffix));string delayed=Path.Combine(root,"late source.js");File.WriteAllText(delayed,"// own delayed failure fixture\n",new UTF8Encoding(false));files.Add(delayed);var specs=files.Select(Spec).ToArray();string image=specs.Single(x=>x.Path.EndsWith(".exe",StringComparison.OrdinalIgnoreCase)).Path;var late=specs.Single(x=>x.Path.EndsWith("late source.js",StringComparison.Ordinal));var plan=new Plan{Files=specs,Nonce=Convert.ToHexString(RandomNumberGenerator.GetBytes(24)).ToLowerInvariant(),Delayed=late.Path,Sha256=late.Sha256,Manifest=HeldSourceFiles.HashManifest(specs)};
   IntPtr peerRaw;Require(DuplicateHandle(GetCurrentProcess(),GetCurrentProcess(),GetCurrentProcess(),out peerRaw,0x1040,false,0));
   using(var peer=new FixtureKernelHandle(peerRaw))using(var signal=new EventWaitHandle(false,EventResetMode.AutoReset))using(var pipe=new AnonymousPipeServerStream(PipeDirection.In,HandleInheritability.None))using(var reader=new StreamReader(pipe,new UTF8Encoding(false),false,1024,true)){
    source=HeldSourceFiles.Acquire(specs,CancellationToken.None);holder=InheritedSourceFixtureSpawn.CreateSuspended(source,image,Path.GetDirectoryName(image),new SafeHandle[]{signal.SafeWaitHandle,pipe.ClientSafePipeHandle,peer},(held,copied)=>new[]{Marker,"holder",Join(held),Join(copied),Encode(plan),plan.Nonce},CancellationToken.None);holder.Resume();pipe.DisposeLocalCopyOfClientHandle();
    using(var createdPacket=Packet(reader))using(var readyPacket=Packet(reader)){var created=createdPacket.RootElement;var ready=readyPacket.RootElement;Require(created.GetProperty("phase").GetString()=="created"&&ready.GetProperty("phase").GetString()=="ready");Require(created.GetProperty("nonce").GetString()==plan.Nonce&&ready.GetProperty("nonce").GetString()==plan.Nonce&&created.GetProperty("manifest").GetString()==plan.Manifest&&ready.GetProperty("manifest").GetString()==plan.Manifest);uint pid=created.GetProperty("pid").GetUInt32();string birth=created.GetProperty("birth").GetString();Require(pid==ready.GetProperty("pid").GetUInt32()&&birth==ready.GetProperty("birth").GetString()&&long.Parse(birth,CultureInfo.InvariantCulture)>=long.Parse(holder.NativeCreatedFileTimeUtc,CultureInfo.InvariantCulture));child=new ExactChild(ready.GetProperty("ownedHandle").GetInt64(),pid,birth,image);}
    Check("original holder creation identity and original transferred child handle agree",()=>Require(!holder.WaitForExit(0)&&!child.Exited(0)));
    source.Dispose();source=null;holder.TerminateOwnedFixture();
    Check("original helper handle proves abrupt TerminateProcess exit without managed cleanup",()=>Require(holder.WaitForExit(0)&&holder.ExitCode()==91));holder.Dispose();holder=null;
    Check("source write and delete stay refused after helper death while original child lives",()=>{Require(!child.Exited(0));Refused(()=>File.WriteAllText(late.Path,"changed"));Refused(()=>File.Delete(late.Path));});
    Check("source ancestor cannot be renamed after helper death",()=>Refused(()=>Directory.Move(root,root+" renamed")));
    Check("ordinary sibling fixture data remains writable after helper death",()=>{string data=Path.Combine(root,"ordinary data.json");File.WriteAllText(data,"{}");Require(File.ReadAllText(data)=="{}");});
    signal.Set();using(var loaded=Packet(reader)){var value=loaded.RootElement;Check("delayed source read after helper death returns the original reviewed bytes",()=>Require(value.GetProperty("phase").GetString()=="delayed-read"&&value.GetProperty("sha256").GetString()==late.Sha256&&value.GetProperty("nonce").GetString()==plan.Nonce));}
    Check("inherited protection remains after delayed read until original child exit",()=>{Require(!child.Exited(0));Refused(()=>File.WriteAllText(late.Path,"changed again"));});
    signal.Set();Check("original child process handle proves successful reader exit",()=>Require(child.Exited(5000)&&child.ExitCode()==0));child.Dispose();child=null;
    Check("source write access returns after original child exit following helper death",()=>{File.WriteAllText(late.Path,"released");Require(File.ReadAllText(late.Path)=="released");});
   }
   Console.WriteLine(JsonSerializer.Serialize(new {checks,ownTemporaryFixturesOnly=true,nativeWindowsHolderFailureExecution=true,abruptOriginalHelperDeathExecuted=true,originalChildHandleTransferredBeforeHelperDeath=true,nodeRuntimeInheritanceCompatibility=false,normalUserPrivilegesVerified=false,productionPolicyCommitIntegrated=false,completeSourceLifetimeProof=false}));return 0;
  }finally{try{if(child!=null)child.Dispose();}finally{try{if(holder!=null)holder.Dispose();}finally{if(source!=null)source.Dispose();for(int n=0;;n++){try{Directory.Delete(root,true);break;}catch(IOException)when(n<60){Thread.Sleep(200);}catch(UnauthorizedAccessException)when(n<60){Thread.Sleep(200);}}}}}
 }
}
