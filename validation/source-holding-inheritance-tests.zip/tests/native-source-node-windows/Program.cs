// Dedicated Windows dummy test. The root test entry accepts no existing paths or PIDs.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using Microsoft.Win32.SafeHandles;
using GlassWidgets.ServerControlPrep;
internal static class SourceNodeInheritanceAcceptance {
 const string NodeExeSha256="528a9aa64888a2a3ba71c6aea89434dd5ab5cb3caa9f0f31345cf5facf685ab0";
 const string Marker="--gw-source-inheritance-child";
 static readonly JsonSerializerOptions Json=new JsonSerializerOptions{IncludeFields=true};
 static int checks;
 public sealed class Plan {public SourceFileSpec[] Files{get;set;}public string Nonce{get;set;}public string Delayed{get;set;}public string Sha256{get;set;}public string Manifest{get;set;}public string HolderImage{get;set;}public string NodeImage{get;set;}public string Reader{get;set;}public uint PeerPid{get;set;}public string Signal{get;set;}public string Ready{get;set;}public string Loaded{get;set;}public string Done{get;set;}}
 [StructLayout(LayoutKind.Sequential)] struct FileTime {public uint Low,High;public long Ticks=>((long)High<<32)|Low;}
 [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool DuplicateHandle(IntPtr sourceProcess,IntPtr source,IntPtr targetProcess,out IntPtr target,uint access,bool inherit,uint options);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetHandleInformation(IntPtr handle,uint mask,uint flags);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetHandleInformation(IntPtr handle,out uint flags);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetProcessId(FixtureKernelHandle process);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(FixtureKernelHandle process,out FileTime birth,out FileTime exit,out FileTime kernel,out FileTime user);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeProcess(FixtureKernelHandle process,out uint code);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateProcess(FixtureKernelHandle process,uint code);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(FixtureKernelHandle handle,uint milliseconds);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(IntPtr handle,uint milliseconds);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageNameW(FixtureKernelHandle process,uint flags,StringBuilder path,ref uint length);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetFinalPathNameByHandleW(SafeFileHandle file,StringBuilder path,uint length,uint flags);
 static void Require(bool value){if(!value)throw new InvalidOperationException("holder_failure_acceptance_assertion");}
 static void Check(string name,Action test){test();checks++;Console.WriteLine("ok "+name);}
 static string Hash(byte[] bytes)=>Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
 static string Canonical(SafeFileHandle file){var value=new StringBuilder(32768);uint size=GetFinalPathNameByHandleW(file,value,32768,0);Require(size>0&&size<32768&&value.ToString().StartsWith("\\\\?\\",StringComparison.Ordinal));return value.ToString().Substring(4);}
 static SourceFileSpec Spec(string path){using(var file=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)){byte[] bytes=File.ReadAllBytes(path);return new SourceFileSpec(Canonical(file.SafeFileHandle),bytes.Length,Hash(bytes));}}
 static string Encode(Plan plan)=>JsonSerializer.Serialize(plan,Json);
 static Plan Decode(string value){Require(value!=null&&value.Length<4096);var plan=JsonSerializer.Deserialize<Plan>(value,Json);Require(plan!=null&&plan.Files!=null&&plan.Files.Length==7&&plan.Nonce!=null&&plan.Nonce.Length==48&&plan.Manifest==HeldSourceFiles.HashManifest(plan.Files));Require(plan.Files.Any(x=>x.Path==plan.Delayed&&x.Sha256==plan.Sha256));Require(plan.PeerPid>0&&plan.Files.Any(x=>x.Path==plan.HolderImage)&&plan.Files.Any(x=>x.Path==plan.NodeImage)&&plan.Files.Any(x=>x.Path==plan.Reader));return plan;}
 static long[] Numbers(string value){var parts=value.Split(',');Require(parts.Length>0&&parts.Length<2180);return parts.Select(x=>{long n=long.Parse(x,NumberStyles.None,CultureInfo.InvariantCulture);Require(n>0);return n;}).ToArray();}
 static string Join(IEnumerable<long> values)=>String.Join(",",values.Select(x=>x.ToString(CultureInfo.InvariantCulture)));
 static void ClearInherit(long value){Require(SetHandleInformation(new IntPtr(value),1,0));uint flags;Require(GetHandleInformation(new IntPtr(value),out flags)&&(flags&1)==0);}
 static List<SafeFileHandle> OwnSourceHandles(string value){var held=new List<SafeFileHandle>();try{foreach(long number in Numbers(value)){ClearInherit(number);held.Add(new SafeFileHandle(new IntPtr(number),true));}return held;}catch{foreach(var handle in held)handle.Dispose();throw;}}
 static JsonDocument Packet(StreamReader reader){string line=reader.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(8)).GetAwaiter().GetResult();Require(line!=null&&line.Length<16384);return JsonDocument.Parse(line);}
 static void Refused(Action action){try{action();}catch(IOException){return;}catch(UnauthorizedAccessException){return;}throw new InvalidOperationException("fixture_source_write_not_refused");}
 sealed class ExactChild:IDisposable {
  readonly FixtureKernelHandle handle;bool disposed;
  internal ExactChild(long raw,uint pid,string birth,string image){handle=new FixtureKernelHandle(new IntPtr(raw));try{Require(!handle.IsInvalid&&GetProcessId(handle)==pid);FileTime b,e,k,u;Require(GetProcessTimes(handle,out b,out e,out k,out u)&&b.Ticks.ToString(CultureInfo.InvariantCulture)==birth);var path=new StringBuilder(32768);uint length=32768;Require(QueryFullProcessImageNameW(handle,0,path,ref length)&&String.Equals(path.ToString(),image,StringComparison.OrdinalIgnoreCase));}catch{handle.Dispose();throw;}}
  internal bool Exited(uint milliseconds){uint result=WaitForSingleObject(handle,milliseconds);Require(result==0||result==258);return result==0;}
  internal uint ExitCode(){uint value=0;Require(Exited(0)&&GetExitCodeProcess(handle,out value));return value;}
  public void Dispose(){if(disposed)return;try{if(!Exited(0))Require(TerminateProcess(handle,92)&&Exited(5000));}finally{disposed=true;handle.Dispose();}}
 }
 static readonly string NodeReader=@"'use strict';
const fs=require('fs'),crypto=require('crypto');
if(process.argv.length!==4||process.argv[2]!=='--gw-source-inheritance-child')process.exit(31);
const p=JSON.parse(process.argv[3]);
function emit(file,value){const temp=file+'.tmp';fs.writeFileSync(temp,JSON.stringify(value),{encoding:'utf8',flag:'wx'});fs.renameSync(temp,file)}
function wait(file,done){const start=Date.now(),timer=setInterval(()=>{try{if(fs.existsSync(file)&&fs.readFileSync(file,'utf8')===p.Nonce){clearInterval(timer);done()}else if(Date.now()-start>10000){clearInterval(timer);process.exit(32)}}catch(e){clearInterval(timer);process.exit(33)}},20)}
if(process.version!=='v20.18.3')process.exit(34);
emit(p.Ready,{phase:'ready',nonce:p.Nonce,version:process.version,uv:process.versions.uv,pid:process.pid});
wait(p.Signal+'1',()=>{try{const value=require(p.Delayed);const hash=crypto.createHash('sha256').update(fs.readFileSync(p.Delayed)).digest('hex');if(value.value!==p.Nonce||hash!==p.Sha256)process.exit(35);emit(p.Loaded,{phase:'delayed-require',nonce:p.Nonce,sha256:hash,value:value.value,pid:process.pid});wait(p.Signal+'2',()=>{emit(p.Done,{phase:'done',nonce:p.Nonce,pid:process.pid});process.exit(0)})}catch(e){process.exit(36)}});
";
 static int Holder(string[] args){
  Require(args.Length==6);var plan=Decode(args[4]);Require(args[5]==plan.Nonce);var channels=Numbers(args[3]);Require(channels.Length==2);foreach(long raw in channels)ClearInherit(raw);var inherited=OwnSourceHandles(args[2]);HeldSourceFiles source=null;InheritedSourceFixtureProcess child=null;
  try{
   source=HeldSourceFiles.Acquire(plan.Files,CancellationToken.None);foreach(var handle in inherited)handle.Dispose();inherited.Clear();
   using(var pipeHandle=new SafePipeHandle(new IntPtr(channels[0]),true))using(var peer=new FixtureKernelHandle(new IntPtr(channels[1])))using(var pipe=new AnonymousPipeClientStream(PipeDirection.Out,pipeHandle))using(var writer=new StreamWriter(pipe,new UTF8Encoding(false),1024,true){AutoFlush=true}){
    child=InheritedSourceFixtureSpawn.CreateSuspended(source,plan.NodeImage,Path.GetDirectoryName(plan.NodeImage),Array.Empty<SafeHandle>(),(held,copied)=>new[]{"--",plan.Reader,Marker,Encode(plan)},CancellationToken.None,plan.Reader);
    long original=child.DuplicateOriginalProcessForFixturePeer(peer,plan.PeerPid);
    writer.WriteLine(JsonSerializer.Serialize(new {phase="created-node",pid=child.Pid,birth=child.NativeCreatedFileTimeUtc,nonce=plan.Nonce,manifest=source.ManifestHash,ownedHandle=original,sealedSourceHandles=child.SealedInheritedSourceCount}));child.Resume();
    if(!child.WaitForExit(15000))return 72;return 73;
   }
  }finally{if(child!=null)child.Dispose();if(source!=null)source.Dispose();foreach(var handle in inherited)handle.Dispose();}
 }
 static JsonDocument NodePacket(string file,ExactChild child){
  var clock=System.Diagnostics.Stopwatch.StartNew();
  while(clock.ElapsedMilliseconds<8000){if(File.Exists(file)){var info=new FileInfo(file);Require((info.Attributes&FileAttributes.ReparsePoint)==0&&info.Length>0&&info.Length<16384);return JsonDocument.Parse(File.ReadAllText(file));}Require(!child.Exited(0));Thread.Sleep(20);}throw new InvalidOperationException("node_fixture_phase_timeout");
 }
 static int Main(string[] args){
  if(args.Length==1&&args[0]=="--portable-plan-check"){
   var names=new[]{"fixture.exe","fixture.dll","fixture.deps.json","fixture.runtimeconfig.json","node.exe","gw-node-source-reader-fixture.cjs","delayed.cjs"};var files=names.Select(x=>new SourceFileSpec("C:\\gw-fixture\\"+x,1,new string('a',64))).ToArray();var plan=new Plan{Files=files,Nonce=new string('b',48),Delayed=files[6].Path,Sha256=files[6].Sha256,Manifest=HeldSourceFiles.HashManifest(files),HolderImage=files[0].Path,NodeImage=files[4].Path,Reader=files[5].Path,PeerPid=1,Signal="C:\\gw-fixture\\signal-",Ready="C:\\gw-fixture\\ready.json",Loaded="C:\\gw-fixture\\loaded.json",Done="C:\\gw-fixture\\done.json"};var copy=Decode(Encode(plan));Require(copy.Manifest==plan.Manifest&&copy.NodeImage==plan.NodeImage&&copy.PeerPid==1);
   Console.WriteLine(JsonSerializer.Serialize(new {checks=1,scope="portable Node fixture plan serialization only",nativeWindowsNodeInheritanceExecution=false,nodeRuntimeInheritanceCompatibility=false,productionPolicyCommitIntegrated=false}));return 0;
  }
  if(!OperatingSystem.IsWindows()){Console.Error.WriteLine("windows_node_source_acceptance_not_executed");return 2;}
  if(args.Length>0){Require(args[0]==Marker&&args[1]=="holder");return Holder(args);}
  string originalNode=Environment.GetEnvironmentVariable("GW_NODE_SOURCE_FIXTURE_PATH");Require(originalNode!=null&&Path.IsPathFullyQualified(originalNode)&&File.Exists(originalNode));
  string root=Path.Combine(Path.GetTempPath(),"gw node source "+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);HeldSourceFiles source=null;InheritedSourceFixtureProcess holder=null;ExactChild child=null;
  try{
   var output=Directory.GetFiles(AppContext.BaseDirectory,"*",SearchOption.TopDirectoryOnly);Require(output.Length<=512&&output.Sum(x=>new FileInfo(x).Length)<=268435456);foreach(string original in output)File.Copy(original,Path.Combine(root,Path.GetFileName(original)),false);
   string node=Path.Combine(root,"node.exe");Require(!File.Exists(node));File.Copy(originalNode,node,false);
   Check("exact official standalone Node fixture binary matches the pinned source hash",()=>Require(Hash(File.ReadAllBytes(node))==NodeExeSha256));
   string nonce=Convert.ToHexString(RandomNumberGenerator.GetBytes(24)).ToLowerInvariant(),script=Path.Combine(root,"gw-node-source-reader-fixture.cjs"),delayed=Path.Combine(root,"delayed.cjs");File.WriteAllText(script,NodeReader,new UTF8Encoding(false));File.WriteAllText(delayed,"module.exports={value:"+JsonSerializer.Serialize(nonce)+"};\n",new UTF8Encoding(false));
   string name=Assembly.GetExecutingAssembly().GetName().Name;var files=new[]{".exe",".dll",".deps.json",".runtimeconfig.json"}.Select(x=>Path.Combine(root,name+x)).Concat(new[]{node,script,delayed}).Select(Spec).ToArray();string image=files.Single(x=>x.Path.EndsWith(name+".exe",StringComparison.Ordinal)).Path;var late=files.Single(x=>x.Path.EndsWith("delayed.cjs",StringComparison.Ordinal));var plan=new Plan{Files=files,Nonce=nonce,Delayed=late.Path,Sha256=late.Sha256,Manifest=HeldSourceFiles.HashManifest(files),HolderImage=image,NodeImage=files.Single(x=>x.Path.EndsWith("\\node.exe",StringComparison.Ordinal)).Path,Reader=files.Single(x=>x.Path.EndsWith("gw-node-source-reader-fixture.cjs",StringComparison.Ordinal)).Path,PeerPid=(uint)Environment.ProcessId,Signal=Path.Combine(root,"continue-"),Ready=Path.Combine(root,"node-ready.json"),Loaded=Path.Combine(root,"node-loaded.json"),Done=Path.Combine(root,"node-done.json")};
   IntPtr peerRaw;Require(DuplicateHandle(GetCurrentProcess(),GetCurrentProcess(),GetCurrentProcess(),out peerRaw,0x1040,false,0));
   string actualUv=null;uint originalNodePid=0;
   using(var peer=new FixtureKernelHandle(peerRaw))using(var pipe=new AnonymousPipeServerStream(PipeDirection.In,HandleInheritability.None))using(var reader=new StreamReader(pipe,new UTF8Encoding(false),false,1024,true)){
    source=HeldSourceFiles.Acquire(files,CancellationToken.None);holder=InheritedSourceFixtureSpawn.CreateSuspended(source,image,Path.GetDirectoryName(image),new SafeHandle[]{pipe.ClientSafePipeHandle,peer},(held,copied)=>new[]{Marker,"holder",Join(held),Join(copied),Encode(plan),nonce},CancellationToken.None);holder.Resume();pipe.DisposeLocalCopyOfClientHandle();
    using(var packet=Packet(reader)){var value=packet.RootElement;Require(value.GetProperty("phase").GetString()=="created-node"&&value.GetProperty("nonce").GetString()==nonce&&value.GetProperty("manifest").GetString()==plan.Manifest&&value.GetProperty("sealedSourceHandles").GetInt32()>=files.Length);uint pid=value.GetProperty("pid").GetUInt32();originalNodePid=pid;string birth=value.GetProperty("birth").GetString();Require(long.Parse(birth,CultureInfo.InvariantCulture)>=long.Parse(holder.NativeCreatedFileTimeUtc,CultureInfo.InvariantCulture));child=new ExactChild(value.GetProperty("ownedHandle").GetInt64(),pid,birth,plan.NodeImage);}
    Check("original Node creation handle binds image birth and sealed source handles before resume",()=>Require(!child.Exited(0)&&!holder.WaitForExit(0)));
    using(var packet=NodePacket(plan.Ready,child)){var value=packet.RootElement;actualUv=value.GetProperty("uv").GetString();Check("the exact standalone Node runtime reaches its own reviewed ready fixture",()=>Require(value.GetProperty("phase").GetString()=="ready"&&value.GetProperty("nonce").GetString()==nonce&&value.GetProperty("version").GetString()=="v20.18.3"&&value.GetProperty("pid").GetUInt32()==originalNodePid&&!String.IsNullOrEmpty(actualUv)));}
    source.Dispose();source=null;holder.TerminateOwnedFixture();Check("original helper handle proves abrupt exit before delayed Node module loading",()=>Require(holder.WaitForExit(0)&&holder.ExitCode()==91));holder.Dispose();holder=null;
    Check("opaque inherited source handles block writes and deletion while the original Node lives",()=>{Require(!child.Exited(0));Refused(()=>File.WriteAllText(plan.Delayed,"changed"));Refused(()=>File.Delete(plan.Delayed));});
    Check("Node-owned source ancestor rename remains refused after helper death",()=>Refused(()=>Directory.Move(root,root+" renamed")));
    Check("ordinary Node fixture data remains writable beside protected code",()=>{string data=Path.Combine(root,"ordinary-data.json");File.WriteAllText(data,"{}");Require(File.ReadAllText(data)=="{}");});
    File.WriteAllText(plan.Signal+"1",nonce);using(var packet=NodePacket(plan.Loaded,child)){var value=packet.RootElement;Check("actual delayed require after helper death loads the original module and bytes",()=>Require(value.GetProperty("phase").GetString()=="delayed-require"&&value.GetProperty("nonce").GetString()==nonce&&value.GetProperty("value").GetString()==nonce&&value.GetProperty("sha256").GetString()==plan.Sha256&&value.GetProperty("pid").GetUInt32()==originalNodePid));}
    Check("source stays protected after require until exact Node exit",()=>{Require(!child.Exited(0));Refused(()=>File.WriteAllText(plan.Delayed,"still changed"));});
    File.WriteAllText(plan.Signal+"2",nonce);Check("the original Node handle proves successful fixture exit",()=>Require(child.Exited(5000)&&child.ExitCode()==0));child.Dispose();child=null;
    Check("source writes return only after the original Node fixture exits",()=>{File.WriteAllText(plan.Delayed,"released");File.WriteAllText(plan.Reader,"released");Require(File.ReadAllText(plan.Delayed)=="released"&&File.ReadAllText(plan.Reader)=="released");});
   }
   Console.WriteLine(JsonSerializer.Serialize(new {checks,nodeVersion="v20.18.3",libuvVersion=actualUv,officialNodeExeSha256=NodeExeSha256,nativeWindowsNodeInheritanceExecution=true,abruptOriginalHelperDeathExecuted=true,sourceHandlesSealedNoninheritableBeforeResume=true,delayedCommonJsRequireExecuted=true,ownTemporaryFixturesOnly=true,installedServerRuntimeIdentified=false,nodeRuntimeInheritanceCompatibility="pinned standalone fixture only",normalUserPrivilegesVerified=false,productionPolicyCommitIntegrated=false,completeSourceLifetimeProof=false}));return 0;
  }finally{try{if(child!=null)child.Dispose();}finally{try{if(holder!=null)holder.Dispose();}finally{if(source!=null)source.Dispose();for(int n=0;;n++){try{Directory.Delete(root,true);break;}catch(IOException)when(n<60){Thread.Sleep(200);}catch(UnauthorizedAccessException)when(n<60){Thread.Sleep(200);}}}}}
 }
}
