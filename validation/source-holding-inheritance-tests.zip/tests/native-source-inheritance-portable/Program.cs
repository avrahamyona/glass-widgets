using System;using System.Linq;using System.Reflection;using System.Runtime.InteropServices;using System.Text.Json;using System.Threading;using GlassWidgets.ServerControlPrep;
internal static class InheritedSourcePortableTest {
 static int checks;static void Check(string name,Action action){action();checks++;Console.WriteLine("ok "+name);}static void Require(bool value){if(!value)throw new Exception("inheritance_portable_assertion");}
 static void Main(){
  Check("fixture primitive keeps an explicit nonproduction scope",()=>Require(InheritedSourceFixtureSpawn.Scope=="source-inheritance-fixture-only-no-policy-commit"));
  Check("empty and plain arguments are individually quoted",()=>{Require(InheritedSourceFixtureSpawn.Quote("")=="\"\"");Require(InheritedSourceFixtureSpawn.Quote("abc")=="\"abc\"");});
  Check("spaces tabs and Unicode are preserved inside the quote boundary",()=>{foreach(string value in new[]{"a b","a\tb","שלום 文件"})Require(InheritedSourceFixtureSpawn.Quote(value)=="\""+value+"\"");});
  Check("trailing slashes are doubled before the closing quote",()=>{for(int n=1;n<20;n++)Require(InheritedSourceFixtureSpawn.Quote("tail"+new string('\\',n))=="\"tail"+new string('\\',n*2)+"\"");});
  Check("slashes before an embedded quote are escaped separately",()=>{for(int n=0;n<20;n++)Require(InheritedSourceFixtureSpawn.Quote("a"+new string('\\',n)+"\"b")=="\"a"+new string('\\',n*2+1)+"\"b\"");});
  Check("middle slashes are unchanged when no quote follows",()=>Require(InheritedSourceFixtureSpawn.Quote("a\\\\b")=="\"a\\\\b\""));
  Check("control terminators null and oversized arguments refuse",()=>{foreach(string value in new[]{(string)null,"a\0b","a\rb","a\nb",new string('x',4097)}){try{InheritedSourceFixtureSpawn.Quote(value);}catch(InvalidOperationException){continue;}throw new Exception("argument_refusal_missing");}});
  Check("the Windows extended-startup ABI has the expected pointer-size layout",()=>{var type=typeof(InheritedSourceFixtureSpawn).GetNestedType("StartupInfoEx",BindingFlags.NonPublic);Require(Marshal.SizeOf(type)==(IntPtr.Size==8?112:72));});
  Check("missing source ownership cannot reach a process creation call",()=>{try{InheritedSourceFixtureSpawn.CreateSuspended(null,"unused","unused",Array.Empty<SafeHandle>(),(a,b)=>new[]{"--gw-source-inheritance-child"},CancellationToken.None);}catch(InvalidOperationException error){Require(error.Message=="fixture_spawn_context_required");return;}throw new Exception("missing_source_owner_was_accepted");});
  Console.WriteLine(JsonSerializer.Serialize(new {checks,scope="portable quoting metadata and refusal checks only",nativeWindowsInheritanceExecution=false,completeSourceLifetimeProof=false,productionPolicyCommitIntegrated=false}));
 }
}
