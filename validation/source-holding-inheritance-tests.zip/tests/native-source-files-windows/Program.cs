// Windows-only acceptance preparation. Own temporary files only. Never accepts a
// user path, existing PID or account and never elevates. Not run by Linux tests.
using System;
using System.IO;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using Microsoft.Win32.SafeHandles;
using GlassWidgets.ServerControlPrep;
internal static class SourceFilesWindowsTest {
 static int checks;static readonly List<string> Missing=new List<string>();
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetFinalPathNameByHandleW(SafeFileHandle file,StringBuilder value,uint size,uint flags);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CreateHardLinkW(string name,string existing,IntPtr security);
 static void Check(string name,Action action){action();checks++;Console.WriteLine("ok "+name);}
 static void Require(bool value){if(!value)throw new Exception("windows_source_assertion_failed");}
 static void SharingRefused(Action action){try{action();}catch(IOException){return;}catch(UnauthorizedAccessException){return;}throw new Exception("source_mutation_was_not_refused");}
 static void LeaseRefused(Action action){try{action();}catch(InvalidOperationException){return;}throw new Exception("source_lease_was_not_refused");}
 static string Canonical(string path){using(var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)){var text=new StringBuilder(32768);uint n=GetFinalPathNameByHandleW(f.SafeFileHandle,text,32768,0);Require(n>0&&n<32768&&text.ToString().StartsWith("\\\\?\\",StringComparison.Ordinal));return text.ToString().Substring(4);}}
 static SourceFileSpec Spec(string path){byte[] bytes=File.ReadAllBytes(path);return new SourceFileSpec(Canonical(path),bytes.Length,Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant());}
 static int Main(){
  if(!OperatingSystem.IsWindows()){Console.Error.WriteLine("windows_source_acceptance_not_executed");return 2;}
  string root=Path.Combine(Path.GetTempPath(),"gw-owned-source-acceptance-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);string code=Path.Combine(root,"code");Directory.CreateDirectory(code);string file=Path.Combine(code,"server.js");File.WriteAllText(file,"// owned source fixture\n");var spec=Spec(file);
  try{
   Check("control fixture is writable before lease",()=>{string control=Path.Combine(root,"control.txt");File.WriteAllText(control,"one");File.WriteAllText(control,"two");File.Move(control,control+".moved");File.Delete(control+".moved");});
   string hardlinkControl=Path.Combine(code,"control-alias.js");bool hardlinkAvailable=CreateHardLinkW(hardlinkControl,file,IntPtr.Zero);if(hardlinkAvailable){try{Check("source with an existing hard-link alias is refused",()=>LeaseRefused(()=>{using(var unexpected=HeldSourceFiles.Acquire(new[]{spec},CancellationToken.None)){};}));}finally{File.Delete(hardlinkControl);}}else Missing.Add("hard-link control fixture unavailable");
   using(var lease=HeldSourceFiles.Acquire(new[]{spec},CancellationToken.None)){
    Check("held source bytes verify while normal readers work",()=>{lease.Verify(CancellationToken.None);Require(File.ReadAllText(file).Contains("owned source fixture"));});
    Check("source write open is refused",()=>SharingRefused(()=>{using(var f=new FileStream(file,FileMode.Open,FileAccess.Write,FileShare.ReadWrite|FileShare.Delete))f.WriteByte(1);}));
    Check("source truncation is refused",()=>SharingRefused(()=>{using(var f=new FileStream(file,FileMode.Truncate,FileAccess.Write,FileShare.ReadWrite|FileShare.Delete)){};}));
    Check("source deletion is refused",()=>SharingRefused(()=>File.Delete(file)));
    Check("source rename is refused",()=>SharingRefused(()=>File.Move(file,file+".moved")));
    Check("source directory rename is refused",()=>SharingRefused(()=>Directory.Move(code,code+".moved")));
    Check("ordinary fixture data outside code remains writable",()=>{string data=Path.Combine(root,"data.txt");File.WriteAllText(data,"data");File.WriteAllText(data,"updated");File.Delete(data);});
    lease.Verify(CancellationToken.None);
   }
   Check("release restores source write access",()=>{using(var f=new FileStream(file,FileMode.Open,FileAccess.ReadWrite,FileShare.ReadWrite|FileShare.Delete))Require(f.Length==spec.Bytes);});
   Check("existing writer prevents acquisition",()=>{using(var writer=new FileStream(file,FileMode.Open,FileAccess.ReadWrite,FileShare.ReadWrite|FileShare.Delete))LeaseRefused(()=>{using(var unexpected=HeldSourceFiles.Acquire(new[]{spec},CancellationToken.None)){};});});
   Check("changed source refuses and cleans partial handles",()=>{File.AppendAllText(file,"// changed\n");LeaseRefused(()=>{using(var unexpected=HeldSourceFiles.Acquire(new[]{spec},CancellationToken.None)){};});File.WriteAllText(file,"// owned source fixture\n");});
   string alias=Path.Combine(code,"alias.js");
   using(var lease=HeldSourceFiles.Acquire(new[]{spec},CancellationToken.None)){
    if(CreateHardLinkW(alias,file,IntPtr.Zero)){
     Check("a created hard-link alias cannot bypass sharing",()=>{SharingRefused(()=>{using(var f=new FileStream(alias,FileMode.Open,FileAccess.Write,FileShare.ReadWrite|FileShare.Delete))f.WriteByte(1);});LeaseRefused(()=>lease.Verify(CancellationToken.None));});
    }else{int error=Marshal.GetLastWin32Error();if(hardlinkAvailable&&(error==32||error==5))Check("hard-link creation itself is refused",()=>{});else Missing.Add("hard-link capability unavailable");}
   }
   if(File.Exists(alias))File.Delete(alias);
   string symbolic=Path.Combine(Path.GetDirectoryName(spec.Path),"symbolic.js");
   try{File.CreateSymbolicLink(symbolic,file);Check("symbolic source is refused",()=>{try{using(var unexpected=HeldSourceFiles.Acquire(new[]{new SourceFileSpec(symbolic,spec.Bytes,spec.Sha256)},CancellationToken.None)){};}catch(InvalidOperationException error){Require(error.Message=="source_handle_unverified");return;}throw new Exception("symbolic_source_was_not_refused");});}
   catch(UnauthorizedAccessException){Missing.Add("symlink fixture privilege unavailable");}
   catch(PlatformNotSupportedException){Missing.Add("symlink fixture unsupported");}
   finally{if(File.Exists(symbolic))File.Delete(symbolic);}
   Console.WriteLine(JsonSerializer.Serialize(new {checks,scope="own temporary Windows source files only",nativeWindowsSourceLeaseExecution=true,acceptanceComplete=Missing.Count==0,missing=Missing,completeSourceLifetimeProof=false,normalUserPrivilegesVerified=false,realServerUsed=false}));return Missing.Count==0?0:6;
  }finally{Directory.Delete(root,true);}
 }
}
