using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using Microsoft.Win32.SafeHandles;
using GlassWidgets.ServerControlPrep;
internal static class InheritedSourceWindowsAcceptance {
 const string Marker="--gw-source-inheritance-child",QuoteProbe="quoted \"value\" and trailing\\";
 static int checks;
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetFileType(SafeFileHandle file);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetFinalPathNameByHandleW(SafeFileHandle file,StringBuilder value,uint length,uint flags);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetHandleInformation(IntPtr file,uint mask,uint flags);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetHandleInformation(IntPtr file,out uint flags);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(IntPtr file,uint milliseconds);
 static void Require(bool value){if(!value)throw new InvalidOperationException("source_inheritance_acceptance_assertion");}
 static void Check(string name,Action test){test();checks++;Console.WriteLine("ok "+name);}
 static string Hash(byte[] bytes)=>Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
 static string Canonical(SafeFileHandle file){var path=new StringBuilder(32768);uint count=GetFinalPathNameByHandleW(file,path,32768,0);Require(count>0&&count<32768&&path.ToString().StartsWith("\\\\?\\",StringComparison.Ordinal));return path.ToString().Substring(4);}
 static SourceFileSpec Spec(string path){using(var file=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)){byte[] bytes=File.ReadAllBytes(path);return new SourceFileSpec(Canonical(file.SafeFileHandle),bytes.Length,Hash(bytes));}}
 static void Refused(Action action){try{action();}catch(IOException){return;}catch(UnauthorizedAccessException){return;}throw new Exception("source_write_was_not_refused");}
 static JsonDocument Packet(StreamReader reader){string line=reader.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(8)).GetAwaiter().GetResult();Require(line!=null&&line.Length<32768);return JsonDocument.Parse(line);}
 static int Child(string[] args){
  if(args.Length!=8||args[0]!=Marker||args[7]!=QuoteProbe)return 31;
  var source=args[1].Split(',');if(source.Length<1||source.Length>2176)return 32;var handles=new List<SafeFileHandle>();var paths=new List<string>();
  try{
   foreach(string value in source){long raw=long.Parse(value,NumberStyles.None,CultureInfo.InvariantCulture);if(raw<=0)return 33;var handle=new SafeFileHandle(new IntPtr(raw),true);handles.Add(handle);if(GetFileType(handle)!=1)return 34;paths.Add(Canonical(handle));if(!SetHandleInformation(handle.DangerousGetHandle(),1,0))return 35;uint flags;if(!GetHandleInformation(handle.DangerousGetHandle(),out flags)||(flags&1)!=0)return 36;}
   long eventRaw=long.Parse(args[2],NumberStyles.None,CultureInfo.InvariantCulture),pipeRaw=long.Parse(args[3],NumberStyles.None,CultureInfo.InvariantCulture);if(eventRaw<=0||pipeRaw<=0)return 37;
   if(!SetHandleInformation(new IntPtr(eventRaw),1,0)||!SetHandleInformation(new IntPtr(pipeRaw),1,0))return 38;
   using(var pipe=new AnonymousPipeClientStream(PipeDirection.Out,new SafePipeHandle(new IntPtr(pipeRaw),true)))using(var writer=new StreamWriter(pipe,new UTF8Encoding(false),1024,true){AutoFlush=true}){
    writer.WriteLine(JsonSerializer.Serialize(new {phase="ready",pid=Environment.ProcessId,manifestHash=args[4],paths,inheritFlagsCleared=true}));
    if(WaitForSingleObject(new IntPtr(eventRaw),10000)!=0)return 39;
    string hash=Hash(File.ReadAllBytes(args[5]));if(hash!=args[6])return 40;writer.WriteLine(JsonSerializer.Serialize(new {phase="delayed-read",pid=Environment.ProcessId,sha256=hash}));
    if(WaitForSingleObject(new IntPtr(eventRaw),10000)!=0)return 41;
   }
   return 0;
  }finally{foreach(var handle in handles)handle.Dispose();}
 }
 static int Main(string[] args){
  if(!OperatingSystem.IsWindows()){Console.Error.WriteLine("windows_source_inheritance_acceptance_not_executed");return 2;}
  if(args.Length>0)return Child(args);
  string name=Assembly.GetExecutingAssembly().GetName().Name,build=AppContext.BaseDirectory;string root=Path.Combine(Path.GetTempPath(),"gw source inheritance "+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
  HeldSourceFiles lease=null;InheritedSourceFixtureProcess child=null;
  try{
   // Copy only this build output, never an installed source or user directory.
   // A self-contained CI publish includes framework runtime files as well. Those
   // are not part of the five-file source-lifetime claim exercised below.
   var output=Directory.GetFiles(build,"*",SearchOption.TopDirectoryOnly);if(output.Length>512||output.Sum(x=>new FileInfo(x).Length)>268435456)throw new InvalidOperationException("own_fixture_output_limit");foreach(string original in output)File.Copy(original,Path.Combine(root,Path.GetFileName(original)),false);
   var files=new List<string>();foreach(string suffix in new[]{".exe",".dll",".deps.json",".runtimeconfig.json"}){string target=Path.Combine(root,name+suffix);if(!File.Exists(target))throw new InvalidOperationException("own_acceptance_apphost_required");files.Add(target);}
   string delayed=Path.Combine(root,"delayed module.js");File.WriteAllText(delayed,"// own delayed source fixture\n",new UTF8Encoding(false));files.Add(delayed);var specs=files.Select(Spec).ToArray();string image=specs.First(x=>x.Path.EndsWith(".exe",StringComparison.OrdinalIgnoreCase)).Path;var source=specs.First(x=>x.Path.EndsWith("delayed module.js",StringComparison.Ordinal));
   using(var signal=new EventWaitHandle(false,EventResetMode.AutoReset))using(var pipe=new AnonymousPipeServerStream(PipeDirection.In,HandleInheritability.None))using(var reader=new StreamReader(pipe,new UTF8Encoding(false),false,1024,true)){
    lease=HeldSourceFiles.Acquire(specs,CancellationToken.None);string manifest=lease.ManifestHash;
    child=InheritedSourceFixtureSpawn.CreateSuspended(lease,image,Path.GetDirectoryName(image),new SafeHandle[]{signal.SafeWaitHandle,pipe.ClientSafePipeHandle},(held,channels)=>new[]{Marker,String.Join(",",held.Select(x=>x.ToString(CultureInfo.InvariantCulture))),channels[0].ToString(CultureInfo.InvariantCulture),channels[1].ToString(CultureInfo.InvariantCulture),manifest,source.Path,source.Sha256,QuoteProbe},CancellationToken.None);
    Check("created fixture is held by original native process handle and remains suspended",()=>{Require(child.Pid>0&&long.Parse(child.NativeCreatedFileTimeUtc,CultureInfo.InvariantCulture)>0&&!child.WaitForExit(0));Require(child.ManifestHash==manifest);});
    child.Resume();pipe.DisposeLocalCopyOfClientHandle();
    using(var ready=Packet(reader)){var value=ready.RootElement;Check("child receives exactly the reviewed source objects before holder release",()=>{Require(value.GetProperty("phase").GetString()=="ready"&&value.GetProperty("pid").GetUInt32()==child.Pid&&value.GetProperty("manifestHash").GetString()==manifest&&value.GetProperty("inheritFlagsCleared").GetBoolean());var paths=value.GetProperty("paths").EnumerateArray().Select(x=>x.GetString()).ToArray();Require(paths.Length>=specs.Length&&specs.All(x=>paths.Contains(x.Path,StringComparer.OrdinalIgnoreCase)));});}
    lease.Dispose();lease=null;
    Check("holder release cannot permit source writes while inherited child remains alive",()=>{Require(!child.WaitForExit(0));Refused(()=>File.WriteAllText(source.Path,"changed"));Refused(()=>File.Delete(source.Path));Refused(()=>Directory.Move(root,root+" renamed"));});
    signal.Set();using(var loaded=Packet(reader)){var value=loaded.RootElement;Check("later ordinary source open reads original bytes after holder release",()=>Require(value.GetProperty("phase").GetString()=="delayed-read"&&value.GetProperty("pid").GetUInt32()==child.Pid&&value.GetProperty("sha256").GetString()==source.Sha256));}
    Check("source remains protected after delayed read until exact child exit",()=>{Require(!child.WaitForExit(0));Refused(()=>File.WriteAllText(source.Path,"still changed"));});
    signal.Set();Check("original child handle proves successful exit",()=>Require(child.WaitForExit(5000)&&child.ExitCode()==0));child.Dispose();child=null;
    Check("own source becomes writable after exact inherited owner exit",()=>{File.WriteAllText(source.Path,"released");Require(File.ReadAllText(source.Path)=="released");});
   }
   Console.WriteLine(JsonSerializer.Serialize(new {checks,scope=InheritedSourceFixtureSpawn.Scope,nativeWindowsInheritanceExecution=true,ownTemporaryFixturesOnly=true,productionPolicyCommitIntegrated=false,nodeRuntimeInheritanceCompatibility=false,completeSourceLifetimeProof=false}));return 0;
  }finally{try{if(child!=null)child.Dispose();}finally{try{if(lease!=null)lease.Dispose();}finally{Directory.Delete(root,true);}}}
 }
}
