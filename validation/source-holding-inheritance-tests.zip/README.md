# Source holding and inheritance dummy tests

This is the narrow source-only component/test snapshot. It is not installed server source, an installer, a production launcher, configuration or a complete backend.

The prior Windows run passed 14 source-file checks, 7 normal-release inheritance checks and 9 portable checks. This continuation adds a test of abrupt termination of the original source holder while the exact original C# reader child remains alive. It uses only its own temporary files and its own processes.

The new test transfers an original child process handle into the root test process before terminating its own helper. It compares PID, exact native creation time and image identity against the original creation report, then waits and cleans up through that original handle. There is no discovered-PID termination. The helper is terminated with the original creation handle and a checked exit code, without relying on managed cleanup. The child reads its delayed source afterward, then exits before write access should return.

The new test has compiled locally and its plan serialization and non-Windows guard were checked. Actual new Windows execution remains pending the manual run associated with this commit. Existing and new tests use the unchanged net10.0/runtime 10.0.15 target. No SDK, generated output, secrets, installed sources or raw logs are included.

This does not prove standalone Node compatibility, ordinary-user privileges, complete dependency closure, ACL integrity, policy CAS or production launch/Stop integration. The inheritance primitive remains fixture-only and is not linked into the production host. The test's own inherited handles and transferred process handles are not a general adoption protocol.
