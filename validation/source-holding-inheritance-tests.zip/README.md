# Native source inheritance and own dummy tests

This is only the source-holding component, explicit inheritance fixture and their own dummy tests. It is not installed server source, an installer, a production policy/CAS adapter, user configuration or a complete backend.

Earlier Windows runs passed source-file, ordinary inheritance and abrupt C# holder-death scenarios. This continuation adds a pinned standalone Node dummy child that must load an ordinary delayed CommonJS module after its original source holder has been forcibly terminated.

Before the Node child resumes, its inherited source handles are replaced within the CHILD handle table with non-inheritable duplicates. Numeric values in the child must never be wrapped in a parent-owned SafeHandle. DuplicateHandle can close the source on failure; any failed sealing step aborts the fixture before resume. This is not a production cleanup protocol.

The root gets the child's original process handle before resume and checks image/PID/exact creation time against the original creation record. The fixture checks source mutation refusal after holder death, actual delayed require, exact original Node exit and restored source write access. It accepts no existing PID and uses only freshly copied runtime/source files and its own child processes.

Pinned test runtime: v20.18.3. This is a fixture selection, NOT identification, installation or upgrade of the user's standalone server runtime. The workflow downloads the official Windows x64 binary only for its isolated dummy test, verifies its published SHA256, and uploads no binary or artifact. Runtime metadata is reported by the actual child. The application project dependencies remain unchanged.

Official release: https://nodejs.org/en/blog/release/v20.18.3
Official executable: https://nodejs.org/dist/v20.18.3/win-x64/node.exe
Pinned executable SHA256: 528a9aa64888a2a3ba71c6aea89434dd5ab5cb3caa9f0f31345cf5facf685ab0

The new project compiled with zero warnings/errors, its plan round trip and non-Windows guard were checked, and its embedded JavaScript passed syntax checking. New Windows execution is pending the manual run of this commit.

Limits: installed-server runtime identity, ordinary-user privileges, full source/dependency closure, production policy CAS and ownership/Stop integration are unverified. The fixture component is not linked into the production host. Public source tests do not grant installed-source or user-PC access.
