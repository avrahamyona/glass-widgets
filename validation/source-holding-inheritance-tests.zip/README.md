# Source holding and inheritance validation

This snapshot contains a read-only Windows source-file holding component, an explicit-handle-inheritance fixture primitive, and tests. It is not an application update, server launcher, installer or release.

The Windows tests create their own temporary files and processes. They accept no existing source path or PID. They do not access an installed server, personal configuration or another computer.

## Test scope

- Read-only source-file handles, ancestor paths, content hashes and refusal of mutations.
- Ordinary writable fixture data and cleanup after disposal.
- Hard-link and symbolic-link handling. An unavailable test capability is reported as incomplete acceptance, not success.
- A suspended fixture process created with an explicit inherited handle list.
- Protection after the original source lease is released, a later ordinary source read, and release after original-child-handle exit proof.
- Portable quoting, argument refusal and extended startup-structure layout checks.

The inheritance child is a dedicated C# fixture. It clears inheritability on its own received handles. This is not proof that the installed Node runtime behaves the same way. Releasing the parent lease is also not a test of abrupt helper-process death.

There is no production policy/CAS commit, complete dependency closure, installed-source enrollment, authenticated server-health check, listener-owner check or real application-answer proof in this snapshot. The inheritance primitive is deliberately not linked into the production stdio host.

## Runtime

The existing target remains .NET 10.0 with runtime 10.0.15. CI publishes self-contained test programs solely into temporary runner output. No installer or executable artifact is uploaded. The inheritance fixture copies only its own build output into a new temporary directory; framework files copied for that self-contained fixture are not part of its five-file source-lifetime claim.

## Validation workflow

The surrounding workflow is manual, tied to a separate validation branch and the exact supplied commit SHA, and uses only a standard Windows runner in this public repository. The workflow first checks the archive's SHA-256. The archive manifest records every source-file hash.

GitHub's standard public-repository runner terms:
https://docs.github.com/en/actions/reference/runners/github-hosted-runners

Windows inheritance and handle-list references:
https://learn.microsoft.com/en-us/windows/win32/procthread/inheritance
https://github.com/MicrosoftDocs/sdk-api/blob/docs/sdk-api-src/content/processthreadsapi/nf-processthreadsapi-updateprocthreadattribute.md
